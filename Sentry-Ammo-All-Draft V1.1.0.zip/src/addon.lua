local hd2=require('mods/skyeshade/hd2runtime')

local generated={}

-- Custom Lua: src/addon.lua (hand-written; ModBuilder copies it unchanged)
local function addon(...)
-- Sentry Ammo All 3.8.5 draft: status-colored icon frames and observed-deployment game-time estimates.
-- No screen projection, no screen GUI, no world GUI and no gameplay writes.
-- Uses Stingray world-space geometry with depth testing so terrain/rocks/walls occlude the marker naturally.
-- Entity record: +0 u64 type hash, +8 id, +0xC unit handle, +0x14 flags.
if type(jit) == 'table' and type(jit.off) == 'function' then jit.off(true, true) end

local CFG = {
    radius = 15.0,        -- m
    interval = 0.5,       -- s per supply pass
    heal_frac = 0.05,     -- fraction of max HP per pass (hull and every part)
    ammo_every = 2,       -- passes (2 x 0.5 s = once per second); 0 = no ammo
    ammo_frac = 0.10,     -- max fraction of a magazine / of max spare magazines per step
    wheel_every = 4,      -- passes per repaired tyre (4 x 0.5 s = 2 s); 0 = off
    leg_fix = true,       -- restore exosuit move speed after full repair
    arm_every = 2,        -- passes between advanced exosuit-arm/weapon repair scans (2 x 0.5 s = 1 s)
    block_arc = false,    -- FX-12 keeps its normal shield behavior; no Tesla arc suppression
    arc_hold = 5.0,       -- unused in FX-12 mode; kept for binary/build compatibility
    learn_every = 1.0,    -- s between tyre-learning scans
    sentry_dynamic = false, -- SAFE: only verified sentry roots; excludes unknown mech/objective mounted weapons
    spatial_emplacement_ammo = true, -- refill fixed mounted ammo inside the FX-12 bubble even if root hash is unknown
    spatial_emplacement_min_cap = 10, -- avoids ordinary single-shot/support weapons; E/AT-12 and sentries exceed this or use >=10 reserves
}

local unpack_values = table.unpack or unpack
local function pack_values(...) return {n = select('#', ...), ...} end
local TWO32 = 4294967296

local TOWER_TYPES = { ['ED13DDC480EC6910'] = 'FX-12 Shield Generator Relay' }
local VEHICLE_TYPES = {
    ['79E4B3D2DA5E45E3'] = 'EXO-45 Patriot', ['08F6089289C83D22'] = 'EXO-45 gatling',
    ['824B7E0C4C879EB5'] = 'EXO-45 rockets', ['821D035AA47E3E75'] = 'EXO-45 rockets MK2',
    ['C2D449ECF7FACAB1'] = 'EXO-49 Emancipator', ['BF4167FD26917AB1'] = 'EXO-49 arm',
    ['E5F64DCC3BFE9DD1'] = 'EXO-49 left', ['32C7063B4BCC4208'] = 'EXO-49 left MK2',
    ['8CA4DFA795A473C8'] = 'EXO-49 left MK3', ['FF9878576A4C543B'] = 'EXO-49 right',
    ['0A03761D50BA5121'] = 'EXO-49 right MK2', ['3E3A31261A124454'] = 'EXO-49 right MK3',
    ['7B2326F6FD9C8069'] = 'EXO-51 Lumberer', ['0736BEE2D6328726'] = 'EXO-51 flamer',
    ['17C5D12D8D5DEE2C'] = 'EXO-51 AT cannon', ['35DBF54F016F3624'] = 'EXO-55 Breaker',
    ['65489809A8181B96'] = 'EXO-55 shield', ['DF51FE8D62F294BE'] = 'EXO-55 shotgun',
    ['CC21C7FFD3EBEFB9'] = 'M-102 FRV', ['E9CD1D0D118886AF'] = 'M-102 FRV (map)',
    ['9B2140378640432E'] = 'M-103 Supply FRV', ['9E83637BB077E782'] = 'M-103 supply crate',
    ['2D85BFE3D8717FE5'] = 'M-104 FRV', ['16474112801385B6'] = 'TD-220 Bastion',
    ['1FA1F596769225C2'] = 'TD-220 cannon', ['B0C9FAF4AF8903F9'] = 'TD-?? Maelstrom',
    ['D58AE6A04EDB10DE'] = 'Maelstrom main gun', ['C36B5B37C058DBDD'] = 'Maelstrom designator',
    ['3A061009AA31E9CB'] = 'Maelstrom smoke launcher', ['8AFF7F0793A5BCED'] = 'Maelstrom rocket pods',
    ['423FF97D57AB04F5'] = 'Harvester rig',
    ['0801B6B3C5D12EBC'] = 'Harvester rig MK2', ['9872EEB31A5F88FD'] = 'Harvester turret',
    ['130574E0FFFE0058'] = 'Harvester tank',
}

-- Verified Super Earth Defensive turret/emplacement roots. The dynamic Mount fallback below
-- covers newer green stratagems (e.g. new sentries/emplacements) whose root hash is not in this table yet.
local SENTRY_TYPES = {
    ['0E977C49DB7604F9'] = 'E/MG-101 HMG Emplacement',
    ['A970CBA66FBEAA11'] = 'HMG Emplacement (discoverable)',
    ['51A0812E3BCE2D74'] = 'Mortar / EMS Mortar Sentry',
    ['37079568DC86E9C6'] = 'Rocket Sentry',
    ['EF85D6CF58E31D70'] = 'Gatling / Autocannon-family Sentry',
    ['7FF0FD4572F5996F'] = 'Power-generated Gatling Sentry',
    ['37CDE43876BA26BB'] = 'Machine Gun Sentry',
    ['57F27CBD5B71B0CB'] = 'Tutorial Sentry',
}

-- WeaponMagazine entity type -> owning vehicle root type.
-- These are used only when the normal Mount/Attachable chain does not reach the vehicle root.
local DIRECT_WEAPON_ROOTS = {
    ['08F6089289C83D22'] = '79E4B3D2DA5E45E3', -- EXO-45 gatling
    ['824B7E0C4C879EB5'] = '79E4B3D2DA5E45E3', -- EXO-45 rockets
    ['821D035AA47E3E75'] = '79E4B3D2DA5E45E3', -- EXO-45 rockets MK2
    ['BF4167FD26917AB1'] = 'C2D449ECF7FACAB1', -- EXO-49 arm
    ['E5F64DCC3BFE9DD1'] = 'C2D449ECF7FACAB1', -- EXO-49 left
    ['32C7063B4BCC4208'] = 'C2D449ECF7FACAB1', -- EXO-49 left MK2
    ['8CA4DFA795A473C8'] = 'C2D449ECF7FACAB1', -- EXO-49 left MK3
    ['FF9878576A4C543B'] = 'C2D449ECF7FACAB1', -- EXO-49 right
    ['0A03761D50BA5121'] = 'C2D449ECF7FACAB1', -- EXO-49 right MK2
    ['3E3A31261A124454'] = 'C2D449ECF7FACAB1', -- EXO-49 right MK3
    ['0736BEE2D6328726'] = '7B2326F6FD9C8069', -- EXO-51 flamer
    ['17C5D12D8D5DEE2C'] = '7B2326F6FD9C8069', -- EXO-51 AT cannon
    ['DF51FE8D62F294BE'] = '35DBF54F016F3624', -- EXO-55 shotgun
    ['1FA1F596769225C2'] = '16474112801385B6', -- TD-220 cannon
    ['D58AE6A04EDB10DE'] = 'B0C9FAF4AF8903F9', -- Maelstrom main gun
    ['C36B5B37C058DBDD'] = 'B0C9FAF4AF8903F9', -- Maelstrom designator
    ['3A061009AA31E9CB'] = 'B0C9FAF4AF8903F9', -- Maelstrom smoke launcher
    ['8AFF7F0793A5BCED'] = 'B0C9FAF4AF8903F9', -- Maelstrom rocket pods
}

-- Exosuit arm/weapon HealthComponent type -> owning exosuit root.
-- Field Repair 1.3 demonstrated that these arm entities remain in the Health manager even after destruction;
-- reviving their Health record + side state + dead-part mask makes the weapon functional again.
local EXO_ARM_ROOTS = {
    ['08F6089289C83D22'] = '79E4B3D2DA5E45E3', ['824B7E0C4C879EB5'] = '79E4B3D2DA5E45E3',
    ['821D035AA47E3E75'] = '79E4B3D2DA5E45E3',
    ['BF4167FD26917AB1'] = 'C2D449ECF7FACAB1', ['E5F64DCC3BFE9DD1'] = 'C2D449ECF7FACAB1',
    ['32C7063B4BCC4208'] = 'C2D449ECF7FACAB1', ['8CA4DFA795A473C8'] = 'C2D449ECF7FACAB1',
    ['FF9878576A4C543B'] = 'C2D449ECF7FACAB1', ['0A03761D50BA5121'] = 'C2D449ECF7FACAB1',
    ['3E3A31261A124454'] = 'C2D449ECF7FACAB1',
    ['0736BEE2D6328726'] = '7B2326F6FD9C8069', ['17C5D12D8D5DEE2C'] = '7B2326F6FD9C8069',
    ['DF51FE8D62F294BE'] = '35DBF54F016F3624', ['65489809A8181B96'] = '35DBF54F016F3624',
}
local EXO_ROOTS = {
    ['79E4B3D2DA5E45E3'] = true, ['C2D449ECF7FACAB1'] = true,
    ['7B2326F6FD9C8069'] = true, ['35DBF54F016F3624'] = true,
}

local function mul32(a, b)
    local al, ah = a % 65536, math.floor(a / 65536)
    local bl, bh = b % 65536, math.floor(b / 65536)
    local mid = (ah * bl + al * bh) % 65536
    return (mid * 65536 + al * bl) % TWO32
end
-- Game hash-map probe: slot = (cap-1) & (i + key*mult); stop at empty key.
local function probe_map(key, capacity, empty_key, multiplier, read_slot, probe_limit)
    if key == empty_key then return nil, 'key_equals_empty_marker' end
    if type(capacity) ~= 'number' or capacity < 1 or capacity > 0x1000000 then return nil, 'map_capacity_rejected' end
    local pow = 1
    while pow < capacity do pow = pow * 2 end
    if pow ~= capacity then return nil, 'map_capacity_not_power_of_two' end
    local base = mul32(key, multiplier)
    local limit = math.min(capacity, probe_limit or 256)
    for i = 0, limit - 1 do
        local index = ((base + i) % TWO32) % capacity
        local k, v = read_slot(index)
        if k == nil then return nil, 'map_slot_unreadable' end
        if k == empty_key then return nil, 'absent' end
        if k == key then
            if v == nil or v == 0xFFFFFFFF then return nil, 'present_with_invalid_index' end
            return v
        end
    end
    return nil, 'probe_limit_reached'
end
local function parse_pattern(text)
    local out = {}
    for token in text:gmatch('%S+') do
        if token == '??' then out[#out + 1] = -1 else out[#out + 1] = tonumber(token, 16) end
    end
    return out
end
local function masked_match(bytes, start, pattern)
    if start < 1 or start + #pattern - 1 > #bytes then return false end
    for i = 1, #pattern do
        local want = pattern[i]
        if want >= 0 and bytes:byte(start + i - 1) ~= want then return false end
    end
    return true
end
-- ceil(n * frac), at least 1
local function step_of(n, frac)
    local x = n * frac
    local s = math.floor(x)
    if x > s then s = s + 1 end
    if s < 1 then s = 1 end
    return s
end

if rawget(_G, 'SentryAmmoModelScannerTest') then
    return {mul32 = mul32, probe_map = probe_map, parse_pattern = parse_pattern, masked_match = masked_match,
        step_of = step_of, CFG = CFG, VEHICLE_TYPES = VEHICLE_TYPES, SENTRY_TYPES = SENTRY_TYPES}
end
if rawget(_G, 'SentryAmmoModelScanner') then return end

-- ---------------------------------------------------------------------------------------
-- Locators (game.dll 1.0.0.19155, dump output20260926). Every address is derived from code
-- bytes; exact build = timestamp + all patterns at their recorded RVAs, otherwise a chunked
-- read-only scan looks for unique hits.
local BUILD = {
    label = 'output20260926', file_version = '1.0.0.19155', pe_timestamp = 0x6AB3B43F,
    accepted_image_sizes = {[0x4747000] = true, [0x4744000] = true},
    P = {
    HEALDRV = {rva = 0x4B9B50, pattern = '40 57 48 83 EC 20 48 8B 39 4C 8B 1D ?? ?? ?? ?? 8B 47 08 3B 05 ?? ?? ?? ?? 74 ?? 45 8B 93 ?? ?? ?? ?? 45 33 C0 48 89 5C 24 30 41 8B 9B ?? ?? ?? ?? 0F AF D8 4C 89 74 24 48 45 8D 72 FF 45 85 D2 74 ?? 48 89 6C 24 38 41 8B AB ?? ?? ?? ?? 48 89 74 24 40 49 8B B3 ?? ?? ?? ?? 66 0F 1F 44 00 00 41 8D 14 18 41 8B CE 48 23 D1 44 8B 0C D6 44 3B CD 74 ?? 44 3B C8 74 ?? 41 FF C0 45 3B C2 72 ?? 48 8B 74 24 40 48 8B 6C 24 38 48 8B 5C 24 30 4C 8B 74 24 48 0F 28 D1 8B D0 49 8B CB 48 83 C4 20 5F E9 ?? ?? ?? ??'},
    RESUP   = {rva = 0x705A80, pattern = '40 53 48 83 EC 20 44 3B 05 ?? ?? ?? ?? 41 8B D8 0F 84 ?? ?? ?? ?? 48 89 6C 24 30 33 D2 48 89 7C 24 40 8B CA 48 8B 3D ?? ?? ?? ?? 4C 89 74 24 48 44 8B 47 28 44 8B 5F 30 41 8B EB 0F AF EB 45 8D 70 FF 45 85 C0 0F 84 ?? ?? ?? ?? 4C 8B 57 20 48 89 74 24 38 8B 77 2C 66 0F 1F 84 00 00 00 00 00 41 8B C6 44 8D 0C 29 4C 23 C8 43 8B 04 CA 3B C6 74 ?? 3B C3 74 ?? FF C1 41 3B C8 72 ?? EB ?? 3B C3 75 ?? 43 8B 44 CA 04 83 F8 FF 74 ?? 8B C8 48 8B 47 38 48 8B 0C C8'},
    ADDMAG  = {rva = 0x76E830, pattern = '48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 48 89 7C 24 20 41 56 48 83 EC 20 3B 15 ?? ?? ?? ?? 8B DA 48 8B 2D ?? ?? ?? ?? 74 ?? 44 8B 45 28 33 C9 44 8B 4D 30 44 0F AF CB 41 8D 78 FF 45 85 C0 74 ?? 4C 8B 55 20 44 8B 5D 2C 66 0F 1F 44 00 00 8B C7 42 8D 14 09 48 23 D0 41 8B 04 D2 41 3B C3 0F 84 ?? ?? ?? ?? 3B C3 0F 84 ?? ?? ?? ?? FF C1 41 3B C8 72 ??'},
    STATMOD = {rva = 0x9CCAE0, pattern = '40 55 3B 15 ?? ?? ?? ?? 4C 8B 15 ?? ?? ?? ?? 49 63 E8 75 ?? B8 FF FF FF FF EB ?? 45 8B 4A 28 33 C9 45 8B 5A 30 48 89 5C 24 10 48 89 74 24 18 44 0F AF DA 41 8D 71 FF 48 89 7C 24 20 45 85 C9 74 ?? 49 8B 5A 20 41 8B 7A 2C 0F 1F 80 00 00 00 00 8B C6 46 8D 04 19 4C 23 C0 42 8B 04 C3 3B C7 74 ?? 3B C2 74 ?? FF C1 41 3B C9 72 ?? B8 FF FF FF FF 48 8B 74 24 18 48 8B 5C 24 10 48 8B 7C 24 20 8B C8 49 8B 42 48 48 6B D1 0D 48 03 D5 F3 0F 11 1C 90 5D C3'},
    WHEEL   = {rva = 0x11A8490, pattern = '48 89 5C 24 18 48 89 6C 24 20 57 48 81 EC C0 00 00 00 48 8B 05 ?? ?? ?? ?? 48 33 C4 48 89 84 24 B0 00 00 00 8B 41 08 8B EA 3B 05 ?? ?? ?? ?? 48 8B 1D ?? ?? ?? ?? 75 ?? B8 FF FF FF FF EB ?? 44 8B 4B 48 33 D2 44 8B 53 50 44 0F AF D0'},
    MOUNTRS = {rva = 0x705900, pattern = '48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 41 56 41 57 48 83 EC 30 8B 05 ?? ?? ?? ?? 48 8B 3D ?? ?? ?? ?? 3B D0 74 ?? 44 8B 57 28 45 33 C9 8B 5F 30 0F AF DA 45 8D 72 FF 45 85 D2 74 ?? 48 8B 77 20 8B 6F 2C 66 66 0F 1F 84 00 00 00 00 00 41 8B CE 45 8D 04 19 4C 23 C1 42 8B 0C C6 4E 8D 1C C6 3B CD 0F 84 ?? ?? ?? ?? 3B CA 0F 84 ?? ?? ?? ?? 41 FF C1 45 3B CA 72 ?? B9 FF FF FF FF 8B D1 41 BF 05 00 00 00 48 8B 4F 48'},
    WAPI    = {rva = 0x6E7F76, pattern = '41 0B C6 80 BF 01 03 00 00 00 89 87 FC 02 00 00 75 ?? 48 8B 05 ?? ?? ?? ?? 48 8B 48 18 48 8B 43 58 4C 8B 81 90 00 00 00 48 8B 0C D0 33 D2 8B 49 0C 41 FF D0'},
    UNIT    = {rva = 0x4DF3CE, pattern = '4D 8B 2C 24 8B 15 ?? ?? ?? ?? 48 8B 2D ?? ?? ?? ?? 41 8B 45 08 3B C2 74 ?? 44 8B 55 48 44 8B C7 44 8B 5D 50 44 0F AF D8'},
    ATT     = {rva = 0x4A52B0, pattern = '48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 48 89 7C 24 20 3B 15 ?? ?? ?? ?? 4C 8B 15 ?? ?? ?? ?? 74 ?? 45 8B 4A 20 45 33 C0 41 8B 5A 28 0F AF DA 41 8D 69 FF 45 85 C9 74 ?? 49 8B 7A 18 41 8B 72 24 0F 1F 40 00 66 66 0F 1F 84 00 00 00 00 00 8B C5 41 8D 0C 18 48 23 C8 8B 04 CF 4C 8D 1C CF 3B C6 74 ?? 3B C2 74 ?? 41 FF C0 45 3B C1 72 ?? 32 C0 48 8B 5C 24 08 48 8B 6C 24 10 48 8B 74 24 18 48 8B 7C 24 20 C3 3B C2 75 ?? 41 8B 43 04 83 F8 FF 74 ?? 48 69 C8 ?? ?? ?? ?? 49 8B 42 ?? 83 3C 01 00 0F 95 C0 EB ??'},
    WPN     = {rva = 0x80DF4A, pattern = '41 8B 45 08 3B 05 ?? ?? ?? ?? 48 8B 35 ?? ?? ?? ?? 74 ?? 44 8B 4E 30 33 D2 44 8B 56 38 44 0F AF D0 45 8D 61 FF 45 85 C9 74 ?? 4C 8B 5E 28 8B 7E 34'},
    ARC     = {rva = 0x80C180, pattern = '48 83 EC 28 3B 15 ?? ?? ?? ?? 4C 8B 1D ?? ?? ?? ?? 75 ?? B8 FF FF FF FF EB ?? 45 8B 4B 50 45 33 C0 48 89 5C 24 30 41 8B 5B 58 48 89 6C 24 38 0F AF DA 41 8D 69 FF 48 89 74 24 40 48 89 7C 24 20 45 85 C9 74 ?? 49 8B 7B 48 41 8B 73 54 0F 1F 00 8B C5 41 8D 0C 18 48 23 C8 8B 04 CF 4C 8D 14 CF 3B C6 74 ?? 3B C2 74 ?? 41 FF C0 45 3B C1 72 ?? B8 FF FF FF FF 48 8B 74 24 40 48 8B 6C 24 38 48 8B 5C 24 30 48 8B 7C 24 20 8B C8 49 8B 43 70 4C 8D 04 89 46 8B 44 C0 04 48 83 C4 28 E9'},
    },
    ORDER = {'HEALDRV', 'RESUP', 'ADDMAG', 'STATMOD', 'WHEEL', 'MOUNTRS', 'WAPI', 'UNIT', 'ATT', 'ARC', 'WPN'},
    -- Health rows / zone config (fixed across 0815..0926 once the table offset is known)
    hp = {rows_from_tbl = 0x28, row28_from_tbl = 0x30, recs_from_tbl = 0x18, cur = 0x14, state = 0x19C,
          zones = 0xF8, max28 = 0x14, row28_stride = 0x1C, cfg_zone = 0x268, cfg_zone_stride = 0x228,
          cfg_zone_max = 0x88, n_zones = 0x26},
    arc = {recs = 0x60, stride = 40, cooldown = 8},
    wpn = {stride = 40, arc_bit = 0x10},
    wm = {stride = 12, cfg_cap = 0x88, cfg_max = 0x94},
    mount = {stride = 0x18, slots = 5},
    sm = {stride = 13 * 4, leg_hurt = 0.75},
    wheel = {size = 0x30, flag = 0x28, magic = 0x20575256},   -- 'VRW ' vehicle resource
}
for _, p in pairs(BUILD.P) do p.mask = parse_pattern(p.pattern) end

local state = {
    revision = 'vehicle-supply-shield-relay-field-repair-parts-lua-1.0.9',
    build = BUILD.label, build_mode = 'unchecked', version_warning = 'none',
    phase = 'environment_gate', status = 'starting', module_fingerprint = 'unchecked', globals = 'unresolved',
    frames = 0, passes = 0, errors = 0, native_calls = 0,
    towers = 0, arc_holds = 0, arc_bits_cleared = 0, arc_bits_restored = 0, tower_weapon = 'none',
    heal_probe = 'none', ammo_probe = 'none', sentry_probe = 'none', vehicles_in_range = 0, sentries_in_range = 0, heal_calls = 0, full_skips = 0,
    ammo_fill_calls = 0, ammo_mag_calls = 0, ammo_skip_non_authority = 0, ammo_native_nochange = 0, client_ammo_writes = 0,
    direct_ammo_hits = 0, direct_ammo_probe = 'none', dynamic_sentry_roots = 0,
    wheel_types_learned = 0, wheels_learned = 0, wheels_fixed = 0, wheel_skips = 'none',
    legs_fixed = 0, arms_revived = 0, arms_mended = 0, shield_plates_fixed = 0,
    arm_scan_hits = 0, arm_skips = 'none', last_part = 'none',
    last_heal = 'none', last_ammo = 'none', last_wheel = 'none',
    compatibility_scan_offset = 0, compatibility_hits = 'none', stopped = false,
}
rawset(_G, 'SentryAmmoModelScanner', state)

local loader = rawget(_G, 'CowboyBingusModLoader')
if type(loader) ~= 'table' or type(loader.api) ~= 'number' or loader.api < 1
    or type(loader.version) ~= 'number' or loader.version < 15 then
    state.phase, state.status = 'rejected', 'Bingus Shared Loader v15 or newer / API 1 (or MDL) required'
    print('[SentryAmmoModelScanner] ' .. state.status)
    return
end
local ok_ffi, ffi = pcall(require, 'ffi')
if not ok_ffi or not ffi.abi('win') or not ffi.abi('64bit') then
    state.phase, state.status = 'rejected', 'Windows x64 LuaJIT FFI required'
    print('[SentryAmmoModelScanner] ' .. state.status)
    return
end
local bit = require('bit')

pcall(ffi.cdef, [[
    typedef struct {
        void *base; void *allocation_base; uint32_t allocation_protection;
        uint16_t partition; uint16_t reserved; size_t size;
        uint32_t state; uint32_t protection; uint32_t type;
    } VstMemoryRegion;
]])
pcall(ffi.cdef, [[
    void *GetModuleHandleA(const char *name);
    void *GetCurrentProcess(void);
    int ReadProcessMemory(void *process, const void *address, void *buffer, size_t size, size_t *read);
    size_t VirtualQuery(const void *address, void *region, size_t size);
]])
local kernel = ffi.load('kernel32')
local process = kernel.GetCurrentProcess()
local U8 = ffi.typeof('uint8_t *')
local query_region = ffi.cast('size_t (*)(const void *, void *, size_t)', kernel.VirtualQuery)
local game_ptr, game, runtime_image_size, last_report
local G = {}      -- resolved addresses (numbers) and layouts

local function addr(n) return ffi.cast(U8, ffi.cast('uintptr_t', n)) end
local function num(p) return tonumber(ffi.cast('uintptr_t', p)) end
local function read(a, size)
    if a == nil or a == 0 or size <= 0 or size > 0x100000 then return nil end
    local buffer, count = ffi.new('uint8_t[?]', size), ffi.new('size_t[1]')
    if kernel.ReadProcessMemory(process, addr(a), buffer, size, count) == 0 or count[0] ~= size then return nil end
    return ffi.string(buffer, size)
end
local function u32s(bytes, o)
    if not bytes or o < 0 or o + 4 > #bytes then return nil end
    local a, b, c, d = bytes:byte(o + 1, o + 4)
    return a + b * 256 + c * 65536 + d * 16777216
end
local function i32s(bytes, o)
    local v = u32s(bytes, o)
    if not v then return nil end
    return v >= 0x80000000 and v - TWO32 or v
end
local function f32s(bytes, o)
    if not bytes or o < 0 or o + 4 > #bytes then return nil end
    local box = ffi.new('float[1]')
    ffi.copy(box, bytes:sub(o + 1, o + 4), 4)
    return tonumber(box[0])
end
-- plausible user-mode pointer or nil
local function ptrs(bytes, o)
    local lo, hi = u32s(bytes, o), u32s(bytes, o + 4)
    if not lo or not hi then return nil end
    if hi >= 0x8000 or (hi == 0 and lo < 0x10000) then return nil end
    return hi * TWO32 + lo
end
local function r32(a) return u32s(read(a, 4), 0) end
local function rq(a) return ptrs(read(a, 8), 0) end
local function rf(a) return f32s(read(a, 4), 0) end
local function rb(a) local b = read(a, 1); return b and b:byte(1) end
local function type_key(rec)
    local b = read(rec, 0x18)
    if not b then return nil end
    return string.format('%08X%08X', u32s(b, 4), u32s(b, 0)), u32s(b, 8), u32s(b, 12), u32s(b, 0x14)
end
local LOG_KEYS = {
    'revision', 'build', 'build_mode', 'version_warning', 'phase', 'status', 'module_fingerprint', 'globals',
    'compatibility_scan_offset', 'compatibility_hits', 'frames', 'passes', 'towers', 'arc_holds',
    'arc_bits_cleared', 'arc_bits_restored', 'tower_weapon', 'heal_probe', 'ammo_probe', 'sentry_probe',
    'vehicles_in_range', 'sentries_in_range', 'heal_calls', 'full_skips', 'ammo_fill_calls', 'ammo_mag_calls', 'ammo_skip_non_authority',
    'ammo_native_nochange', 'client_ammo_writes', 'direct_ammo_hits', 'direct_ammo_probe', 'dynamic_sentry_roots',
    'wheel_types_learned', 'wheels_learned', 'wheels_fixed', 'wheel_skips', 'legs_fixed',
    'arms_revived', 'arms_mended', 'shield_plates_fixed', 'arm_scan_hits', 'arm_skips', 'last_part',
    'last_heal', 'last_ammo', 'last_wheel', 'native_calls', 'errors', 'stopped',
}
local function write_reports(force)
    if not force and last_report == state.status then return end
    last_report = state.status
    pcall(function()
        local log = loader.open_log and loader.open_log('SentryAmmoModelScanner.log')
        if log then
            for _, key in ipairs(LOG_KEYS) do log:write(key .. '=' .. tostring(state[key]) .. '\n') end
            log:close()
        end
        local st = loader.open_log and loader.open_log('SentryAmmoModelScanner_STATUS.log')
        if st then
            local prefix = state.phase == 'steady' and 'OK' or state.phase == 'rejected' and 'FAILED' or 'WAITING'
            st:write(prefix .. ' - ' .. state.status .. '\nrevision=' .. state.revision .. '\nbuild_mode='
                .. state.build_mode .. '\nversion_warning=' .. state.version_warning .. '\n')
            st:close()
        end
    end)
end
local function reject(reason)
    state.phase, state.status, state.stopped = 'rejected', reason, true
    write_reports(true)
end

-- ---------------------------------------------------------------------------------------
-- Derivation from pattern hits (a = absolute address of each pattern start).
local function bytes_at(a, list)
    local b = read(a, #list)
    if not b then return false end
    for i = 1, #list do if b:byte(i) ~= list[i] then return false end end
    return true
end
local function riprel(a, disp_off, insn_len)
    local d = i32s(read(a + disp_off, 4), 0)
    if not d then return nil end
    return a + insn_len + d
end
local function need(c, msg) if not c then error(msg, 0) end end

local function derive(H)
    local R = {}
    -- Health manager + HEAL (0x91E920) via the repair-drone wrapper that tail-jumps to it
    local hd = H.HEALDRV
    need(bytes_at(hd + 0x09, {0x4C, 0x8B, 0x1D}), 'HEALDRV+9')
    R.health = riprel(hd + 0x09, 3, 7)
    local tbl = r32(hd + 0x56)
    local hp = {tbl = tbl, cap = r32(hd + 0x1E), mult = r32(hd + 0x2D), empty = r32(hd + 0x4A)}
    need(tbl and hp.cap == tbl + 8 and hp.empty == tbl + 12 and hp.mult == tbl + 16, 'health layout')
    need(bytes_at(hd + 0xA1, {0xE9}), 'HEALDRV tail jmp')
    R.heal = riprel(hd + 0xA1, 1, 5)
    need(bytes_at(R.heal, {0x48, 0x8B, 0xC4, 0x48, 0x89, 0x58, 0x10}), 'HEAL prologue')
    need(bytes_at(R.heal + 0xBB, {0x49, 0x8B, 0xCC}) and bytes_at(R.heal + 0xC2, {0xE8}), 'HEAL cfg call')
    R.hcfg = riprel(R.heal + 0xC2, 1, 5)
    need(bytes_at(R.heal + 0xCB, {0x4D, 0x69, 0xED}), 'HEAL row stride')
    hp.stride = r32(R.heal + 0xCE)
    need(hp.stride and hp.stride >= 0x19C + 4 and hp.stride < 0x1000, 'health stride')
    R.hp = hp
    -- WeaponMagazine + fill current magazine (0x76E080)
    local rs = H.RESUP
    need(bytes_at(rs + 0x24, {0x48, 0x8B, 0x3D}), 'RESUP+24')
    R.wmag = riprel(rs + 0x24, 3, 7)
    R.wm = {cap = rb(rs + 0x33), mult = rb(rs + 0x37), tbl = rb(rs + 0x4E), empty = rb(rs + 0x56), recs = rb(rs + 0x92)}
    need(bytes_at(rs + 0xEA, {0x45, 0x33, 0xC0, 0x8B, 0xD3, 0xE8}), 'RESUP fill call')
    R.fill = riprel(rs + 0xEF, 1, 5)
    -- spare magazines (0x76E830) + magazine config (0x4F3740)
    local am = H.ADDMAG
    R.addmag = am
    need(bytes_at(am + 0x85, {0x48, 0x8B, 0xCF, 0xE8}), 'ADDMAG cfg call')
    R.magcfg = riprel(am + 0x88, 1, 5)
    need(bytes_at(am + 0x95, {0x48, 0x8B, 0x4D}), 'ADDMAG rows')
    R.wm.rows = rb(am + 0x98)
    -- stat modifier (exosuit leg speed)
    local sm = H.STATMOD
    R.statmod = riprel(sm + 0x08, 3, 7)
    R.sm = {cap = rb(sm + 0x1E), mult = rb(sm + 0x24), tbl = rb(sm + 0x44), empty = rb(sm + 0x48), rows = rb(sm + 0x85)}
    need(bytes_at(sm + 0x86, {0x48, 0x6B, 0xD1, 0x0D}), 'STATMOD stride')
    -- wheels: component query table [0x3326310] and VehicleApi [0x3326320]
    local wh = H.WHEEL
    need(bytes_at(wh + 0xB3, {0x4C, 0x8B, 0x0D}), 'WHEEL comp table')
    R.comp_tbl = riprel(wh + 0xB3, 3, 7)
    need(bytes_at(wh + 0xBA, {0x4C, 0x8D, 0x44, 0x24, 0x50, 0x8B, 0x4B, 0x0C, 0xBA, 0x10, 0x00, 0x00, 0x00}), 'WHEEL comp args')
    need(bytes_at(wh + 0xCD, {0x48, 0x8B, 0x4C, 0x24, 0x70}), 'WHEEL comp result')
    need(bytes_at(wh + 0xEB, {0x48, 0x8B, 0x05}), 'WHEEL vapi')
    R.vapi = riprel(wh + 0xEB, 3, 7)
    need(bytes_at(wh + 0xFC, {0xFF, 0x50}) and bytes_at(wh + 0x173, {0xFF, 0x50}), 'WHEEL get/set slots')
    R.vget_slot, R.vset_slot = rb(wh + 0xFE), rb(wh + 0x175)
    need(R.vapi == riprel(wh + 0x114, 3, 7), 'WHEEL vapi twice')
    -- Mount (vehicle weapon slots)
    local mr = H.MOUNTRS
    need(bytes_at(mr + 0x1E, {0x48, 0x8B, 0x3D}), 'MOUNTRS+1E')
    R.mount = riprel(mr + 0x1E, 3, 7)
    R.mo = {cap = rb(mr + 0x2C), mult = rb(mr + 0x32), tbl = rb(mr + 0x42), empty = rb(mr + 0x45), rows = rb(mr + 0x8A)}
    -- world API: [[G]+wapi1]+wapi2 (unit, 0) -> world matrix (translation +0x30)
    local wa = H.WAPI
    R.wapi = riprel(wa + 0x12, 3, 7)
    R.wapi1, R.wapi2 = rb(wa + 0x1C), r32(wa + 0x24)
    -- Unit component (membership check before asking for a world position)
    local un = H.UNIT
    R.unit = riprel(un + 0x0A, 3, 7)
    R.un = {cap = rb(un + 0x1C), mult = rb(un + 0x23), tbl = 0x40, empty = 0x4C}
    -- Attachable (weapon -> vehicle parent chain)
    local at = H.ATT
    R.att = riprel(at + 0x1A, 3, 7)
    R.at = {cap = rb(at + 0x26), mult = rb(at + 0x2D), tbl = rb(at + 0x3D), empty = rb(at + 0x41),
            stride = r32(at + 0x97), rows = rb(at + 0x9E)}
    need(R.at.stride and R.at.stride > 0 and R.at.stride < 0x1000, 'attachable stride')
    -- ArcWeapon (Tesla tower)
    local ar = H.ARC
    R.arc = riprel(ar + 0x0A, 3, 7)
    R.ar = {cap = rb(ar + 0x1D), mult = rb(ar + 0x29), tbl = rb(ar + 0x48), empty = rb(ar + 0x4C), rows = rb(ar + 0x8E)}
    need(R.ar.rows == BUILD.arc.recs + 0x10, 'arc rows offset')
    -- Weapon manager (row type bits; generic fire 0x741DF0 dispatches on them)
    local wp = H.WPN
    R.weapon = riprel(wp + 0x0A, 3, 7)
    R.wp = {cap = rb(wp + 0x16), mult = rb(wp + 0x1C), tbl = rb(wp + 0x2D), empty = rb(wp + 0x30)}
    need(bytes_at(wp + 0x70, {0x48, 0x8B, 0x76}), 'WPN rows load')
    R.wp.rows = rb(wp + 0x73)
    need(R.wp.tbl == 0x28 and R.wp.cap == 0x30 and R.wp.rows == 0x50, 'weapon layout')
    return R
end

local function bind(R)
    for k, v in pairs(R) do G[k] = v end
    state.globals = string.format('health=0x%X;wmag=0x%X;mount=0x%X;arc=0x%X;vapi=0x%X;heal=0x%X',
        R.health - game, R.wmag - game, R.mount - game, R.arc - game, R.vapi - game, R.heal - game)
end

local ok_gate, gate_error = pcall(function()
    game_ptr = kernel.GetModuleHandleA('game.dll')
    need(game_ptr ~= nil, 'game.dll unavailable')
    game = num(game_ptr)
    local dos = read(game, 0x100)
    need(dos and dos:sub(1, 2) == 'MZ', 'game.dll MZ signature missing')
    local pe_offset = u32s(dos, 0x3C)
    need(pe_offset and pe_offset >= 0x40 and pe_offset <= 0x1000, 'game.dll PE offset rejected')
    local pe = read(game + pe_offset, 0x100)
    need(pe and pe:sub(1, 4) == 'PE\0\0' and u32s(pe, 24) % 65536 == 0x20B, 'game.dll PE32+ identity rejected')
    local timestamp, image_size = u32s(pe, 8), u32s(pe, 24 + 56)
    runtime_image_size = image_size
    state.module_fingerprint = string.format('timestamp=0x%08X;size=0x%X', timestamp, image_size)
    if timestamp == BUILD.pe_timestamp and BUILD.accepted_image_sizes[image_size] then
        local H, all = {}, true
        for _, k in ipairs(BUILD.ORDER) do
            local p = BUILD.P[k]
            local b = read(game + p.rva, #p.mask)
            if b and masked_match(b, 1, p.mask) then H[k] = game + p.rva else all = false end
        end
        if all then
            local ok, R = pcall(derive, H)
            if ok then bind(R); state.build_mode = 'exact'; return end
            state.version_warning = 'timestamp matches but derivation failed: ' .. tostring(R)
        else
            state.version_warning = 'timestamp matches ' .. BUILD.file_version .. ' but recorded locators failed'
        end
    else
        state.version_warning = 'game.dll differs from ' .. BUILD.file_version .. ': ' .. state.module_fingerprint
    end
    state.build_mode = 'compatibility'
    state.phase, state.status = 'compatibility_search', 'version_mismatch_scanning_locators'
end)
if not ok_gate then reject(tostring(gate_error)); return end

-- Chunked read-only compatibility scan: one 256 KiB chunk per frame; every pattern must hit once.
local compat = {offset = 0, hits = {}}
for _, k in ipairs(BUILD.ORDER) do
    local p = BUILD.P[k]
    compat.hits[k] = {}
    -- anchor = longest run of fixed bytes at the start of the pattern
    local i, s = 1, {}
    while i <= #p.mask and p.mask[i] >= 0 and #s < 8 do s[#s + 1] = string.char(p.mask[i]); i = i + 1 end
    p.anchor = table.concat(s)
end
local function compatibility_scan_step()
    if compat.offset >= runtime_image_size then
        local parts, H, ok = {}, {}, true
        for _, k in ipairs(BUILD.ORDER) do
            local n = #compat.hits[k]
            parts[#parts + 1] = k .. '=' .. n
            if n ~= 1 then ok = false else H[k] = game + compat.hits[k][1] end
        end
        state.compatibility_hits = table.concat(parts, ';')
        compat.offset = math.huge
        if not ok then
            state.phase, state.status = 'waiting_read_only', 'compatibility_locators_not_unique'
            write_reports(true); return
        end
        local good, R = pcall(derive, H)
        if not good then
            state.phase, state.status = 'waiting_read_only', 'compatibility_derivation_rejected:' .. tostring(R)
            write_reports(true); return
        end
        bind(R)
        state.phase, state.status = 'waiting_for_scene', 'version_warning_compatibility_ready'
        write_reports(true)
        return
    end
    local chunk, overlap = 0x40000, 256
    local size = math.min(chunk + overlap, runtime_image_size - compat.offset)
    local bytes = read(game + compat.offset, size)
    if bytes then
        for _, k in ipairs(BUILD.ORDER) do
            local p, cursor = BUILD.P[k], 1
            while true do
                local found = bytes:find(p.anchor, cursor, true)
                if not found or found > chunk then break end
                if masked_match(bytes, found, p.mask) then
                    local rva, list = compat.offset + found - 1, compat.hits[k]
                    if list[#list] ~= rva then list[#list + 1] = rva end
                end
                cursor = found + 1
            end
        end
    end
    compat.offset = compat.offset + chunk
    state.compatibility_scan_offset = compat.offset
end

-- ---------------------------------------------------------------------------------------
local function map_of(mgr, L)
    local tbl, cap, empty, mult = rq(mgr + L.tbl), r32(mgr + L.cap), r32(mgr + L.empty), r32(mgr + L.mult)
    if not tbl or not cap or cap < 1 or cap > 0x100000 or not empty or not mult then return nil end
    return {tbl = tbl, cap = cap, empty = empty, mult = mult}
end
local function find_row(mgr, L, id)
    local m = mgr and map_of(mgr, L)
    if not m then return nil end
    return probe_map(id, m.cap, m.empty, m.mult, function(i)
        local s = read(m.tbl + i * 8, 8)
        if not s then return nil end
        return u32s(s, 0), u32s(s, 4)
    end)
end
-- iterate (id,row) of a manager map
local function each_entry(mgr, L, fn)
    local m = map_of(mgr, L)
    if not m then return false end
    local entries = read(m.tbl, m.cap * 8)
    if not entries then return false end
    for i = 0, m.cap - 1 do
        local id, row = u32s(entries, i * 8), u32s(entries, i * 8 + 4)
        if id ~= m.empty and row ~= 0xFFFFFFFF then fn(id, row) end
    end
    return true
end
local function health_rows(hm, row)
    local hp, H = G.hp, BUILD.hp
    local rows, row28 = rq(hm + hp.tbl + H.rows_from_tbl), rq(hm + hp.tbl + H.row28_from_tbl)
    if not rows or not row28 then return nil end
    return rows + row * hp.stride, row28 + row * H.row28_stride
end

local hd2=require('mods/skyeshade/hd2runtime')
local exe=num(kernel.GetModuleHandleA(nil))
local UNIT_PINS={{551541,"48890574969801"},{645327,"488b351a289701"},{645351,"25ffff3f00"},{645356,"3b8698000000"},{645370,"488b86a0000000"},{645377,"c1eb16"},{645380,"381c01"},{645385,"488b8688000000"},{645392,"488b1cc8"},{4225124,"ff92e8000000"},{4225137,"488b4828"},{4225141,"4883c130"}}
local unit_layout_ok=false
local function check_unit_layout()
    for _,pin in ipairs(UNIT_PINS) do
        local bytes=(pin[2]:gsub('..',function(h)return string.char(tonumber(h,16)) end))
        if read(exe+pin[1],#bytes)~=bytes then
            state.position_status='unit_layout_changed:'..string.format('%X',pin[1]);return false
        end
    end
    if read(exe+0x2BD870,5)~=string.char(0x48,0x8D,0x41,0x60,0xC3) then
        state.position_status='unit_accessor_changed';return false
    end
    state.position_status='generation_checked_read_only'
    return true
end
local function world_pos(unit)
    if not unit_layout_ok or not unit or unit==0 or unit==0xFFFFFFFF then return nil end
    local registry=rq(exe+0x1A100F0)
    if not registry then return nil end
    local count=r32(registry+0x98)
    local gens,objects=rq(registry+0xA0),rq(registry+0x88)
    local index,generation=unit%4194304,math.floor(unit/4194304)%256
    if not count or count>4194304 or index>=count or not gens or not objects or rb(gens+index)~=generation then return nil end
    local object=rq(objects+index*8)
    if not object or r32(object+8)~=unit then return nil end
    local vtable=rq(object)
    if not vtable or rq(vtable+0xE8)~=exe+0x2BD870 then return nil end
    local poses=rq(object+0x88)
    local b=poses and read(poses+0x30,12)
    if not b or rq(exe+0x1A100F0)~=registry or rb(gens+index)~=generation
        or rq(objects+index*8)~=object or r32(object+8)~=unit then return nil end
    local p={x=f32s(b,0),y=f32s(b,4),z=f32s(b,8)}
    if not p.x or not p.y or not p.z or p.x~=p.x or p.y~=p.y or p.z~=p.z
        or math.abs(p.x)>100000 or math.abs(p.y)>100000 or math.abs(p.z)>100000 then return nil end
    return p
end
local function read_available_heat(_)
    state.heat_status='unproven_runtime_field'
    return nil
end
local function read_rounds(_)
    state.rounds_status='unproven_runtime_field'
    return nil,nil
end
local MODEL_TITLE = '全部哨戒炮状态'
local MODEL_VERSION = '3.8.5-draft'
local MC = {
    enabled = true,
    max_distance = 110.0,
    scale = 0.36,
    height = 2.40,
    opacity = 70,
    low_color = true,
    scan_every = 6,
}

state.model_version = MODEL_VERSION
state.model_rows = 0
state.model_drawn = 0
state.model_status = 'starting'
state.model_error = 'none'
state.model_option_links = {}
state.model_world = nil
state.model_line = nil
state.model_line_created = 0
state.model_line_errors = 0
state.ac8_spatial_claims = 0
state.spatial_claims = 0
state.unowned_magazines = 0
state.unowned_detail = 'none'
state.render_mode = '3d_depth_tested_line_model'
state.last_model_diag = ''

local function model_log(message)
    state.model_status = tostring(message)
    pcall(function()
        local f = loader.open_log and loader.open_log('SentryAmmoModel.log')
        if f then
            f:write('version=' .. MODEL_VERSION .. '\n')
            f:write('status=' .. tostring(state.model_status) .. '\n')
            f:write('build_mode=' .. tostring(state.build_mode) .. '\n')
            f:write('rows=' .. tostring(state.model_rows or 0) .. '\n')
            f:write('drawn=' .. tostring(state.model_drawn or 0) .. '\n')
            f:write('render_mode=' .. tostring(state.render_mode) .. '\n')
            f:write('line_created=' .. tostring(state.model_line_created or 0) .. '\n')
            f:write('line_errors=' .. tostring(state.model_line_errors or 0) .. '\n')
            f:write('component_status=' .. tostring(state.component_status or 'none') .. '\n')
            f:write('roots=' .. tostring(state.root_detail or 'none') .. '\n')
            f:write('owned=' .. tostring(state.owned_detail or 'none') .. '\n')
            f:write('claims=entity:' .. tostring(state.claim_entity or 0) .. ',mount:' .. tostring(state.claim_mount or 0) .. ',unit:' .. tostring(state.claim_unit or 0) .. ',goid:' .. tostring(state.claim_goid or 0) .. ',spatial:' .. tostring(state.claim_spatial or 0) .. ',mount_fallback:' .. tostring(state.claim_mount_fallback or 0) .. ',feed_fallback:' .. tostring(state.claim_feed_fallback or 0) .. '\n')
            f:write('components=mag:' .. tostring(state.mag_components or 0) .. ',rounds:' .. tostring(state.round_components or 0) .. '\n')
            f:write('ac8_spatial_claims=' .. tostring(state.ac8_spatial_claims or 0) .. '\n')
            f:write('spatial_claims=' .. tostring(state.spatial_claims or 0) .. '\n')
            f:write('unowned_magazines=' .. tostring(state.unowned_magazines or 0) .. '\n')
            f:write('player_filtered=' .. tostring(state.player_filtered or 0) .. '\n')
            f:write('ac8_claims=' .. tostring(state.ac8_claims or 0) .. '\n')
            f:write('unowned_detail=' .. tostring(state.unowned_detail or 'none') .. '\n')
            f:write('opacity=' .. tostring(MC.opacity) .. '\n')
            f:write('join_phase='..tostring(state.join_phase)..'\n')
            f:write('config_status='..tostring(state.config_status)..'\n')
            f:write('position_status='..tostring(state.position_status)..'\n')
            f:write('time_status='..tostring(state.time_status)..'\n')
            f:write('heat_status='..tostring(state.heat_status)..'\n')
            f:write('rounds_status='..tostring(state.rounds_status)..'\n')
            f:write('pending_values='..tostring(state.pending_values)..'\n')
            f:write('error=' .. tostring(state.model_error or 'none') .. '\n')
            f:close()
        end
    end)
end

pcall(function()
    local f = loader.open_log and loader.open_log('SentryAmmoModel_BOOT.log')
    if f then f:write('BOOT ' .. MODEL_VERSION .. ' - 3D model entry executed\n'); f:close() end
end)

-- Optional Mod Options Menu.
local OPTION_SPECS = {
    {key='enabled', id='codex.sentry_ammo_model.enabled', type='toggle', label='显示哨戒炮弹药模型',
     description='在哨戒炮上方生成真实的3D弹药标记模型。模型参与场景深度遮挡，不使用屏幕投影。', default=true},
    {key='max_distance', id='codex.sentry_ammo_model.distance', type='slider', label='最大显示距离（米）',
     description='超过此距离不生成弹药模型。', min=20,max=200,step=10,default=110},
    {key='scale', id='codex.sentry_ammo_model.scale', type='slider', label='3D标记大小',
     description='调整图标和数字模型的整体大小。调整战备图标和数字模型的整体大小。', min=0.10,max=1.2,step=0.05,default=0.36},
    {key='height', id='codex.sentry_ammo_model.height', type='slider', label='标记悬浮高度',
     description='调整3D弹药模型位于哨戒炮上方的高度。', min=1.0,max=4.0,step=0.1,default=2.4},
    {key='opacity', id='codex.sentry_ammo_model.opacity', type='slider', label='标记透明度（%）',
     description='调整3D标记透明度。数值越低越不挡视野。', min=0,max=100,step=5,default=70},
    {key='low_color', id='codex.sentry_ammo_model.low_color', type='toggle', label='低弹药变色',
     description='弹药低于50%时变黄，低于20%时变红。', default=true},
}

local function menu_step()
    local menu = rawget(_G, 'ModOptionsMenu')
    if type(menu) ~= 'table' or menu.api ~= 1 or type(menu.register_option) ~= 'function' or type(menu.get) ~= 'function' then return end
    local ver = tonumber(menu.version) or 1
    for _,spec in ipairs(OPTION_SPECS) do
        if state.model_option_links[spec.id] == nil then
            state.model_option_links[spec.id] = false
            if spec.type ~= 'slider' or ver >= 2 then
                local data = {type=spec.type,mod=MODEL_TITLE,label=spec.label,description=spec.description,default=spec.default}
                if spec.type == 'slider' then data.min,data.max,data.step = spec.min,spec.max,spec.step end
                local ok,accepted = pcall(menu.register_option, spec.id, data)
                if ok and accepted == true then
                    state.model_option_links[spec.id] = true
                    if type(menu.on_change) == 'function' then
                        local key = spec.key
                        pcall(menu.on_change, spec.id, function(v)
                            if (key == 'enabled' or key == 'low_color') and type(v) == 'boolean' then MC[key] = v
                            elseif key ~= 'enabled' and key ~= 'low_color' and type(v) == 'number' and v == v then MC[key] = v end
                        end)
                    end
                end
            end
        end
        if state.model_option_links[spec.id] then
            local ok,v = pcall(menu.get, spec.id)
            if ok then
                if (spec.key == 'enabled' or spec.key == 'low_color') and type(v) == 'boolean' then MC[spec.key] = v
                elseif spec.key ~= 'enabled' and spec.key ~= 'low_color' and type(v) == 'number' and v == v then MC[spec.key] = v end
            end
        end
    end
end

-- SDK game-time estimate for newly observed deployments. Never starts on a renderer/scanner sighting.
-- Existing towers, loading/join population and unproven native lifetime fields remain unknown.
local TESLA_TYPE='74599E56F72F9D7E'
local TESLA_LIFETIME=150
local deployment_timers={}
local deployment_subscriptions={}
local function cancel_deployment(entry)
    if entry and entry.timer then pcall(entry.timer.cancel,entry.timer) end
end
local function clear_deployments()
    for _,entry in pairs(deployment_timers) do cancel_deployment(entry) end
    deployment_timers={}
end
local function deployment_spawned(event)
    if event.type~=TESLA_TYPE or not event.entity or not event.entity_id or not event.unit_id then return end
    if state.join_phase~='active' then state.time_status='deployment_ignored_during_join';return end
    local epoch,mission=hd2.events.mission_id()
    if not mission or epoch~=event.mission then return end
    local previous=deployment_timers[event.entity_id]
    if previous and previous.unit==event.unit_id and previous.epoch==epoch then
        local ok,valid=pcall(previous.entity.is_valid,previous.entity)
        if ok and valid then return end
    end
    cancel_deployment(previous)
    local entry={unit=event.unit_id,epoch=epoch,entity=event.entity,expired=false}
    local timer=hd2.after(TESLA_LIFETIME,function()
        if deployment_timers[event.entity_id]==entry then entry.expired=true end
    end,{scope='mission',id='sentry_tesla_'..tostring(event.entity_id)})
    if not timer or timer.state~='active' then
        deployment_timers[event.entity_id]=nil
        state.time_status='deployment_timer_rejected';return
    end
    entry.timer=timer
    deployment_timers[event.entity_id]=entry
    state.time_status='estimated_from_deployment;total_lifetime=150'
end
local function deployment_died(event)
    if event.type~=TESLA_TYPE then return end
    local entry=deployment_timers[event.entity_id]
    if entry and entry.unit==event.unit_id and entry.epoch==event.mission then
        cancel_deployment(entry);deployment_timers[event.entity_id]=nil
    end
end
local function start_deployment_tracker()
    if not hd2.events or type(hd2.events.on)~='function' or type(hd2.events.mission_id)~='function'
        or type(hd2.after)~='function' then state.time_status='deployment_events_unavailable';return end
    local registrations={
        {'mission_started',clear_deployments,'sentry_deployment_begin'},
        {'mission_ended',clear_deployments,'sentry_deployment_end'},
        {'entity_spawned',deployment_spawned,'sentry_deployment_spawn'},
        {'entity_died',deployment_died,'sentry_deployment_death'},
    }
    for _,registration in ipairs(registrations) do
        local ok,sub=pcall(hd2.events.on,registration[1],registration[2],{id=registration[3]})
        if not ok or not sub or sub.state~='active' then
            for _,s in ipairs(deployment_subscriptions) do pcall(s.unsubscribe,s) end
            deployment_subscriptions={}
            state.time_status='deployment_subscription_failed';return
        end
        deployment_subscriptions[#deployment_subscriptions+1]=sub
    end
    state.time_status='waiting_for_new_deployment;estimate=150s_game_time'
end
local function stop_deployment_tracker()
    clear_deployments()
    for _,sub in ipairs(deployment_subscriptions) do pcall(sub.unsubscribe,sub) end
    deployment_subscriptions={}
end
local function read_deployment_timer(root)
    local entry=deployment_timers[root.id]
    if not entry or entry.unit~=root.unit then
        state.time_status='unknown_existing_or_missed_deployment';return nil
    end
    local epoch,mission=hd2.events.mission_id()
    local valid,alive=pcall(entry.entity.is_valid,entry.entity)
    if not mission or epoch~=entry.epoch or not valid or not alive then
        cancel_deployment(entry);deployment_timers[root.id]=nil
        state.time_status='deployment_identity_expired';return nil
    end
    local remaining
    if entry.expired then remaining=0
    else
        local ok,value=pcall(entry.timer.remaining,entry.timer)
        if ok and type(value)=='number' and value==value then remaining=value end
    end
    if remaining==nil then state.time_status='deployment_timer_unavailable';return nil end
    root.estimated=true
    state.time_status='estimated_from_deployment;total_lifetime=150'
    return math.max(0,math.min(TESLA_LIFETIME,remaining))
end
-- Read-only scanner. No raw game-function calls and no writes to gameplay memory.
local DEFENSIVE_ROOTS = {
    ['37CDE43876BA26BB']={kind='mg',mode='ammo'},
    ['EF85D6CF58E31D70']={kind='gatling',mode='ammo'},
    ['54D86057F5DACFB9']={kind='cannon',mode='ammo'},
    ['51A0812E3BCE2D74']={kind='mortar',mode='ammo'},
    ['37079568DC86E9C6']={kind='rocket',mode='ammo'},
    ['B2053A1838092F8B']={kind='ems',mode='ammo'},
    ['820CC3BAFE962858']={kind='flame',mode='ammo'},
    ['299C0D3DFD2F0994']={kind='gas',mode='ammo'},
    ['74599E56F72F9D7E']={kind='tesla',mode='time',duration=150},
    ['56070F36CFFFA8A8']={kind='laser',mode='heat'},
    ['0E977C49DB7604F9']={kind='hmg',mode='ammo'},
    ['2B11C9E4980EC479']={kind='at',mode='ammo'},
    ['0C8257D1C0255593']={kind='gl',mode='rounds'},
}
local function unhex(h)
    return (h:gsub('..',function(x) return string.char(tonumber(x,16)) end))
end
local STATIC_SCHEMAS = {
    mag={offset=528664,index=5,indices=540,records=271,stride=160,
        header='a3888dfb4c444c4401000000a3888dfb20cb00000100000000000000'},
    heat={offset=27493728,index=266,indices=58,records=30,stride=592,
        header='d91c984c4c444c4401000000d91c984c004900000100000000000000'},
    rounds={offset=5766096,index=117,indices=50,records=26,stride=136,
        header='721008664c444c440100000072100866f01000000100000000000000'},
}
local ENTITY_HEADER=unhex('70cac1804c444c440100000070cac18084d002000100000000000000')
local entity_scan={cursor=0x10000,base=nil,index={},last_check=0}
local function clear_static()
    entity_scan={cursor=0x10000,base=nil,index={},last_check=0}
end
local function static_scan_step()
    if entity_scan.base then
        if read(entity_scan.base,28)~=ENTITY_HEADER then clear_static() end
        return
    end
    local region=ffi.new('VstMemoryRegion[1]')
    for _=1,128 do
        local cursor=entity_scan.cursor
        if cursor>=0x7FFFFFFF0000 then entity_scan.cursor=0x10000;return end
        if query_region(addr(cursor),region,ffi.sizeof(region[0]))~=ffi.sizeof(region[0]) then
            entity_scan.cursor=0x10000;return
        end
        local r=region[0]
        local base,size=num(r.base),tonumber(r.size)
        if not base or not size or size<=0 or base+size<=cursor then entity_scan.cursor=0x10000;return end
        entity_scan.cursor=base+size
        if r.state==0x1000 and r.type==0x20000 and (r.protection==2 or r.protection==4)
            and base==num(r.allocation_base) and size==46616576 and read(base,28)==ENTITY_HEADER then
            entity_scan.base=base
            state.config_status='entity_definitions_found'
            return
        end
    end
    state.config_status='searching_entity_definitions'
end
local function static_record(component,key)
    local base,c=entity_scan.base,STATIC_SCHEMAS[component]
    if not base or not c then return nil end
    if read(base,28)~=ENTITY_HEADER then clear_static();return nil end
    local at=base+c.offset
    local framing=read(at-4,32)
    if not framing or u32s(framing,0)~=c.index or framing:sub(5,32)~=unhex(c.header) then
        state.config_status='component_framing_changed:'..component
        return nil
    end
    local mappings=entity_scan.index[component]
    if not mappings then
        framing=read(at-4,32+c.indices*16)
        if not framing then return nil end
        mappings={}
        for i=0,c.indices-1 do
            local o=32+i*16
            local k=string.format('%08X%08X',u32s(framing,o+4),u32s(framing,o))
            local j,flags=u32s(framing,o+8),u32s(framing,o+12)
            if not j or j>=c.records or flags~=0 or (k~='0000000000000000' and mappings[k]) then
                state.config_status='component_index_changed:'..component;return nil
            end
            if k~='0000000000000000' then mappings[k]={record=j,row=i} end
        end
        entity_scan.index[component]=mappings
    end
    local target=mappings[key]
    if not target then return nil end
    local entry=read(at+28+target.row*16,16)
    if not entry or string.format('%08X%08X',u32s(entry,4),u32s(entry,0))~=key
        or u32s(entry,8)~=target.record or u32s(entry,12)~=0 then
        entity_scan.index[component]=nil
        state.config_status='component_mapping_changed:'..component
        return nil
    end
    return read(at+28+c.indices*16+target.record*c.stride,c.stride)
end
local record_guards={}
local function reset_scanner()
    record_guards={}
end
local function stable_descriptor(tag,mgr,L,recs,id,row,rec,key,unit)
    if find_row(mgr,L,id)~=row or rq(recs+row*8)~=rec then return false end
    local k,i,u=type_key(rec)
    if k~=key or i~=id or u~=unit then return false end
    local token=tag..':'..id
    local g=record_guards[token]
    if not g or g.rec~=rec or g.key~=key or g.unit~=unit or g.frame~=state.frames-MC.scan_every then
        g={rec=rec,key=key,unit=unit,count=0};record_guards[token]=g
    end
    g.count=g.count+1;g.frame=state.frames
    return g.count>=3
end
local function collect_sentry_ammo()
    local roots,byunit={},{}
    state.mag_components,state.round_components=0,0
    state.pending_values=0
    local function add_root(id,key,unit)
        local spec=DEFENSIVE_ROOTS[key]
        if not spec then return nil end
        if roots[id] then return roots[id] end
        local p=world_pos(unit)
        if not p then return nil end
        local r={id=id,key=key,unit=unit,kind=spec.kind,mode=spec.mode,pos=p,
            remaining=0,maximum=0,parts=0,sources={}}
        roots[id]=r
        -- Only direct root identities may contribute a unit association.
        if not byunit[unit] then byunit[unit]=id elseif byunit[unit]~=id then byunit[unit]=false end
        return r
    end
    local hm=rq(G.health)
    local hrecs=hm and rq(hm+G.hp.tbl+BUILD.hp.recs_from_tbl)
    if hm and hrecs then
        each_entry(hm,G.hp,function(id,j)
            if j>=0x100000 then return end
            local rec=rq(hrecs+j*8)
            local key,rid,unit=type_key(rec)
            if rid~=id or not DEFENSIVE_ROOTS[key] then return end
            local healthrow=health_rows(hm,j)
            if not healthrow or r32(healthrow+BUILD.hp.state)~=0 then return end
            if stable_descriptor('hp',hm,G.hp,hrecs,id,j,rec,key,unit) then add_root(id,key,unit) end
        end)
    end
    local wm=rq(G.wmag)
    local wrecs=wm and rq(wm+G.wm.recs)
    local wrows=wm and rq(wm+G.wm.rows)
    local feeds={}
    if wm and wrecs and wrows then
        each_entry(wm,G.wm,function(id,j)
            if j>=0x100000 then return end
            local rec=rq(wrecs+j*8)
            local key,rid,unit=type_key(rec)
            if rid~=id or not key then return end
            if not stable_descriptor('mag',wm,G.wm,wrecs,id,j,rec,key,unit) then return end
            if DEFENSIVE_ROOTS[key] then add_root(id,key,unit) end
            feeds[#feeds+1]={id=id,key=key,unit=unit,j=j,rec=rec}
        end)
    end
    local mount_owner={}
    local mo=rq(G.mount)
    local morows=mo and rq(mo+G.mo.rows)
    if mo and morows then
        for id in pairs(roots) do
            local j=find_row(mo,G.mo,id)
            local b=j and read(morows+j*BUILD.mount.stride,BUILD.mount.slots*4)
            if b then
                for n=0,BUILD.mount.slots-1 do
                    local w=u32s(b,n*4)
                    if w and w~=0 and w~=0xFFFFFFFF then
                        if mount_owner[w]==nil then mount_owner[w]=id elseif mount_owner[w]~=id then mount_owner[w]=false end
                    end
                end
            end
        end
    end
    local am=rq(G.att)
    local amrows=am and rq(am+G.at.rows)
    local function owner_of(id,unit)
        local cur,seen=id,{}
        for _=1,24 do
            if roots[cur] then return roots[cur] end
            if mount_owner[cur] then return roots[mount_owner[cur]] end
            if seen[cur] then return nil end
            seen[cur]=true
            local j=am and amrows and find_row(am,G.at,cur)
            if j==nil then break end
            local parent=r32(amrows+j*G.at.stride)
            if not parent or parent==0 or parent==cur then break end
            cur=parent
        end
        local root=unit and byunit[unit]
        return root and roots[root] or nil
    end
    local seen_feeds={}
    for _,f in ipairs(feeds) do
        local root=owner_of(f.id,f.unit)
        if root and root.mode=='ammo' and not seen_feeds[f.id] then
            local cfg=static_record('mag',f.key)
            local b=read(wrows+f.j*BUILD.wm.stride,8)
            if cfg and b and rq(G.wmag)==wm and rq(wm+G.wm.rows)==wrows
                and rq(wrecs+f.j*8)==f.rec and find_row(wm,G.wm,f.id)==f.j then
                local cap,maxm=i32s(cfg,0x88),i32s(cfg,0x94)
                local mags,rounds=i32s(b,0),i32s(b,4)
                if cap and cap>0 and cap<=100000 and maxm and maxm>=0 and maxm<=10000
                    and mags and mags>=0 and mags<=100000 and rounds and rounds>=0 and rounds<=1000000 then
                    root.remaining=root.remaining+rounds+mags*cap
                    root.maximum=root.maximum+cap*(1+maxm)
                    root.parts=root.parts+1;seen_feeds[f.id]=true
                    root.sources[#root.sources+1]='mag:'..f.key
                    state.mag_components=state.mag_components+1
                end
            end
        end
    end
    local out,details,names={},{},{}
    for id,r in pairs(roots) do
        -- Runtime timer/heat readers are separately proven before they are enabled.
        if r.mode=='time' then r.remaining,r.maximum=read_deployment_timer(r),150
        elseif r.mode=='heat' then r.remaining,r.maximum=read_available_heat(r),100
        elseif r.mode=='rounds' then r.remaining,r.maximum=read_rounds(r)
        elseif r.parts==0 then r.remaining=nil end
        r.unknown=r.remaining==nil
        if r.unknown then state.pending_values=state.pending_values+1 end
        out[#out+1]=r
        names[#names+1]=string.format('%X:%s',id,r.key)
        details[#details+1]=string.format('%X:%s:%s %s/%s',id,r.key,r.kind,tostring(r.remaining),tostring(r.maximum))
    end
    table.sort(out,function(a,b)return a.id<b.id end)
    table.sort(names);table.sort(details)
    state.root_detail=#names>0 and table.concat(names,' | ') or 'none'
    state.owned_detail=#details>0 and table.concat(details,' | ') or 'none'
    state.component_status='read_only;mag='..state.mag_components..';pending='..state.pending_values
    return out
end
local sr = rawget(_G,'stingray') or rawget(_G,'s3d')

local function main_world()
    if not sr or not sr.Application or type(sr.Application.main_world) ~= 'function' then return nil end
    local ok,w = pcall(sr.Application.main_world)
    if ok then return w end
    return nil
end

local function release_model()
    if state.model_line and state.model_world and main_world()==state.model_world and sr and sr.World and type(sr.World.destroy_line_object) == 'function' then
        pcall(sr.World.destroy_line_object,state.model_world,state.model_line)
    end
    state.model_line = nil
    state.model_world = nil
end

local function ensure_model(world)
    if not sr or not sr.World or not sr.LineObject or type(sr.World.create_line_object) ~= 'function' then return false end
    if state.model_line and state.model_world == world then return true end
    release_model()
    local ok,line = pcall(sr.World.create_line_object,world,false)
    if not ok or not line then
        state.model_line_errors = state.model_line_errors + 1
        state.model_error = tostring(line)
        return false
    end
    state.model_world = world
    state.model_line = line
    state.model_line_created = state.model_line_created + 1
    return true
end

local function point(center,right,up,x,y,scale)
    return center + right*(x*scale) + up*(y*scale)
end
local function add_thick_line(line,color,center,right,up,x1,y1,x2,y2,scale,thick)
    local p1=point(center,right,up,x1,y1,scale)
    local p2=point(center,right,up,x2,y2,scale)
    sr.LineObject.add_line(line,color,p1,p2)
    local dx,dy=x2-x1,y2-y1
    local len=math.sqrt(dx*dx+dy*dy)
    if len>0.0001 then
        local ox,oy=-dy/len*thick,dx/len*thick
        sr.LineObject.add_line(line,color,point(center,right,up,x1+ox,y1+oy,scale),point(center,right,up,x2+ox,y2+oy,scale))
        sr.LineObject.add_line(line,color,point(center,right,up,x1-ox,y1-oy,scale),point(center,right,up,x2-ox,y2-oy,scale))
    end
end

local ICON_RES=64
local FONT_RES=48
local ICONS={["mg"]={["layers"]={{["rgb"]={102,148,80},["runs"]={11,18,31,11,37,56,12,18,35,12,39,56,13,21,37,13,40,56,14,25,38,14,41,56,15,27,39,15,42,56,16,29,40,16,43,56,17,29,41,17,44,56,18,27,42,19,25,43,20,25,43,21,27,44,22,29,44,23,29,45,24,27,45,25,25,45,26,25,45,27,27,46,28,29,46,29,29,46,30,27,46,31,25,46,32,21,46,33,18,46,34,18,46,46,18,46,47,17,47,48,16,48,49,15,49,50,14,50,51,13,51,52,12,52}},{["rgb"]={237,237,237},["runs"]={15,8,20,16,8,25,17,8,25,18,8,20,21,8,20,22,8,25,23,8,25,24,8,20,27,8,20,28,8,25,29,8,25,30,8,20}}}},["gatling"]={["layers"]={{["rgb"]={237,237,237},["runs"]={16,8,20,17,8,25,18,8,25,19,8,20,22,8,20,23,8,25,24,8,25,25,8,20,28,8,20,29,8,25,30,8,25,31,8,20,34,8,20,35,8,25,36,8,25,37,8,20,40,8,20,41,8,25,42,8,25,43,8,20}},{["rgb"]={102,148,80},["runs"]={11,18,31,11,37,56,12,18,35,12,39,56,13,18,37,13,40,56,14,21,38,14,41,56,15,25,39,15,42,56,16,27,40,16,43,56,17,29,41,17,44,56,18,29,42,19,27,43,20,25,43,21,25,44,22,27,44,23,29,45,24,29,45,25,27,45,26,25,45,27,25,46,28,27,46,29,29,46,30,29,46,31,27,46,32,25,46,33,25,46,34,27,46,37,27,42,38,25,42,39,25,42,40,27,42,41,29,42,42,29,42,43,27,42,46,18,46,47,17,47,48,16,48,49,15,49,50,14,50,51,13,51,52,12,52}}}},["cannon"]={["layers"]={{["rgb"]={237,237,237},["runs"]={17,8,17,17,20,25,18,8,16,18,19,26,19,8,15,19,18,26,20,8,14,20,17,26,21,8,13,21,16,26,22,8,12,22,15,25,25,8,17,25,20,25,26,8,16,26,19,26,27,8,15,27,18,26,28,8,14,28,17,26,29,8,13,29,16,26,30,8,12,30,15,25,33,8,17,33,20,25,34,8,16,34,19,26,35,8,15,35,18,26,36,8,14,36,17,26,37,8,13,37,16,26,38,8,12,38,15,25}},{["rgb"]={102,148,80},["runs"]={11,18,31,11,37,56,12,18,35,12,39,56,13,18,37,13,40,56,14,18,38,14,41,56,15,25,39,15,42,56,16,27,40,16,43,56,17,27,41,17,44,56,18,28,42,19,28,43,20,28,43,21,28,44,22,27,44,23,27,45,24,27,45,25,27,45,26,28,45,27,28,46,28,28,46,29,28,46,30,27,46,31,27,46,32,27,46,33,27,46,34,28,46,37,28,42,38,27,42,39,27,42,40,25,42,41,22,42,42,22,42,43,22,42,46,18,46,47,17,47,48,16,48,49,15,49,50,14,50,51,13,51,52,12,52}}}},["mortar"]={["layers"]={{["rgb"]={102,148,80},["runs"]={11,24,31,11,37,56,12,25,35,12,39,56,13,25,37,13,40,56,14,25,38,14,41,56,15,26,39,15,42,56,16,26,40,16,43,56,17,26,41,17,44,56,18,27,42,19,27,43,20,27,43,21,28,44,22,28,44,23,28,45,24,28,45,25,27,45,26,27,45,27,27,46,28,26,46,29,26,46,30,26,46,31,25,46,32,25,46,33,25,46,34,24,46,37,24,42,38,24,42,39,25,42,40,26,42,41,27,42,42,27,42,43,27,42,46,27,46,47,27,47,48,27,48,49,15,49,50,14,50,51,13,51,52,12,52}},{["rgb"]={237,237,237},["runs"]={11,19,22,12,19,22,13,18,23,14,18,23,15,18,23,16,17,24,17,17,24,18,17,24,19,16,25,20,16,25,21,16,25,22,15,26,23,15,26,24,15,26,25,16,25,26,16,25,27,16,25,28,17,24,29,17,24,30,17,24,31,18,23,32,18,23,33,18,23,34,19,22,35,19,22,36,19,22,37,19,22,38,19,22,39,18,23,40,17,24,41,16,25,42,16,25,43,16,25,44,16,25,45,16,25,46,16,25}}}},["ems"]={["layers"]={{["rgb"]={102,148,80},["runs"]={11,24,31,11,37,56,12,25,35,12,39,56,13,25,37,13,40,56,14,25,38,14,41,56,15,26,39,15,42,56,16,26,40,16,43,56,17,26,41,17,44,56,18,27,42,19,27,43,20,27,43,21,28,44,22,28,44,23,28,45,24,28,45,25,27,45,26,27,45,27,27,46,28,26,46,29,26,46,30,26,46,31,25,46,32,25,46,33,25,46,34,24,46,37,24,42,38,24,42,39,25,42,40,26,42,41,27,42,42,27,42,43,27,42,46,27,46,47,27,47,48,27,48,49,15,49,50,14,50,51,13,51,52,12,52}},{["rgb"]={237,237,237},["runs"]={11,19,22,12,19,22,13,18,23,14,18,23,15,18,23,16,17,24,17,17,24,18,17,24,19,16,25,20,16,25,21,16,25,22,15,26,23,22,26,24,21,26,25,21,25,26,20,25,27,19,25,28,19,24,29,18,24,30,17,24,31,18,23,32,18,23,33,18,23,34,19,22,35,19,22,36,19,22,37,19,22,38,19,22,39,18,23,40,17,24,41,16,25,42,16,25,43,16,25,44,16,25,45,16,25,46,16,25}},{["rgb"]={255,255,255},["runs"]={16,14,15,17,13,15,18,13,14,19,12,14,20,11,14,21,11,14,22,10,13,23,9,13,24,9,13,25,8,18,26,7,18,27,13,17,28,12,16,29,12,15,30,12,15,31,12,14,32,11,13,33,11,13,34,11,12,36,10,11}}}},["rocket"]={["layers"]={{["rgb"]={237,237,237},["runs"]={18,25,32,19,24,32,20,23,32,21,22,32,22,21,32,23,20,32,24,19,32,25,14,31,26,13,30,27,12,29,28,11,28,29,10,27,30,9,26,31,8,25,32,18,25,33,18,25,34,10,14,34,18,25,35,9,13,35,18,25,36,8,12,36,15,16,36,18,24,37,14,16,37,18,23,38,13,16,38,18,22,39,13,16,39,18,21,40,13,15,40,18,20,41,13,14,41,18,19}},{["rgb"]={102,148,80},["runs"]={11,18,31,11,37,56,12,18,35,12,39,56,13,18,37,13,40,56,14,18,38,14,41,56,15,18,39,15,42,56,16,18,24,16,34,40,16,43,56,17,18,23,17,34,41,17,44,56,18,18,22,18,34,42,19,18,21,19,34,43,20,18,20,20,34,43,21,18,19,21,34,44,22,34,44,23,34,45,24,34,45,25,34,45,26,33,45,27,32,46,28,31,46,29,30,46,30,29,46,31,28,46,32,27,46,33,27,46,34,27,46,37,27,42,38,26,42,39,25,42,40,24,42,41,23,42,42,22,42,43,22,42,46,18,46,47,17,47,48,16,48,49,15,49,50,14,50,51,13,51,52,12,52}}}},["tesla"]={["layers"]={{["rgb"]={102,148,80},["runs"]={46,13,15,46,31,33,46,49,51,47,10,17,47,29,35,47,47,54,48,8,19,48,27,37,48,45,56,49,6,21,49,25,40,49,43,58,50,4,60,51,4,60,52,4,60,53,4,60,54,4,60,55,4,60,56,4,60,57,4,60,58,4,60,59,4,60}},{["rgb"]={237,237,237},["runs"]={9,33,34,10,32,33,11,32,33,12,31,33,13,30,33,14,29,32,15,29,32,16,28,36,17,27,36,18,32,35,19,32,34,20,31,34,21,31,33,22,22,25,22,31,32,22,39,42,23,22,25,23,30,31,23,39,42,24,22,25,24,30,31,24,39,42,25,22,25,25,39,42,26,22,25,26,31,33,26,39,42,27,22,25,27,31,33,27,39,42,28,22,25,28,31,33,28,39,42,29,22,25,29,31,33,29,39,42,30,22,25,30,31,33,30,39,42,31,22,25,31,30,34,31,39,42,32,22,25,32,29,35,32,39,42,33,22,25,33,29,35,33,39,42,34,22,25,34,29,35,34,39,42,35,22,25,35,29,35,35,39,42,36,22,25,36,29,35,36,39,42,37,22,42,38,22,42,39,22,42,40,22,42,41,21,43,42,21,43,43,20,44,44,20,30,44,34,44,45,19,28,45,36,45,46,20,26,46,38,44,47,22,24,47,40,42}}}},["flame"]={["layers"]={{["rgb"]={102,148,80},["runs"]={11,20,31,11,37,56,12,21,35,12,39,56,13,22,37,13,40,56,14,23,38,14,41,56,15,24,39,15,42,56,16,25,40,16,43,56,17,26,41,17,44,56,18,27,42,19,28,43,20,29,43,21,30,44,22,31,44,23,32,45,24,33,45,25,34,45,26,35,45,27,36,46,28,37,46,29,36,46,30,35,46,31,19,20,31,34,46,32,19,20,32,33,46,33,20,21,33,32,46,34,31,46,37,29,42,38,28,42,39,27,42,40,26,42,41,25,42,42,24,42,43,23,42,46,18,46,47,17,47,48,16,48,49,15,49,50,14,50,51,13,51,52,12,52}},{["rgb"]={237,237,237},["runs"]={13,18,19,14,18,20,15,18,21,16,18,22,17,18,23,18,18,24,19,18,25,20,17,26,21,16,26,22,15,26,23,14,26,23,28,29,24,13,26,24,27,30,25,12,31,26,11,21,26,22,32,27,10,20,27,22,33,28,10,19,28,22,34,29,10,19,29,22,33,30,10,18,30,22,32,31,10,17,31,22,31,32,10,16,32,24,30,33,11,17,33,24,29,34,12,18,34,23,29,35,13,19,35,23,28,36,14,19,36,23,27,37,15,19,37,23,26,38,16,19,38,23,25,39,18,19,39,23,24}}}},["laser"]={["layers"]={{["rgb"]={102,148,80},["runs"]={11,18,31,11,37,56,12,18,35,12,39,56,13,18,25,13,30,37,13,40,56,14,18,25,14,30,38,14,41,56,15,18,21,15,23,25,15,30,32,15,34,39,15,42,56,16,18,20,16,24,25,16,30,31,16,35,40,16,43,56,17,18,19,17,36,41,17,44,56,18,18,19,18,36,42,19,18,20,19,35,43,20,18,21,20,34,43,21,38,44,22,38,44,23,38,45,24,38,45,25,38,45,26,18,21,26,34,45,27,18,20,27,35,46,28,18,19,28,36,46,29,18,20,29,36,46,30,18,21,30,24,25,30,30,31,30,35,46,31,18,22,31,23,25,31,30,32,31,34,46,32,18,25,32,30,46,33,18,46,34,18,46,37,22,42,38,22,42,39,22,42,40,22,42,41,22,42,42,22,42,43,22,42,46,18,46,47,17,47,48,16,48,49,15,49,50,14,50,51,13,51,52,12,52}},{["rgb"]={237,237,237},["runs"]={15,27,28,16,27,28,17,22,23,17,27,28,17,32,33,18,21,24,18,27,28,18,31,34,19,22,25,19,30,33,20,23,24,20,27,29,20,31,32,21,25,30,22,25,31,23,6,31,23,32,36,24,24,31,25,25,30,26,23,24,26,26,29,26,31,32,27,22,25,27,30,33,28,21,24,28,27,28,28,31,34,29,22,23,29,27,28,29,32,33,30,27,28,31,27,28}}}},["gas"]={["layers"]={{["rgb"]={103,148,82},["runs"]={11,24,31,11,37,56,12,25,35,12,39,56,13,25,37,13,40,56,14,25,38,14,41,56,15,26,39,15,42,56,16,26,40,16,43,56,17,26,41,17,44,56,18,27,42,19,27,43,20,27,43,21,28,44,22,28,44,23,28,45,24,28,45,25,27,45,26,27,45,27,27,46,28,26,46,29,26,46,30,26,46,31,25,46,32,25,46,33,25,46,34,24,46,37,24,42,38,24,42,39,25,42,40,26,42,41,27,42,42,27,42,43,27,42,46,27,46,47,27,47,48,27,48,49,15,49,50,14,50,51,13,51,52,12,52}},{["rgb"]={237,237,237},["runs"]={11,19,22,12,19,22,13,18,23,14,18,23,15,18,23,16,11,18,16,20,24,17,10,19,17,20,24,18,9,19,18,21,24,19,9,20,19,21,25,20,9,20,20,22,25,21,8,10,21,18,21,21,22,25,22,8,10,22,18,21,22,22,26,23,8,10,23,18,21,23,22,26,24,8,11,24,13,16,24,18,21,24,22,26,25,8,14,25,15,21,25,22,25,26,9,12,26,13,20,26,21,25,27,10,14,27,15,19,27,20,25,28,11,12,28,13,18,28,19,20,28,21,24,29,8,10,29,11,14,29,15,20,29,22,24,30,9,12,30,13,16,30,17,19,30,21,24,31,10,12,31,16,18,31,20,23,32,11,13,32,16,17,32,19,23,33,18,23,34,19,22,35,19,22,36,19,22,37,19,22,38,19,22,39,18,23,40,17,24,41,16,25,42,16,25,43,16,25,44,16,25,45,16,25,46,16,25}}}},["hmg"]={["layers"]={{["rgb"]={237,237,237},["runs"]={11,10,13,12,9,14,13,8,15,14,8,15,15,8,15,16,9,14,16,21,33,17,10,13,17,21,38,18,21,39,19,6,17,19,21,39,20,6,17,20,21,38,21,6,17,21,21,33,22,6,17,23,6,17,24,6,17,24,21,33,25,6,17,25,21,38,26,6,17,26,21,39,27,6,17,27,21,39,28,6,17,28,21,38,29,6,17,29,21,33,30,6,17,31,6,17,32,6,17,33,6,17,34,6,17,35,6,17,36,6,17,37,8,15,38,8,15,39,8,15,40,8,15,41,8,15,42,8,15,43,8,15,44,8,15,45,8,15,46,8,15,47,8,15,48,8,15,49,8,15,50,8,15,51,8,15,52,8,15}},{["rgb"]={102,148,80},["runs"]={11,26,33,11,41,58,12,26,38,12,42,58,13,26,40,13,44,58,14,33,42,14,45,58,15,38,43,15,46,58,16,40,44,16,47,58,17,41,45,17,48,58,18,43,46,19,43,47,20,41,47,21,40,48,22,38,48,23,38,49,24,40,49,25,41,49,26,43,49,27,43,50,28,41,50,29,40,50,30,38,50,31,33,50,32,26,50,33,26,50,34,26,50,37,31,45,38,31,45,39,31,45,40,31,45,41,31,45,42,31,45,43,31,45,46,26,50,47,25,51,48,24,52,49,23,53,50,22,54,51,21,55,52,20,56}}}},["at"]={["layers"]={{["rgb"]={237,237,237},["runs"]={11,10,13,12,9,14,13,8,15,14,8,15,15,8,15,16,9,14,17,10,13,19,6,17,20,6,17,21,6,17,21,20,31,22,6,17,22,20,32,23,6,17,23,20,40,24,6,17,24,20,42,25,6,17,25,20,43,26,6,17,26,20,42,27,6,17,27,20,41,28,6,17,28,20,32,29,6,17,29,20,31,30,6,17,31,6,17,32,6,17,33,6,17,34,6,17,35,6,17,36,6,17,37,8,15,38,8,15,39,8,15,40,8,15,41,8,15,42,8,15,43,8,15,44,8,15,45,8,15,46,8,15,47,8,15,48,8,15,49,8,15,50,8,15,51,8,15,52,8,15}},{["rgb"]={102,148,80},["runs"]={11,26,33,11,41,58,12,26,38,12,42,58,13,26,40,13,44,58,14,26,42,14,45,58,15,26,43,15,46,58,16,26,44,16,47,58,17,26,45,17,48,58,18,26,46,19,32,47,20,33,47,21,42,48,22,43,48,23,44,49,24,46,49,25,47,49,26,46,49,27,44,50,28,43,50,29,42,50,30,33,50,31,32,50,32,26,50,33,26,50,34,26,50,37,31,45,38,31,45,39,31,45,40,31,45,41,31,45,42,31,45,43,31,45,46,26,50,47,25,51,48,24,52,49,23,53,50,22,54,51,21,55,52,20,56}}}},["gl"]={["layers"]={{["rgb"]={93,133,74},["runs"]={11,26,37,11,42,58,12,26,39,12,43,58,13,26,41,13,44,58,14,26,42,14,45,58,15,26,43,15,46,58,16,26,44,16,47,58,17,26,45,17,47,58,18,38,46,19,39,46,20,40,47,21,41,47,22,41,48,23,41,48,24,41,48,25,41,48,26,41,49,27,40,49,28,39,49,29,26,49,30,26,49,31,26,49,32,26,49,33,26,49,34,26,49,37,29,46,38,29,46,39,29,46,40,29,46,41,29,46,42,29,46,43,29,46,46,25,49,47,24,50,48,24,51,49,23,52,50,22,52,51,22,53,52,21,54}},{["rgb"]={237,237,237},["runs"]={11,9,13,12,8,14,13,8,14,14,7,14,15,8,14,16,8,14,17,9,13,19,6,16,19,19,23,20,5,16,20,19,29,20,30,38,21,5,16,21,19,29,21,30,39,22,5,16,22,19,29,22,30,40,23,5,16,23,19,29,23,30,40,24,5,16,24,19,29,24,30,40,25,5,16,25,19,29,25,30,39,26,5,16,26,19,29,26,30,39,27,5,16,27,19,29,27,30,38,28,5,16,28,19,23,29,5,16,30,5,16,31,5,16,32,5,16,33,5,16,34,5,16,35,5,16,36,6,16,37,7,15,38,7,14,39,7,14,40,7,14,41,7,14,42,7,14,43,7,14,44,7,14,45,7,14,46,7,14,47,7,14,48,7,14,49,7,14,50,7,14,51,7,14,52,8,14}}}}}
local GLYPHS={["0"]={["w"]=0.75,["runs"]={0,14,23,1,11,25,2,10,27,3,9,28,4,8,29,5,7,29,6,6,15,6,21,30,7,6,14,7,22,30,8,5,13,8,23,31,9,5,12,9,23,31,10,4,12,10,24,32,11,4,12,11,24,32,12,4,11,12,24,32,13,3,11,13,25,32,14,3,11,14,25,33,15,3,11,15,25,33,16,3,10,16,25,33,17,3,10,17,25,33,18,3,10,18,25,33,19,3,10,19,25,33,20,2,10,20,26,33,21,2,10,21,26,33,22,2,10,22,26,33,23,2,10,23,26,33,24,2,10,24,26,33,25,2,10,25,26,33,26,2,10,26,26,33,27,2,10,27,26,33,28,2,10,28,25,33,29,3,10,29,25,33,30,3,10,30,25,33,31,3,10,31,25,33,32,3,11,32,25,32,33,3,11,33,25,32,34,3,11,34,24,32,35,4,11,35,24,32,36,4,12,36,24,31,37,4,12,37,23,31,38,5,13,38,23,30,39,5,14,39,22,30,40,6,15,40,21,29,41,6,29,42,7,28,43,8,27,44,9,26,45,11,24,46,13,22}},["1"]={["w"]=0.5416666666666666,["runs"]={0,15,19,1,14,19,2,12,19,3,10,19,4,8,19,5,6,19,6,3,19,7,2,19,8,2,19,9,2,11,9,12,19,10,2,9,10,12,19,11,2,7,11,12,19,12,2,5,12,12,19,13,12,19,14,12,19,15,12,19,16,12,19,17,12,19,18,12,19,19,12,19,20,12,19,21,12,19,22,12,19,23,12,19,24,12,19,25,12,19,26,12,19,27,12,19,28,12,19,29,12,19,30,12,19,31,12,19,32,12,19,33,12,19,34,12,19,35,12,19,36,12,19,37,12,19,38,12,19,39,12,19,40,12,19,41,12,19,42,12,19,43,12,19,44,12,19,45,12,19}},["2"]={["w"]=0.75,["runs"]={0,12,22,1,9,24,2,7,26,3,6,27,4,5,28,5,5,29,6,5,13,6,19,29,7,5,10,7,21,30,8,5,8,8,22,30,9,5,7,9,22,30,10,5,6,10,23,30,11,23,31,12,23,31,13,23,31,14,23,30,15,23,30,16,22,30,17,22,30,18,22,30,19,21,29,20,20,29,21,19,28,22,18,27,23,17,27,24,16,26,25,15,25,26,13,24,27,12,22,28,11,21,29,10,20,30,9,19,31,8,18,32,7,16,33,6,15,34,5,14,35,5,13,36,4,12,37,4,12,38,4,11,39,3,11,40,3,31,41,3,31,42,3,31,43,3,31,44,3,31,45,3,31}},["3"]={["w"]=0.75,["runs"]={0,11,21,1,8,24,2,6,25,3,5,26,4,5,27,5,5,28,6,5,10,6,18,29,7,5,8,7,20,29,8,5,7,8,21,29,9,21,29,10,22,30,11,22,30,12,22,29,13,22,29,14,22,29,15,21,29,16,21,28,17,20,28,18,19,27,19,16,26,20,8,25,21,8,23,22,8,21,23,8,25,24,8,26,25,8,28,26,17,29,27,20,29,28,21,30,29,22,30,30,23,31,31,23,31,32,23,31,33,23,31,34,23,31,35,23,31,36,23,31,37,22,30,38,4,5,38,21,30,39,4,7,39,20,30,40,4,9,40,18,29,41,4,28,42,4,27,43,4,26,44,4,25,45,6,23,46,9,20}},["4"]={["w"]=0.7708333333333334,["runs"]={1,21,29,2,21,29,3,20,29,4,20,29,5,19,29,6,19,29,7,18,29,8,18,29,9,17,29,10,16,29,11,16,29,12,15,21,12,22,29,13,14,21,13,22,29,14,14,20,14,22,29,15,13,19,15,22,29,16,12,19,16,22,29,17,11,18,17,22,29,18,11,18,18,22,29,19,10,17,19,22,29,20,9,16,20,22,29,21,8,16,21,22,29,22,8,15,22,22,29,23,7,14,23,22,29,24,6,13,24,22,29,25,5,13,25,22,29,26,4,12,26,22,29,27,4,11,27,22,29,28,3,10,28,22,29,29,2,9,29,22,29,30,2,36,31,2,36,32,2,36,33,2,36,34,2,36,35,2,36,36,22,29,37,22,29,38,22,29,39,22,29,40,22,29,41,22,29,42,22,29,43,22,29,44,22,29,45,22,29}},["5"]={["w"]=0.75,["runs"]={1,7,29,2,7,29,3,7,29,4,7,29,5,7,29,6,7,29,7,7,13,8,7,13,9,7,13,10,6,13,11,6,13,12,6,13,13,6,13,14,6,13,15,6,13,16,6,13,17,6,13,18,6,21,19,6,24,20,6,26,21,6,27,22,6,28,23,6,29,24,17,30,25,20,30,26,21,31,27,22,31,28,23,31,29,23,31,30,24,31,31,24,31,32,24,31,33,24,31,34,24,31,35,23,31,36,23,31,37,22,31,38,5,6,38,21,30,39,5,8,39,20,30,40,5,10,40,18,29,41,5,28,42,5,27,43,5,26,44,5,25,45,5,23,46,8,20}},["6"]={["w"]=0.75,["runs"]={0,18,28,1,15,30,2,13,30,3,12,30,4,11,30,5,10,30,6,9,19,6,26,30,7,8,17,7,29,30,8,7,16,9,7,15,10,6,14,11,6,13,12,5,13,13,5,12,14,5,12,15,4,12,16,4,11,17,4,11,18,4,11,18,16,25,19,4,11,19,14,27,20,3,11,20,13,29,21,3,11,21,12,30,22,3,31,23,3,31,24,3,16,24,22,32,25,3,14,25,23,32,26,3,13,26,24,33,27,3,12,27,25,33,28,3,12,28,25,33,29,3,11,29,26,33,30,3,11,30,26,33,31,3,11,31,26,33,32,4,11,32,26,33,33,4,11,33,26,33,34,4,11,34,26,33,35,4,12,35,25,33,36,5,12,36,25,33,37,5,13,37,25,32,38,5,13,38,24,32,39,6,14,39,23,32,40,7,16,40,21,31,41,7,30,42,8,29,43,9,28,44,10,27,45,12,25,46,14,23}},["7"]={["w"]=0.7083333333333334,["runs"]={1,2,32,2,2,32,3,2,32,4,2,32,5,2,32,6,2,31,7,23,31,8,23,30,9,22,30,10,22,29,11,21,29,12,21,28,13,20,28,14,20,27,15,19,27,16,19,26,17,18,26,18,18,25,19,17,25,20,17,24,21,16,24,22,16,23,23,15,23,24,15,23,25,15,22,26,14,22,27,14,21,28,13,21,29,13,21,30,13,20,31,12,20,32,12,20,33,12,19,34,11,19,35,11,19,36,11,19,37,11,18,38,10,18,39,10,18,40,10,18,41,10,17,42,9,17,43,9,17,44,9,17,45,9,17}},["8"]={["w"]=0.75,["runs"]={0,13,22,1,11,25,2,9,26,3,8,28,4,7,29,5,6,29,6,5,15,6,21,30,7,5,13,7,22,30,8,5,13,8,23,31,9,4,12,9,23,31,10,4,12,10,24,31,11,4,12,11,24,31,12,4,12,12,24,31,13,4,12,13,24,31,14,5,12,14,24,31,15,5,12,15,23,30,16,5,13,16,22,30,17,6,14,17,22,29,18,7,16,18,20,29,19,8,28,20,9,26,21,10,25,22,8,27,23,7,28,24,6,17,24,18,29,25,5,14,25,22,30,26,5,13,26,23,31,27,4,12,27,24,31,28,4,11,28,24,32,29,3,11,29,25,32,30,3,10,30,25,32,31,3,10,31,25,33,32,3,10,32,26,33,33,3,10,33,25,33,34,3,10,34,25,33,35,3,10,35,25,33,36,3,11,36,25,33,37,3,11,37,24,32,38,4,12,38,24,32,39,4,13,39,23,31,40,5,14,40,21,31,41,5,30,42,6,29,43,7,28,44,9,27,45,10,25,46,13,22}},["9"]={["w"]=0.75,["runs"]={0,13,22,1,11,24,2,9,26,3,8,27,4,7,28,5,6,29,6,5,15,6,20,30,7,5,13,7,22,30,8,4,12,8,23,31,9,4,12,9,23,31,10,3,11,10,24,31,11,3,11,11,24,32,12,3,10,12,25,32,13,3,10,13,25,32,14,3,10,14,25,32,15,3,10,15,25,32,16,3,10,16,25,33,17,3,10,17,25,33,18,3,11,18,25,33,19,3,11,19,24,33,20,3,11,20,24,33,21,4,12,21,23,33,22,4,13,22,22,33,23,5,15,23,20,33,24,5,33,25,6,33,26,7,24,26,25,33,27,8,23,27,25,32,28,10,22,28,25,32,29,12,20,29,25,32,30,25,32,31,25,32,32,24,31,33,24,31,34,24,31,35,23,30,36,22,30,37,22,29,38,21,29,39,5,7,39,19,28,40,5,10,40,17,28,41,5,27,42,5,26,43,5,25,44,5,23,45,5,21,46,9,19}},[":"]={["w"]=0.3125,["runs"]={13,5,10,14,4,11,15,3,12,16,3,12,17,3,12,18,3,12,19,4,11,20,5,10,39,5,10,40,4,11,41,3,12,42,3,12,43,3,12,44,3,12,45,4,11,46,5,10}},["%"]={["w"]=1.125,["runs"]={0,10,18,1,8,20,1,38,43,2,6,21,2,38,42,3,5,22,3,37,42,4,5,22,4,36,41,5,4,10,5,16,23,5,36,41,6,3,9,6,17,23,6,35,40,7,3,9,7,18,24,7,35,39,8,3,8,8,18,24,8,34,39,9,3,8,9,18,24,9,33,38,10,3,8,10,19,24,10,33,37,11,3,8,11,19,24,11,32,37,12,3,8,12,19,24,12,31,36,13,3,8,13,18,24,13,31,35,14,3,8,14,18,24,14,30,35,15,3,9,15,18,23,15,29,34,16,3,9,16,17,23,16,29,34,17,4,10,17,16,23,17,28,33,18,4,12,18,14,22,18,28,32,19,5,21,19,27,32,20,6,20,20,26,31,21,7,19,21,26,30,22,9,17,22,25,30,23,24,29,24,24,28,24,36,44,25,23,28,25,34,46,26,22,27,26,33,47,27,22,27,27,32,48,28,21,26,28,31,49,29,21,25,29,30,37,29,43,49,30,20,25,30,30,36,30,44,50,31,19,24,31,29,35,31,44,50,32,19,23,32,29,35,32,45,50,33,18,23,33,29,35,33,45,50,34,17,22,34,29,34,34,45,50,35,17,21,35,29,34,35,45,50,36,16,21,36,29,34,36,45,50,37,15,20,37,29,34,37,45,50,38,15,19,38,29,35,38,45,50,39,14,19,39,29,35,39,44,50,40,14,18,40,30,36,40,44,49,41,13,18,41,30,36,41,43,49,42,12,17,42,31,39,42,41,48,43,12,16,43,31,48,44,11,16,44,32,47,45,10,15,45,33,45,46,36,43}},["-"]={["w"]=0.5416666666666666,["runs"]={26,4,22,27,4,22,28,4,22,29,4,22,30,4,22}},["~"]={["w"]=0.9166666666666666,["runs"]={22,12,19,22,33,38,23,10,21,23,33,38,24,9,23,24,32,38,25,8,25,25,32,38,26,8,27,26,31,37,27,7,15,27,17,37,28,7,13,28,20,36,29,7,12,29,21,36,30,6,12,30,23,35,31,6,12,31,25,33}}}
-- Glyphs are rasterized from Segoe UI Semibold; icons come from local game XAML.
local function draw_runs(line,center,right,up,scale,runs,res,width,color)
    for i=1,#runs,3 do
        local y=0.5-(runs[i]+0.5)/res
        local x1=runs[i+1]/res-width/2
        local x2=runs[i+2]/res-width/2
        add_thick_line(line,color,center,right,up,x1,y,x2,y,scale,0.32/res)
    end
end
local function text_width(text)
    local total=0
    for ch in text:gmatch('.') do
        local g=GLYPHS[ch]
        if g then total=total+g.w+0.075 end
    end
    return math.max(0,total-0.075)
end
local function add_text(line,text,center,right,up,scale,color)
    local x=-text_width(text)/2
    for ch in text:gmatch('.') do
        local g=GLYPHS[ch]
        if g then
            local c=center+right*((x+g.w/2)*scale)
            draw_runs(line,c,right,up,scale,g.runs,FONT_RES,g.w,color)
            x=x+g.w+0.075
        end
    end
end
local function marker_text(r)
    if r.remaining==nil then
        if r.mode=='time' then return '--:--' end
        if r.mode=='heat' then return '--%' end
        return '--'
    end
    if r.mode=='time' then
        local s=math.max(0,math.ceil(r.remaining))
        return (r.estimated and '~' or '')..string.format('%02d:%02d',math.floor(s/60),s%60)
    end
    if r.mode=='heat' then return tostring(math.floor(math.max(0,math.min(100,r.remaining))+0.5))..'%' end
    return tostring(math.max(0,math.floor(r.remaining+0.5)))
end
local ICON_FRAME_SEGMENTS = {
    {-0.56,0.38,-0.56,0.56}, {-0.56,0.56,-0.38,0.56},
    {0.38,0.56,0.56,0.56}, {0.56,0.56,0.56,0.38},
    {-0.56,-0.38,-0.56,-0.56}, {-0.56,-0.56,-0.38,-0.56},
    {0.38,-0.56,0.56,-0.56}, {0.56,-0.56,0.56,-0.38},
}
local function add_icon_frame(line,center,right,up,scale,alpha,status_color)
    local shadow=sr.Color(alpha*0.65,12,17,20)
    for _,segment in ipairs(ICON_FRAME_SEGMENTS) do
        add_thick_line(line,shadow,center,right,up,segment[1],segment[2],segment[3],segment[4],scale,0.020)
    end
    for _,segment in ipairs(ICON_FRAME_SEGMENTS) do
        add_thick_line(line,status_color,center,right,up,segment[1],segment[2],segment[3],segment[4],scale,0.010)
    end
end
local function add_original_icon(line,kind,center,right,up,scale,alpha,status_color)
    local icon=ICONS[kind]
    if not icon then return end
    add_icon_frame(line,center,right,up,scale,alpha,status_color)
    for _,layer in ipairs(icon.layers) do
        local rgb=layer.rgb
        draw_runs(line,center,right,up,scale,layer.runs,ICON_RES,1,sr.Color(alpha,rgb[1],rgb[2],rgb[3]))
    end
end
local function render_models(world)
    if not ensure_model(world) then state.model_drawn=0;return end
    local line=state.model_line
    sr.LineObject.reset(line)
    if not MC.enabled then sr.LineObject.dispatch(world,line);state.model_drawn=0;return end
    if not sr.World or type(sr.World.debug_camera_pose)~='function' or not sr.Matrix4x4 then return end
    local ok,pose=pcall(sr.World.debug_camera_pose,world)
    if not ok or not pose then return end
    local cam=sr.Matrix4x4.translation(pose)
    local right,up=sr.Matrix4x4.axis(pose,1),sr.Matrix4x4.axis(pose,3)
    local alpha=math.max(0,math.min(100,MC.opacity))*2.55
    local drawn=0
    for _,r in ipairs(state.live_ammo or {}) do
        local center=sr.Vector3(r.pos.x,r.pos.y,r.pos.z+MC.height)
        if sr.Vector3.distance(cam,center)<=MC.max_distance then
            local rr,gg,bb=240,243,246
            local ratio=r.remaining and r.maximum and r.maximum>0 and r.remaining/r.maximum
            if r.unknown then rr,gg,bb=164,172,182
            elseif MC.low_color and ratio and ratio<=0.2 then rr,gg,bb=255,86,75
            elseif MC.low_color and ratio and ratio<=0.5 then rr,gg,bb=255,209,67 end
            local text=marker_text(r)
            local icon_size,font_size=MC.scale*0.72,MC.scale*0.51
            local tw=text_width(text)*font_size
            local gap=MC.scale*0.20
            local width=icon_size+gap+tw
            local ic=center+right*(-width/2+icon_size/2)
            local nc=center+right*(width/2-tw/2)
            local status_color=sr.Color(alpha,rr,gg,bb)
            add_original_icon(line,r.kind,ic,right,up,icon_size,alpha,status_color)
            add_text(line,text,nc,right,up,font_size,status_color)
            drawn=drawn+1
        end
    end
    sr.LineObject.dispatch(world,line)
    state.model_drawn=drawn
end

pcall(ffi.cdef,'uint64_t GetTickCount64(void);')
local session={world=nil,wm=nil,hp=nil,since=nil}
local function clear_session(world,wm,hp,now)
    session={world=world,wm=wm,hp=hp,since=now}
    reset_scanner()
    release_model()
    state.live_ammo={};state.model_rows=0;state.model_drawn=0
end
local function model_tick()
    state.frames=state.frames+1
    if state.frames%30==0 then menu_step() end
    if not G.wmag then
        if state.build_mode=='compatibility' and compat.offset~=math.huge then compatibility_scan_step() end
        return
    end
    if not unit_layout_ok then
        unit_layout_ok=check_unit_layout()
        if not unit_layout_ok then
            if state.frames%120==0 then model_log(state.position_status) end
            return
        end
    end
    static_scan_step()
    if not sr then sr=rawget(_G,'stingray') or rawget(_G,'s3d') end
    local world=main_world()
    local game_state=hd2.game_state()
    local now=tonumber(kernel.GetTickCount64())
    local wm,hp=rq(G.wmag),rq(G.health)
    if not world or not wm or not hp or not game_state or not game_state.mission then
        clear_session(nil,nil,nil,now);state.join_phase='waiting_for_mission'
        if state.frames%120==0 then model_log('waiting_for_mission') end
        return
    end
    if world~=session.world or wm~=session.wm or hp~=session.hp then
        clear_session(world,wm,hp,now)
    end
    if now-session.since<8000 then state.join_phase='warmup';return end
    state.join_phase='active'
    if state.frames%MC.scan_every==0 then
        local ok,rows=pcall(collect_sentry_ammo)
        if ok then state.live_ammo=rows;state.model_rows=#rows;state.model_error='none'
        else state.live_ammo={};state.model_rows=0;state.model_error=tostring(rows);model_log('scan failed') end
    end
    local ok,err=pcall(render_models,world)
    if not ok then state.model_error=tostring(err);state.model_line_errors=state.model_line_errors+1;release_model();model_log('render failed') end
    if state.frames%120==0 then
        model_log(string.format('read_only;rows=%d drawn=%d pending=%d',state.model_rows or 0,state.model_drawn or 0,state.pending_values or 0))
    end
end
start_deployment_tracker()
local previous_update = rawget(_G,'update')
if type(previous_update) ~= 'function' then
    model_log('global update() unavailable')
    return state
end
local model_wrapper
local function after_update(...)
    if not state.model_failed then
        local ok,err = pcall(model_tick)
        if not ok then
            state.model_failed = true
            state.model_error = tostring(err)
            model_log('FAILED: ' .. tostring(err))
            pcall(release_model)
        end
    end
    return ...
end
model_wrapper = function(...) return after_update(previous_update(...)) end
_G.update = model_wrapper

local previous_shutdown = rawget(_G,'shutdown')
if type(previous_shutdown) == 'function' then
    _G.shutdown = function(...)
        pcall(stop_deployment_tracker)
        pcall(release_model)
        if rawget(_G,'update') == model_wrapper then _G.update = previous_update end
        return previous_shutdown(...)
    end
end

model_log('ready - ModBuilder project draft; 13 exact types; Tesla deployment estimate; heat/GL reads pending')
return state
end
addon()
return generated
