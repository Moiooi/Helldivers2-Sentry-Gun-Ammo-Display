# Sentry-Ammo-All-Draft

四角框略加粗并跟随数字按剩余量变色。新观察到的电塔部署按 150 游戏秒倒数，~ 标明估算；已有电塔时长未知。激光当前热量、榴弹炮台实时弹药尚未验证。

By Codex.

Requires Bingus Shared Loader v15+ / API 1 and HD2Runtime 0.28.1+ / API 1; install dependencies separately.

Install this gameplay ZIP through your mod manager after installing both dependencies.
