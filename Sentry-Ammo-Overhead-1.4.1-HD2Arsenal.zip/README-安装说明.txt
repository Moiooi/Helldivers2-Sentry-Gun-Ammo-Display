﻿炮塔头顶弹药显示 1.4.1-dev — HD2Arsenal 独立安装包

安装
1. 完全退出《HELLDIVERS 2》。
2. 将 Sentry-Ammo-Overhead-1.4.1-HD2Arsenal.zip 拖入 HD2Arsenal，或使用“导入模组”。
3. 导入新版时使用与旧版相同的模组标识，按管理器提示更新；将“炮塔头顶弹药显示 1.4.1”添加到当前配置文件，启用“炮塔弹药显示（完整）”。
4. 你当前的优先级设置为“第一个模组优先级最高”，请将此 MOD“移至顶部”。
5. 点击“部署模组”，完成后照常启动游戏。

这是一个独立 MOD，只有一个完整安装选项。
Core 中的两组补丁必须一起部署：主程序和图标资源、遮挡着色器资源。
不需要 Bingus Shared Loader、HD2Runtime 或额外启动器程序。
管理器会自动编号补丁；不要自行改成 patch_35/patch_36，也不要把文件直接复制到游戏 data 目录。
如有其他修改游戏启动脚本的 MOD，请让本 MOD 保持最高优先级。

显示
- 自动哨戒炮与可操控炮台头顶显示实际读取的剩余弹数。
- 原版配色图标去除黑色底板，增加半透明四角切角框。
- 数字在上、四格状态条在下；每格表示25%，数字与状态条同色。普通弹药和电塔剩余量>75%为白、>50%为绿、>25%为黄、<=25%为红。近距离放大，远距离保留可读尺寸。
- 数字、图标、装饰框和弹药条使用深度遮挡绘制。
- 普通炮塔显示实际读取的剩余弹数；四格条按这座炮塔已读取到的最高弹数计算比例。
- 激光塔显示 0% 至 100%：实际温度按250过热阈值计算百分比，热量从0%开始增加填条；0%-25%为白、>25%-50%为绿、>50%-75%为黄、>75%-100%为红。
- 电塔显示 M:SS 倒计时，秒数向上取整，从首次确认发现这座塔时按150秒递减。
- 本包为 1.4.1-dev，适配 Steam build 26088801。

卸载
在 HD2Arsenal 中禁用或从当前配置文件移除此 MOD，然后再次“部署模组”。
不使用旧的直接安装、迁移或卸载脚本。

诊断日志
%LOCALAPPDATA%\SentryAmmoLoader.log
%LOCALAPPDATA%\SentryAmmoLoader-journal.txt
成功加载时日志中会包含 version=1.4.1-dev。

包内容
manifest.json
Core/9ba626afa44a3aa3.patch_0
Core/9ba626afa44a3aa3.patch_0.stream
Core/9ba626afa44a3aa3.patch_0.gpu_resources
Core/ee6b1ba7e22d71ed.patch_0
Core/ee6b1ba7e22d71ed.patch_0.stream
Core/ee6b1ba7e22d71ed.patch_0.gpu_resources
README-安装说明.txt