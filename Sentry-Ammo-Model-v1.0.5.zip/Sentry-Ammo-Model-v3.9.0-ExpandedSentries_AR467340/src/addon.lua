-- HD2-Addon: mods/codex/sentry_ammo_model_v3
-- Sentry Ammo Model v3.9.0 - expanded sentry feeds: Flame / Tesla / Mortar / EMS plus existing MG/Gatling/AC8/Rocket.
-- Based on the stable v3.7.8 renderer and hostile-feed filter.
-- No screen projection, no screen GUI, no world GUI and no gameplay writes.
-- Uses Stingray world-space geometry with depth testing so terrain/rocks/walls occlude the marker naturally.
-- Entity record: +0 u64 type hash, +8 id, +0xC unit handle, +0x14 flags.
if type(jit) == 'table' and type(jit.off) == 'function' then jit.off(true, true) end

local CFG = {
    radius = 15.0,        -- m
    interval = 0.5,       -- s per supply pass
    heal_frac = 0.05,     -- fraction of max HP per pass (hull and every part)
    ammo_every = 2,       -- passes (2 x 0.5 s = once per second); 0 = no ammo
    ammo_frac = 0.10,     -- max fraction of a magazine / of max spare magazines per step
    wheel_every = 4,      -- passes per repaired tyre (4 x 0.5 s = 2 s); 0 = off
    leg_fix = true,       -- restore exosuit move speed after full repair
    arm_every = 2,        -- passes between advanced exosuit-arm/weapon repair scans (2 x 0.5 s = 1 s)
    block_arc = false,    -- FX-12 keeps its normal shield behavior; no Tesla arc suppression
    arc_hold = 5.0,       -- unused in FX-12 mode; kept for binary/build compatibility
    learn_every = 1.0,    -- s between tyre-learning scans
    sentry_dynamic = true, -- include dynamic defensive roots that expose mounted sentry ammo
    spatial_emplacement_ammo = true, -- refill fixed mounted ammo inside the FX-12 bubble even if root hash is unknown
    spatial_emplacement_min_cap = 10, -- avoids ordinary single-shot/support weapons; E/AT-12 and sentries exceed this or use >=10 reserves
}

local unpack_values = table.unpack or unpack
local function pack_values(...) return {n = select('#', ...), ...} end
local TWO32 = 4294967296

local TOWER_TYPES = { ['ED13DDC480EC6910'] = 'FX-12 Shield Generator Relay' }
local VEHICLE_TYPES = {
    ['79E4B3D2DA5E45E3'] = 'EXO-45 Patriot', ['08F6089289C83D22'] = 'EXO-45 gatling',
    ['824B7E0C4C879EB5'] = 'EXO-45 rockets', ['821D035AA47E3E75'] = 'EXO-45 rockets MK2',
    ['C2D449ECF7FACAB1'] = 'EXO-49 Emancipator', ['BF4167FD26917AB1'] = 'EXO-49 arm',
    ['E5F64DCC3BFE9DD1'] = 'EXO-49 left', ['32C7063B4BCC4208'] = 'EXO-49 left MK2',
    ['8CA4DFA795A473C8'] = 'EXO-49 left MK3', ['FF9878576A4C543B'] = 'EXO-49 right',
    ['0A03761D50BA5121'] = 'EXO-49 right MK2', ['3E3A31261A124454'] = 'EXO-49 right MK3',
    ['7B2326F6FD9C8069'] = 'EXO-51 Lumberer', ['0736BEE2D6328726'] = 'EXO-51 flamer',
    ['17C5D12D8D5DEE2C'] = 'EXO-51 AT cannon', ['35DBF54F016F3624'] = 'EXO-55 Breaker',
    ['65489809A8181B96'] = 'EXO-55 shield', ['DF51FE8D62F294BE'] = 'EXO-55 shotgun',
    ['CC21C7FFD3EBEFB9'] = 'M-102 FRV', ['E9CD1D0D118886AF'] = 'M-102 FRV (map)',
    ['9B2140378640432E'] = 'M-103 Supply FRV', ['9E83637BB077E782'] = 'M-103 supply crate',
    ['2D85BFE3D8717FE5'] = 'M-104 FRV', ['16474112801385B6'] = 'TD-220 Bastion',
    ['1FA1F596769225C2'] = 'TD-220 cannon', ['B0C9FAF4AF8903F9'] = 'TD-?? Maelstrom',
    ['D58AE6A04EDB10DE'] = 'Maelstrom main gun', ['C36B5B37C058DBDD'] = 'Maelstrom designator',
    ['3A061009AA31E9CB'] = 'Maelstrom smoke launcher', ['8AFF7F0793A5BCED'] = 'Maelstrom rocket pods',
    ['423FF97D57AB04F5'] = 'Harvester rig',
    ['0801B6B3C5D12EBC'] = 'Harvester rig MK2', ['9872EEB31A5F88FD'] = 'Harvester turret',
    ['130574E0FFFE0058'] = 'Harvester tank',
}

-- Verified Super Earth Defensive turret/emplacement roots. The dynamic Mount fallback below
-- covers newer green stratagems (e.g. new sentries/emplacements) whose root hash is not in this table yet.
local SENTRY_TYPES = {
    ['0E977C49DB7604F9'] = 'E/MG-101 HMG Emplacement',
    ['A970CBA66FBEAA11'] = 'HMG Emplacement (discoverable)',
    ['51A0812E3BCE2D74'] = 'Mortar / EMS Mortar Sentry',
    ['37079568DC86E9C6'] = 'Rocket Sentry',
    ['EF85D6CF58E31D70'] = 'Gatling / Autocannon-family Sentry',
    ['7FF0FD4572F5996F'] = 'Power-generated Gatling Sentry',
    ['37CDE43876BA26BB'] = 'Machine Gun Sentry',
    ['57F27CBD5B71B0CB'] = 'Tutorial Sentry',
}

-- WeaponMagazine entity type -> owning vehicle root type.
-- These are used only when the normal Mount/Attachable chain does not reach the vehicle root.
local DIRECT_WEAPON_ROOTS = {
    ['08F6089289C83D22'] = '79E4B3D2DA5E45E3', -- EXO-45 gatling
    ['824B7E0C4C879EB5'] = '79E4B3D2DA5E45E3', -- EXO-45 rockets
    ['821D035AA47E3E75'] = '79E4B3D2DA5E45E3', -- EXO-45 rockets MK2
    ['BF4167FD26917AB1'] = 'C2D449ECF7FACAB1', -- EXO-49 arm
    ['E5F64DCC3BFE9DD1'] = 'C2D449ECF7FACAB1', -- EXO-49 left
    ['32C7063B4BCC4208'] = 'C2D449ECF7FACAB1', -- EXO-49 left MK2
    ['8CA4DFA795A473C8'] = 'C2D449ECF7FACAB1', -- EXO-49 left MK3
    ['FF9878576A4C543B'] = 'C2D449ECF7FACAB1', -- EXO-49 right
    ['0A03761D50BA5121'] = 'C2D449ECF7FACAB1', -- EXO-49 right MK2
    ['3E3A31261A124454'] = 'C2D449ECF7FACAB1', -- EXO-49 right MK3
    ['0736BEE2D6328726'] = '7B2326F6FD9C8069', -- EXO-51 flamer
    ['17C5D12D8D5DEE2C'] = '7B2326F6FD9C8069', -- EXO-51 AT cannon
    ['DF51FE8D62F294BE'] = '35DBF54F016F3624', -- EXO-55 shotgun
    ['1FA1F596769225C2'] = '16474112801385B6', -- TD-220 cannon
    ['D58AE6A04EDB10DE'] = 'B0C9FAF4AF8903F9', -- Maelstrom main gun
    ['C36B5B37C058DBDD'] = 'B0C9FAF4AF8903F9', -- Maelstrom designator
    ['3A061009AA31E9CB'] = 'B0C9FAF4AF8903F9', -- Maelstrom smoke launcher
    ['8AFF7F0793A5BCED'] = 'B0C9FAF4AF8903F9', -- Maelstrom rocket pods
}

-- Exosuit arm/weapon HealthComponent type -> owning exosuit root.
-- Field Repair 1.3 demonstrated that these arm entities remain in the Health manager even after destruction;
-- reviving their Health record + side state + dead-part mask makes the weapon functional again.
local EXO_ARM_ROOTS = {
    ['08F6089289C83D22'] = '79E4B3D2DA5E45E3', ['824B7E0C4C879EB5'] = '79E4B3D2DA5E45E3',
    ['821D035AA47E3E75'] = '79E4B3D2DA5E45E3',
    ['BF4167FD26917AB1'] = 'C2D449ECF7FACAB1', ['E5F64DCC3BFE9DD1'] = 'C2D449ECF7FACAB1',
    ['32C7063B4BCC4208'] = 'C2D449ECF7FACAB1', ['8CA4DFA795A473C8'] = 'C2D449ECF7FACAB1',
    ['FF9878576A4C543B'] = 'C2D449ECF7FACAB1', ['0A03761D50BA5121'] = 'C2D449ECF7FACAB1',
    ['3E3A31261A124454'] = 'C2D449ECF7FACAB1',
    ['0736BEE2D6328726'] = '7B2326F6FD9C8069', ['17C5D12D8D5DEE2C'] = '7B2326F6FD9C8069',
    ['DF51FE8D62F294BE'] = '35DBF54F016F3624', ['65489809A8181B96'] = '35DBF54F016F3624',
}
local EXO_ROOTS = {
    ['79E4B3D2DA5E45E3'] = true, ['C2D449ECF7FACAB1'] = true,
    ['7B2326F6FD9C8069'] = true, ['35DBF54F016F3624'] = true,
}

local function mul32(a, b)
    local al, ah = a % 65536, math.floor(a / 65536)
    local bl, bh = b % 65536, math.floor(b / 65536)
    local mid = (ah * bl + al * bh) % 65536
    return (mid * 65536 + al * bl) % TWO32
end
-- Game hash-map probe: slot = (cap-1) & (i + key*mult); stop at empty key.
local function probe_map(key, capacity, empty_key, multiplier, read_slot, probe_limit)
    if key == empty_key then return nil, 'key_equals_empty_marker' end
    if type(capacity) ~= 'number' or capacity < 1 or capacity > 0x1000000 then return nil, 'map_capacity_rejected' end
    local pow = 1
    while pow < capacity do pow = pow * 2 end
    if pow ~= capacity then return nil, 'map_capacity_not_power_of_two' end
    local base = mul32(key, multiplier)
    local limit = math.min(capacity, probe_limit or 256)
    for i = 0, limit - 1 do
        local index = ((base + i) % TWO32) % capacity
        local k, v = read_slot(index)
        if k == nil then return nil, 'map_slot_unreadable' end
        if k == empty_key then return nil, 'absent' end
        if k == key then
            if v == nil or v == 0xFFFFFFFF then return nil, 'present_with_invalid_index' end
            return v
        end
    end
    return nil, 'probe_limit_reached'
end
local function parse_pattern(text)
    local out = {}
    for token in text:gmatch('%S+') do
        if token == '??' then out[#out + 1] = -1 else out[#out + 1] = tonumber(token, 16) end
    end
    return out
end
local function masked_match(bytes, start, pattern)
    if start < 1 or start + #pattern - 1 > #bytes then return false end
    for i = 1, #pattern do
        local want = pattern[i]
        if want >= 0 and bytes:byte(start + i - 1) ~= want then return false end
    end
    return true
end
-- ceil(n * frac), at least 1
local function step_of(n, frac)
    local x = n * frac
    local s = math.floor(x)
    if x > s then s = s + 1 end
    if s < 1 then s = 1 end
    return s
end

if rawget(_G, 'SentryAmmoModelScannerTest') then
    return {mul32 = mul32, probe_map = probe_map, parse_pattern = parse_pattern, masked_match = masked_match,
        step_of = step_of, CFG = CFG, VEHICLE_TYPES = VEHICLE_TYPES, SENTRY_TYPES = SENTRY_TYPES}
end
if rawget(_G, 'SentryAmmoModelScanner') then return end

-- ---------------------------------------------------------------------------------------
-- Locators (game.dll 1.0.0.19155, dump output20260926). Every address is derived from code
-- bytes; exact build = timestamp + all patterns at their recorded RVAs, otherwise a chunked
-- read-only scan looks for unique hits.
local BUILD = {
    label = 'output20260926', file_version = '1.0.0.19155', pe_timestamp = 0x6AB3B43F,
    accepted_image_sizes = {[0x4747000] = true, [0x4744000] = true},
    P = {
    HEALDRV = {rva = 0x4B9B50, pattern = '40 57 48 83 EC 20 48 8B 39 4C 8B 1D ?? ?? ?? ?? 8B 47 08 3B 05 ?? ?? ?? ?? 74 ?? 45 8B 93 ?? ?? ?? ?? 45 33 C0 48 89 5C 24 30 41 8B 9B ?? ?? ?? ?? 0F AF D8 4C 89 74 24 48 45 8D 72 FF 45 85 D2 74 ?? 48 89 6C 24 38 41 8B AB ?? ?? ?? ?? 48 89 74 24 40 49 8B B3 ?? ?? ?? ?? 66 0F 1F 44 00 00 41 8D 14 18 41 8B CE 48 23 D1 44 8B 0C D6 44 3B CD 74 ?? 44 3B C8 74 ?? 41 FF C0 45 3B C2 72 ?? 48 8B 74 24 40 48 8B 6C 24 38 48 8B 5C 24 30 4C 8B 74 24 48 0F 28 D1 8B D0 49 8B CB 48 83 C4 20 5F E9 ?? ?? ?? ??'},
    RESUP   = {rva = 0x705A80, pattern = '40 53 48 83 EC 20 44 3B 05 ?? ?? ?? ?? 41 8B D8 0F 84 ?? ?? ?? ?? 48 89 6C 24 30 33 D2 48 89 7C 24 40 8B CA 48 8B 3D ?? ?? ?? ?? 4C 89 74 24 48 44 8B 47 28 44 8B 5F 30 41 8B EB 0F AF EB 45 8D 70 FF 45 85 C0 0F 84 ?? ?? ?? ?? 4C 8B 57 20 48 89 74 24 38 8B 77 2C 66 0F 1F 84 00 00 00 00 00 41 8B C6 44 8D 0C 29 4C 23 C8 43 8B 04 CA 3B C6 74 ?? 3B C3 74 ?? FF C1 41 3B C8 72 ?? EB ?? 3B C3 75 ?? 43 8B 44 CA 04 83 F8 FF 74 ?? 8B C8 48 8B 47 38 48 8B 0C C8'},
    ADDMAG  = {rva = 0x76E830, pattern = '48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 48 89 7C 24 20 41 56 48 83 EC 20 3B 15 ?? ?? ?? ?? 8B DA 48 8B 2D ?? ?? ?? ?? 74 ?? 44 8B 45 28 33 C9 44 8B 4D 30 44 0F AF CB 41 8D 78 FF 45 85 C0 74 ?? 4C 8B 55 20 44 8B 5D 2C 66 0F 1F 44 00 00 8B C7 42 8D 14 09 48 23 D0 41 8B 04 D2 41 3B C3 0F 84 ?? ?? ?? ?? 3B C3 0F 84 ?? ?? ?? ?? FF C1 41 3B C8 72 ??'},
    STATMOD = {rva = 0x9CCAE0, pattern = '40 55 3B 15 ?? ?? ?? ?? 4C 8B 15 ?? ?? ?? ?? 49 63 E8 75 ?? B8 FF FF FF FF EB ?? 45 8B 4A 28 33 C9 45 8B 5A 30 48 89 5C 24 10 48 89 74 24 18 44 0F AF DA 41 8D 71 FF 48 89 7C 24 20 45 85 C9 74 ?? 49 8B 5A 20 41 8B 7A 2C 0F 1F 80 00 00 00 00 8B C6 46 8D 04 19 4C 23 C0 42 8B 04 C3 3B C7 74 ?? 3B C2 74 ?? FF C1 41 3B C9 72 ?? B8 FF FF FF FF 48 8B 74 24 18 48 8B 5C 24 10 48 8B 7C 24 20 8B C8 49 8B 42 48 48 6B D1 0D 48 03 D5 F3 0F 11 1C 90 5D C3'},
    WHEEL   = {rva = 0x11A8490, pattern = '48 89 5C 24 18 48 89 6C 24 20 57 48 81 EC C0 00 00 00 48 8B 05 ?? ?? ?? ?? 48 33 C4 48 89 84 24 B0 00 00 00 8B 41 08 8B EA 3B 05 ?? ?? ?? ?? 48 8B 1D ?? ?? ?? ?? 75 ?? B8 FF FF FF FF EB ?? 44 8B 4B 48 33 D2 44 8B 53 50 44 0F AF D0'},
    MOUNTRS = {rva = 0x705900, pattern = '48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 41 56 41 57 48 83 EC 30 8B 05 ?? ?? ?? ?? 48 8B 3D ?? ?? ?? ?? 3B D0 74 ?? 44 8B 57 28 45 33 C9 8B 5F 30 0F AF DA 45 8D 72 FF 45 85 D2 74 ?? 48 8B 77 20 8B 6F 2C 66 66 0F 1F 84 00 00 00 00 00 41 8B CE 45 8D 04 19 4C 23 C1 42 8B 0C C6 4E 8D 1C C6 3B CD 0F 84 ?? ?? ?? ?? 3B CA 0F 84 ?? ?? ?? ?? 41 FF C1 45 3B CA 72 ?? B9 FF FF FF FF 8B D1 41 BF 05 00 00 00 48 8B 4F 48'},
    WAPI    = {rva = 0x6E7F76, pattern = '41 0B C6 80 BF 01 03 00 00 00 89 87 FC 02 00 00 75 ?? 48 8B 05 ?? ?? ?? ?? 48 8B 48 18 48 8B 43 58 4C 8B 81 90 00 00 00 48 8B 0C D0 33 D2 8B 49 0C 41 FF D0'},
    UNIT    = {rva = 0x4DF3CE, pattern = '4D 8B 2C 24 8B 15 ?? ?? ?? ?? 48 8B 2D ?? ?? ?? ?? 41 8B 45 08 3B C2 74 ?? 44 8B 55 48 44 8B C7 44 8B 5D 50 44 0F AF D8'},
    ATT     = {rva = 0x4A52B0, pattern = '48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 48 89 7C 24 20 3B 15 ?? ?? ?? ?? 4C 8B 15 ?? ?? ?? ?? 74 ?? 45 8B 4A 20 45 33 C0 41 8B 5A 28 0F AF DA 41 8D 69 FF 45 85 C9 74 ?? 49 8B 7A 18 41 8B 72 24 0F 1F 40 00 66 66 0F 1F 84 00 00 00 00 00 8B C5 41 8D 0C 18 48 23 C8 8B 04 CF 4C 8D 1C CF 3B C6 74 ?? 3B C2 74 ?? 41 FF C0 45 3B C1 72 ?? 32 C0 48 8B 5C 24 08 48 8B 6C 24 10 48 8B 74 24 18 48 8B 7C 24 20 C3 3B C2 75 ?? 41 8B 43 04 83 F8 FF 74 ?? 48 69 C8 ?? ?? ?? ?? 49 8B 42 ?? 83 3C 01 00 0F 95 C0 EB ??'},
    WPN     = {rva = 0x80DF4A, pattern = '41 8B 45 08 3B 05 ?? ?? ?? ?? 48 8B 35 ?? ?? ?? ?? 74 ?? 44 8B 4E 30 33 D2 44 8B 56 38 44 0F AF D0 45 8D 61 FF 45 85 C9 74 ?? 4C 8B 5E 28 8B 7E 34'},
    ARC     = {rva = 0x80C180, pattern = '48 83 EC 28 3B 15 ?? ?? ?? ?? 4C 8B 1D ?? ?? ?? ?? 75 ?? B8 FF FF FF FF EB ?? 45 8B 4B 50 45 33 C0 48 89 5C 24 30 41 8B 5B 58 48 89 6C 24 38 0F AF DA 41 8D 69 FF 48 89 74 24 40 48 89 7C 24 20 45 85 C9 74 ?? 49 8B 7B 48 41 8B 73 54 0F 1F 00 8B C5 41 8D 0C 18 48 23 C8 8B 04 CF 4C 8D 14 CF 3B C6 74 ?? 3B C2 74 ?? 41 FF C0 45 3B C1 72 ?? B8 FF FF FF FF 48 8B 74 24 40 48 8B 6C 24 38 48 8B 5C 24 30 48 8B 7C 24 20 8B C8 49 8B 43 70 4C 8D 04 89 46 8B 44 C0 04 48 83 C4 28 E9'},
    },
    ORDER = {'HEALDRV', 'RESUP', 'ADDMAG', 'STATMOD', 'WHEEL', 'MOUNTRS', 'WAPI', 'UNIT', 'ATT', 'ARC', 'WPN'},
    -- Health rows / zone config (fixed across 0815..0926 once the table offset is known)
    hp = {rows_from_tbl = 0x28, row28_from_tbl = 0x30, recs_from_tbl = 0x18, cur = 0x14, state = 0x19C,
          zones = 0xF8, max28 = 0x14, row28_stride = 0x1C, cfg_zone = 0x268, cfg_zone_stride = 0x228,
          cfg_zone_max = 0x88, n_zones = 0x26},
    arc = {recs = 0x60, stride = 40, cooldown = 8},
    wpn = {stride = 40, arc_bit = 0x10},
    wm = {stride = 12, cfg_cap = 0x88, cfg_max = 0x94},
    mount = {stride = 0x18, slots = 5},
    sm = {stride = 13 * 4, leg_hurt = 0.75},
    wheel = {size = 0x30, flag = 0x28, magic = 0x20575256},   -- 'VRW ' vehicle resource
}
for _, p in pairs(BUILD.P) do p.mask = parse_pattern(p.pattern) end

local state = {
    revision = 'vehicle-supply-shield-relay-field-repair-parts-lua-1.0.9',
    build = BUILD.label, build_mode = 'unchecked', version_warning = 'none',
    phase = 'environment_gate', status = 'starting', module_fingerprint = 'unchecked', globals = 'unresolved',
    frames = 0, passes = 0, errors = 0, native_calls = 0,
    towers = 0, arc_holds = 0, arc_bits_cleared = 0, arc_bits_restored = 0, tower_weapon = 'none',
    heal_probe = 'none', ammo_probe = 'none', sentry_probe = 'none', vehicles_in_range = 0, sentries_in_range = 0, heal_calls = 0, full_skips = 0,
    ammo_fill_calls = 0, ammo_mag_calls = 0, ammo_skip_non_authority = 0, ammo_native_nochange = 0, client_ammo_writes = 0,
    direct_ammo_hits = 0, direct_ammo_probe = 'none', dynamic_sentry_roots = 0,
    wheel_types_learned = 0, wheels_learned = 0, wheels_fixed = 0, wheel_skips = 'none',
    legs_fixed = 0, arms_revived = 0, arms_mended = 0, shield_plates_fixed = 0,
    arm_scan_hits = 0, arm_skips = 'none', last_part = 'none',
    last_heal = 'none', last_ammo = 'none', last_wheel = 'none',
    compatibility_scan_offset = 0, compatibility_hits = 'none', stopped = false,
}
rawset(_G, 'SentryAmmoModelScanner', state)

local loader = rawget(_G, 'CowboyBingusModLoader')
if type(loader) ~= 'table' or type(loader.api) ~= 'number' or loader.api < 1
    or type(loader.version) ~= 'number' or loader.version < 15 then
    state.phase, state.status = 'rejected', 'Bingus Shared Loader v15 or newer / API 1 (or MDL) required'
    print('[SentryAmmoModelScanner] ' .. state.status)
    return
end
local ok_ffi, ffi = pcall(require, 'ffi')
if not ok_ffi or not ffi.abi('win') or not ffi.abi('64bit') then
    state.phase, state.status = 'rejected', 'Windows x64 LuaJIT FFI required'
    print('[SentryAmmoModelScanner] ' .. state.status)
    return
end
local bit = require('bit')

pcall(ffi.cdef, [[
    typedef struct {
        void *base; void *allocation_base; uint32_t allocation_protection;
        uint16_t partition; uint16_t reserved; size_t size;
        uint32_t state; uint32_t protection; uint32_t type;
    } VstMemoryRegion;
]])
pcall(ffi.cdef, [[
    void *GetModuleHandleA(const char *name);
    void *GetCurrentProcess(void);
    int ReadProcessMemory(void *process, const void *address, void *buffer, size_t size, size_t *read);
    size_t VirtualQuery(const void *address, void *region, size_t size);
]])
local kernel = ffi.load('kernel32')
local process = kernel.GetCurrentProcess()
local U8 = ffi.typeof('uint8_t *')
local query_region = ffi.cast('size_t (*)(const void *, void *, size_t)', kernel.VirtualQuery)
local game_ptr, game, runtime_image_size, last_report
local G = {}      -- resolved addresses (numbers) and layouts

local function addr(n) return ffi.cast(U8, ffi.cast('uintptr_t', n)) end
local function num(p) return tonumber(ffi.cast('uintptr_t', p)) end
local function read(a, size)
    if a == nil or a == 0 or size <= 0 or size > 0x100000 then return nil end
    local buffer, count = ffi.new('uint8_t[?]', size), ffi.new('size_t[1]')
    if kernel.ReadProcessMemory(process, addr(a), buffer, size, count) == 0 or count[0] ~= size then return nil end
    return ffi.string(buffer, size)
end
local function u32s(bytes, o)
    if not bytes or o < 0 or o + 4 > #bytes then return nil end
    local a, b, c, d = bytes:byte(o + 1, o + 4)
    return a + b * 256 + c * 65536 + d * 16777216
end
local function i32s(bytes, o)
    local v = u32s(bytes, o)
    if not v then return nil end
    return v >= 0x80000000 and v - TWO32 or v
end
local function f32s(bytes, o)
    if not bytes or o < 0 or o + 4 > #bytes then return nil end
    local box = ffi.new('float[1]')
    ffi.copy(box, bytes:sub(o + 1, o + 4), 4)
    return tonumber(box[0])
end
-- plausible user-mode pointer or nil
local function ptrs(bytes, o)
    local lo, hi = u32s(bytes, o), u32s(bytes, o + 4)
    if not lo or not hi then return nil end
    if hi >= 0x8000 or (hi == 0 and lo < 0x10000) then return nil end
    return hi * TWO32 + lo
end
local function r32(a) return u32s(read(a, 4), 0) end
local function rq(a) return ptrs(read(a, 8), 0) end
local function rf(a) return f32s(read(a, 4), 0) end
local function rb(a) local b = read(a, 1); return b and b:byte(1) end
local function type_key(rec)
    local b = read(rec, 0x18)
    if not b then return nil end
    return string.format('%08X%08X', u32s(b, 4), u32s(b, 0)), u32s(b, 8), u32s(b, 12), u32s(b, 0x14)
end
local function writable_private(a, size)
    local region = ffi.new('VstMemoryRegion[1]')
    if query_region(addr(a), region, ffi.sizeof(region[0])) ~= ffi.sizeof(region[0]) then return false end
    if region[0].state ~= 0x1000 or region[0].type ~= 0x20000
        or (region[0].protection ~= 4 and region[0].protection ~= 8) then return false end
    local available = tonumber(region[0].size) - (a - num(region[0].base))
    return available >= size
end
local function write_u32(a, v)
    if not writable_private(a, 4) then return false end
    ffi.cast('uint32_t *', addr(a))[0] = v
    return r32(a) == v
end
local function write_float(a, v)
    if not writable_private(a, 4) then return false end
    ffi.cast('float *', addr(a))[0] = v
    return rf(a) == tonumber(ffi.new('float', v))
end

local function write_bytes(a, bytes)
    if type(bytes) ~= 'string' or #bytes == 0 or not writable_private(a, #bytes) then return false end
    ffi.copy(addr(a), bytes, #bytes)
    return read(a, #bytes) == bytes
end
local function i32_bytes(v)
    local x = ffi.new('int32_t[1]', v)
    return ffi.string(x, 4)
end
local function u32_bytes(v)
    local x = ffi.new('uint32_t[1]', v % TWO32)
    return ffi.string(x, 4)
end

-- Native calls. A test harness may substitute implementations (SentryAmmoModelScannerSim.native).
local native_cache = {}
local function native(name, ctype, a)
    local key = name .. ':' .. tostring(a)
    local f = native_cache[key]
    if f then return f end
    local sim = rawget(_G, 'SentryAmmoModelScannerSim')
    if sim and sim.native then f = sim.native(name, a, ctype) end
    f = f or ffi.cast(ctype, addr(a))
    native_cache[key] = f
    return f
end
local CT = {
    heal = 'void (*)(void *, uint32_t, float)',
    hcfg = 'void *(*)(void *)',
    fill = 'void (*)(void *, uint32_t, int32_t)',
    addmag = 'void (*)(void *, uint32_t, float)',
    magcfg = 'void *(*)(void *)',
    wpos = 'void *(*)(uint32_t, uint32_t)',
    comp = 'uint64_t (*)(uint32_t, uint32_t, void *)',
    vget = 'uint64_t (*)(uint32_t, uint32_t, void *)',
    vset = 'uint64_t (*)(uint32_t, uint32_t, void *)',
}
local function call(name, a, ...)
    state.native_calls = state.native_calls + 1
    return native(name, CT[name], a)(...)
end

local LOG_KEYS = {
    'revision', 'build', 'build_mode', 'version_warning', 'phase', 'status', 'module_fingerprint', 'globals',
    'compatibility_scan_offset', 'compatibility_hits', 'frames', 'passes', 'towers', 'arc_holds',
    'arc_bits_cleared', 'arc_bits_restored', 'tower_weapon', 'heal_probe', 'ammo_probe', 'sentry_probe',
    'vehicles_in_range', 'sentries_in_range', 'heal_calls', 'full_skips', 'ammo_fill_calls', 'ammo_mag_calls', 'ammo_skip_non_authority',
    'ammo_native_nochange', 'client_ammo_writes', 'direct_ammo_hits', 'direct_ammo_probe', 'dynamic_sentry_roots',
    'wheel_types_learned', 'wheels_learned', 'wheels_fixed', 'wheel_skips', 'legs_fixed',
    'arms_revived', 'arms_mended', 'shield_plates_fixed', 'arm_scan_hits', 'arm_skips', 'last_part',
    'last_heal', 'last_ammo', 'last_wheel', 'native_calls', 'errors', 'stopped',
}
local function write_reports(force)
    if not force and last_report == state.status then return end
    last_report = state.status
    pcall(function()
        local log = loader.open_log and loader.open_log('SentryAmmoModelScanner.log')
        if log then
            for _, key in ipairs(LOG_KEYS) do log:write(key .. '=' .. tostring(state[key]) .. '\n') end
            log:close()
        end
        local st = loader.open_log and loader.open_log('SentryAmmoModelScanner_STATUS.log')
        if st then
            local prefix = state.phase == 'steady' and 'OK' or state.phase == 'rejected' and 'FAILED' or 'WAITING'
            st:write(prefix .. ' - ' .. state.status .. '\nrevision=' .. state.revision .. '\nbuild_mode='
                .. state.build_mode .. '\nversion_warning=' .. state.version_warning .. '\n')
            st:close()
        end
    end)
end
local function reject(reason)
    state.phase, state.status, state.stopped = 'rejected', reason, true
    write_reports(true)
end

-- ---------------------------------------------------------------------------------------
-- Derivation from pattern hits (a = absolute address of each pattern start).
local function bytes_at(a, list)
    local b = read(a, #list)
    if not b then return false end
    for i = 1, #list do if b:byte(i) ~= list[i] then return false end end
    return true
end
local function riprel(a, disp_off, insn_len)
    local d = i32s(read(a + disp_off, 4), 0)
    if not d then return nil end
    return a + insn_len + d
end
local function need(c, msg) if not c then error(msg, 0) end end

local function derive(H)
    local R = {}
    -- Health manager + HEAL (0x91E920) via the repair-drone wrapper that tail-jumps to it
    local hd = H.HEALDRV
    need(bytes_at(hd + 0x09, {0x4C, 0x8B, 0x1D}), 'HEALDRV+9')
    R.health = riprel(hd + 0x09, 3, 7)
    local tbl = r32(hd + 0x56)
    local hp = {tbl = tbl, cap = r32(hd + 0x1E), mult = r32(hd + 0x2D), empty = r32(hd + 0x4A)}
    need(tbl and hp.cap == tbl + 8 and hp.empty == tbl + 12 and hp.mult == tbl + 16, 'health layout')
    need(bytes_at(hd + 0xA1, {0xE9}), 'HEALDRV tail jmp')
    R.heal = riprel(hd + 0xA1, 1, 5)
    need(bytes_at(R.heal, {0x48, 0x8B, 0xC4, 0x48, 0x89, 0x58, 0x10}), 'HEAL prologue')
    need(bytes_at(R.heal + 0xBB, {0x49, 0x8B, 0xCC}) and bytes_at(R.heal + 0xC2, {0xE8}), 'HEAL cfg call')
    R.hcfg = riprel(R.heal + 0xC2, 1, 5)
    need(bytes_at(R.heal + 0xCB, {0x4D, 0x69, 0xED}), 'HEAL row stride')
    hp.stride = r32(R.heal + 0xCE)
    need(hp.stride and hp.stride >= 0x19C + 4 and hp.stride < 0x1000, 'health stride')
    R.hp = hp
    -- WeaponMagazine + fill current magazine (0x76E080)
    local rs = H.RESUP
    need(bytes_at(rs + 0x24, {0x48, 0x8B, 0x3D}), 'RESUP+24')
    R.wmag = riprel(rs + 0x24, 3, 7)
    R.wm = {cap = rb(rs + 0x33), mult = rb(rs + 0x37), tbl = rb(rs + 0x4E), empty = rb(rs + 0x56), recs = rb(rs + 0x92)}
    need(bytes_at(rs + 0xEA, {0x45, 0x33, 0xC0, 0x8B, 0xD3, 0xE8}), 'RESUP fill call')
    R.fill = riprel(rs + 0xEF, 1, 5)
    -- spare magazines (0x76E830) + magazine config (0x4F3740)
    local am = H.ADDMAG
    R.addmag = am
    need(bytes_at(am + 0x85, {0x48, 0x8B, 0xCF, 0xE8}), 'ADDMAG cfg call')
    R.magcfg = riprel(am + 0x88, 1, 5)
    need(bytes_at(am + 0x95, {0x48, 0x8B, 0x4D}), 'ADDMAG rows')
    R.wm.rows = rb(am + 0x98)
    -- stat modifier (exosuit leg speed)
    local sm = H.STATMOD
    R.statmod = riprel(sm + 0x08, 3, 7)
    R.sm = {cap = rb(sm + 0x1E), mult = rb(sm + 0x24), tbl = rb(sm + 0x44), empty = rb(sm + 0x48), rows = rb(sm + 0x85)}
    need(bytes_at(sm + 0x86, {0x48, 0x6B, 0xD1, 0x0D}), 'STATMOD stride')
    -- wheels: component query table [0x3326310] and VehicleApi [0x3326320]
    local wh = H.WHEEL
    need(bytes_at(wh + 0xB3, {0x4C, 0x8B, 0x0D}), 'WHEEL comp table')
    R.comp_tbl = riprel(wh + 0xB3, 3, 7)
    need(bytes_at(wh + 0xBA, {0x4C, 0x8D, 0x44, 0x24, 0x50, 0x8B, 0x4B, 0x0C, 0xBA, 0x10, 0x00, 0x00, 0x00}), 'WHEEL comp args')
    need(bytes_at(wh + 0xCD, {0x48, 0x8B, 0x4C, 0x24, 0x70}), 'WHEEL comp result')
    need(bytes_at(wh + 0xEB, {0x48, 0x8B, 0x05}), 'WHEEL vapi')
    R.vapi = riprel(wh + 0xEB, 3, 7)
    need(bytes_at(wh + 0xFC, {0xFF, 0x50}) and bytes_at(wh + 0x173, {0xFF, 0x50}), 'WHEEL get/set slots')
    R.vget_slot, R.vset_slot = rb(wh + 0xFE), rb(wh + 0x175)
    need(R.vapi == riprel(wh + 0x114, 3, 7), 'WHEEL vapi twice')
    -- Mount (vehicle weapon slots)
    local mr = H.MOUNTRS
    need(bytes_at(mr + 0x1E, {0x48, 0x8B, 0x3D}), 'MOUNTRS+1E')
    R.mount = riprel(mr + 0x1E, 3, 7)
    R.mo = {cap = rb(mr + 0x2C), mult = rb(mr + 0x32), tbl = rb(mr + 0x42), empty = rb(mr + 0x45), rows = rb(mr + 0x8A)}
    -- world API: [[G]+wapi1]+wapi2 (unit, 0) -> world matrix (translation +0x30)
    local wa = H.WAPI
    R.wapi = riprel(wa + 0x12, 3, 7)
    R.wapi1, R.wapi2 = rb(wa + 0x1C), r32(wa + 0x24)
    -- Unit component (membership check before asking for a world position)
    local un = H.UNIT
    R.unit = riprel(un + 0x0A, 3, 7)
    R.un = {cap = rb(un + 0x1C), mult = rb(un + 0x23), tbl = 0x40, empty = 0x4C}
    -- Attachable (weapon -> vehicle parent chain)
    local at = H.ATT
    R.att = riprel(at + 0x1A, 3, 7)
    R.at = {cap = rb(at + 0x26), mult = rb(at + 0x2D), tbl = rb(at + 0x3D), empty = rb(at + 0x41),
            stride = r32(at + 0x97), rows = rb(at + 0x9E)}
    need(R.at.stride and R.at.stride > 0 and R.at.stride < 0x1000, 'attachable stride')
    -- ArcWeapon (Tesla tower)
    local ar = H.ARC
    R.arc = riprel(ar + 0x0A, 3, 7)
    R.ar = {cap = rb(ar + 0x1D), mult = rb(ar + 0x29), tbl = rb(ar + 0x48), empty = rb(ar + 0x4C), rows = rb(ar + 0x8E)}
    need(R.ar.rows == BUILD.arc.recs + 0x10, 'arc rows offset')
    -- Weapon manager (row type bits; generic fire 0x741DF0 dispatches on them)
    local wp = H.WPN
    R.weapon = riprel(wp + 0x0A, 3, 7)
    R.wp = {cap = rb(wp + 0x16), mult = rb(wp + 0x1C), tbl = rb(wp + 0x2D), empty = rb(wp + 0x30)}
    need(bytes_at(wp + 0x70, {0x48, 0x8B, 0x76}), 'WPN rows load')
    R.wp.rows = rb(wp + 0x73)
    need(R.wp.tbl == 0x28 and R.wp.cap == 0x30 and R.wp.rows == 0x50, 'weapon layout')
    return R
end

local function bind(R)
    for k, v in pairs(R) do G[k] = v end
    state.globals = string.format('health=0x%X;wmag=0x%X;mount=0x%X;arc=0x%X;vapi=0x%X;heal=0x%X',
        R.health - game, R.wmag - game, R.mount - game, R.arc - game, R.vapi - game, R.heal - game)
end

local ok_gate, gate_error = pcall(function()
    game_ptr = kernel.GetModuleHandleA('game.dll')
    need(game_ptr ~= nil, 'game.dll unavailable')
    game = num(game_ptr)
    local dos = read(game, 0x100)
    need(dos and dos:sub(1, 2) == 'MZ', 'game.dll MZ signature missing')
    local pe_offset = u32s(dos, 0x3C)
    need(pe_offset and pe_offset >= 0x40 and pe_offset <= 0x1000, 'game.dll PE offset rejected')
    local pe = read(game + pe_offset, 0x100)
    need(pe and pe:sub(1, 4) == 'PE\0\0' and u32s(pe, 24) % 65536 == 0x20B, 'game.dll PE32+ identity rejected')
    local timestamp, image_size = u32s(pe, 8), u32s(pe, 24 + 56)
    runtime_image_size = image_size
    state.module_fingerprint = string.format('timestamp=0x%08X;size=0x%X', timestamp, image_size)
    if timestamp == BUILD.pe_timestamp and BUILD.accepted_image_sizes[image_size] then
        local H, all = {}, true
        for _, k in ipairs(BUILD.ORDER) do
            local p = BUILD.P[k]
            local b = read(game + p.rva, #p.mask)
            if b and masked_match(b, 1, p.mask) then H[k] = game + p.rva else all = false end
        end
        if all then
            local ok, R = pcall(derive, H)
            if ok then bind(R); state.build_mode = 'exact'; return end
            state.version_warning = 'timestamp matches but derivation failed: ' .. tostring(R)
        else
            state.version_warning = 'timestamp matches ' .. BUILD.file_version .. ' but recorded locators failed'
        end
    else
        state.version_warning = 'game.dll differs from ' .. BUILD.file_version .. ': ' .. state.module_fingerprint
    end
    state.build_mode = 'compatibility'
    state.phase, state.status = 'compatibility_search', 'version_mismatch_scanning_locators'
end)
if not ok_gate then reject(tostring(gate_error)); return end

-- Chunked read-only compatibility scan: one 256 KiB chunk per frame; every pattern must hit once.
local compat = {offset = 0, hits = {}}
for _, k in ipairs(BUILD.ORDER) do
    local p = BUILD.P[k]
    compat.hits[k] = {}
    -- anchor = longest run of fixed bytes at the start of the pattern
    local i, s = 1, {}
    while i <= #p.mask and p.mask[i] >= 0 and #s < 8 do s[#s + 1] = string.char(p.mask[i]); i = i + 1 end
    p.anchor = table.concat(s)
end
local function compatibility_scan_step()
    if compat.offset >= runtime_image_size then
        local parts, H, ok = {}, {}, true
        for _, k in ipairs(BUILD.ORDER) do
            local n = #compat.hits[k]
            parts[#parts + 1] = k .. '=' .. n
            if n ~= 1 then ok = false else H[k] = game + compat.hits[k][1] end
        end
        state.compatibility_hits = table.concat(parts, ';')
        compat.offset = math.huge
        if not ok then
            state.phase, state.status = 'waiting_read_only', 'compatibility_locators_not_unique'
            write_reports(true); return
        end
        local good, R = pcall(derive, H)
        if not good then
            state.phase, state.status = 'waiting_read_only', 'compatibility_derivation_rejected:' .. tostring(R)
            write_reports(true); return
        end
        bind(R)
        state.phase, state.status = 'waiting_for_scene', 'version_warning_compatibility_ready'
        write_reports(true)
        return
    end
    local chunk, overlap = 0x40000, 256
    local size = math.min(chunk + overlap, runtime_image_size - compat.offset)
    local bytes = read(game + compat.offset, size)
    if bytes then
        for _, k in ipairs(BUILD.ORDER) do
            local p, cursor = BUILD.P[k], 1
            while true do
                local found = bytes:find(p.anchor, cursor, true)
                if not found or found > chunk then break end
                if masked_match(bytes, found, p.mask) then
                    local rva, list = compat.offset + found - 1, compat.hits[k]
                    if list[#list] ~= rva then list[#list + 1] = rva end
                end
                cursor = found + 1
            end
        end
    end
    compat.offset = compat.offset + chunk
    state.compatibility_scan_offset = compat.offset
end

-- ---------------------------------------------------------------------------------------
-- Runtime helpers
local function map_of(mgr, L)
    local tbl, cap, empty, mult = rq(mgr + L.tbl), r32(mgr + L.cap), r32(mgr + L.empty), r32(mgr + L.mult)
    if not tbl or not cap or cap < 1 or cap > 0x100000 or not empty or not mult then return nil end
    return {tbl = tbl, cap = cap, empty = empty, mult = mult}
end
local function find_row(mgr, L, id)
    local m = mgr and map_of(mgr, L)
    if not m then return nil end
    return probe_map(id, m.cap, m.empty, m.mult, function(i)
        local s = read(m.tbl + i * 8, 8)
        if not s then return nil end
        return u32s(s, 0), u32s(s, 4)
    end)
end
-- iterate (id,row) of a manager map
local function each_entry(mgr, L, fn)
    local m = map_of(mgr, L)
    if not m then return false end
    local entries = read(m.tbl, m.cap * 8)
    if not entries then return false end
    for i = 0, m.cap - 1 do
        local id, row = u32s(entries, i * 8), u32s(entries, i * 8 + 4)
        if id ~= m.empty and row ~= 0xFFFFFFFF then fn(id, row) end
    end
    return true
end
local function world_pos(unit)
    local api = rq(G.wapi)
    local tbl = api and rq(api + G.wapi1)
    local fn = tbl and rq(tbl + G.wapi2)
    if not fn then return nil end
    local m = call('wpos', fn, unit, 0)
    if m == nil then return nil end
    local b = read(num(m) + 0x30, 12)
    if not b then return nil end
    return {x = f32s(b, 0), y = f32s(b, 4), z = f32s(b, 8)}
end
local function dist2(a, b) local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z; return dx * dx + dy * dy + dz * dz end

-- ---- FX-12 Shield Generator Relay supply anchors ----
local towers = {}   -- list of {id, unit, pos}
local cleared_arc = {}   -- kept empty in FX-12 mode; shutdown compatibility only

-- ---- Health ----
local function health_rows(hm, row)
    local hp, H = G.hp, BUILD.hp
    local rows, row28 = rq(hm + hp.tbl + H.rows_from_tbl), rq(hm + hp.tbl + H.row28_from_tbl)
    if not rows or not row28 then return nil end
    return rows + row * hp.stride, row28 + row * H.row28_stride
end
-- 'dead' | 'damaged' | 'full'
local function health_status(rec, r440, r28)
    local H = BUILD.hp
    local b = read(r440, G.hp.stride)
    local maxv = u32s(read(r28, 0x1C), H.max28)
    if not b or not maxv then return nil end
    if u32s(b, H.state) ~= 0 then return 'dead' end
    if i32s(b, H.cur) < maxv then return 'damaged' end
    local cfg = call('hcfg', G.hcfg, addr(rec))
    if cfg == nil then return 'full' end
    local c = num(cfg)
    local zb = read(c + H.cfg_zone, H.cfg_zone_stride * H.n_zones)
    if not zb then return 'full' end
    for z = 0, H.n_zones - 1 do
        local zmax = i32s(zb, z * H.cfg_zone_stride + H.cfg_zone_max)
        if zmax == -1 then zmax = maxv end
        if zmax == 0 or zmax == nil then break end
        if i32s(b, H.zones + z * 4) < zmax then return 'damaged' end
    end
    return 'full'
end

-- FX-12 has Health + Unit components but no ArcWeapon component, so scan the Health manager.
-- The entity hash is content/fac_helldivers/hellpod/energy_shield/energy_shield.
local function scan_towers(_)
    towers = {}
    local hm = rq(G.health)
    if not hm then state.towers = 0; return end
    local recs = rq(hm + G.hp.tbl + BUILD.hp.recs_from_tbl)
    local um = rq(G.unit)
    if not recs or not um then state.towers = 0; return end
    each_entry(hm, G.hp, function(id, row)
        if row > 0x100000 then return end
        local rec = rq(recs + row * 8)
        if not rec then return end
        local key, rid, unit = type_key(rec)
        if rid ~= id or not TOWER_TYPES[key] then return end
        if not find_row(um, G.un, id) then return end
        towers[#towers + 1] = {id = id, unit = unit}
        state.tower_weapon = string.format('FX-12 0x%X', id)
    end)
    state.towers = #towers
    if #towers == 0 then state.tower_weapon = 'no_shield_relay' end
end

-- vehicles: id -> {rec, key, unit, flags, in_range, status}
local function scan_vehicles(need_pos)
    local out = {}
    local hm = rq(G.health)
    if not hm then return out, nil end
    local recs = rq(hm + G.hp.tbl + BUILD.hp.recs_from_tbl)
    if not recs then return out, hm end
    local um = rq(G.unit)
    each_entry(hm, G.hp, function(id, row)
        if row > 0x100000 then return end
        local rec = rq(recs + row * 8)
        if not rec then return end
        local key, rid, unit, flags = type_key(rec)
        if rid ~= id or not VEHICLE_TYPES[key] then return end
        local v = {id = id, row = row, rec = rec, key = key, unit = unit, flags = flags}
        if need_pos and um and find_row(um, G.un, id) then
            local p = world_pos(unit)
            if p then
                for _, t in ipairs(towers) do
                    if t.pos and dist2(p, t.pos) <= CFG.radius * CFG.radius then v.in_range = true; break end
                end
            end
        end
        out[#out + 1] = v
    end)
    return out, hm
end

-- sentries/emplacements: known Super Earth roots plus newer static deployables with a Mount component.
-- Vehicles and the FX-12 itself are explicitly excluded.
-- Build a set containing every WeaponMagazine entity and every parent reachable through Attachable.
-- This matters for E/AT-12 and newer emplacements where the magazine sits below the mounted weapon
-- instead of being the mounted entity itself.
local function build_magazine_ancestors()
    local linked = {}
    local wmg = rq(G.wmag)
    if not wmg then return linked end
    local am = rq(G.att)
    local amrows = am and rq(am + G.at.rows)
    each_entry(wmg, G.wm, function(id, _)
        local cur, seen = id, {}
        for _ = 1, 32 do
            if not cur or cur == 0 or seen[cur] then break end
            seen[cur] = true
            linked[cur] = true
            if not am or not amrows then break end
            local row = find_row(am, G.at, cur)
            if not row then break end
            local parent = r32(amrows + row * G.at.stride)
            if not parent or parent == 0 or parent == cur then break end
            cur = parent
        end
    end)
    return linked
end

local function mount_has_magazine(id, linked)
    local mo, wmg = rq(G.mount), rq(G.wmag)
    if not mo or not wmg then return false end
    local row = find_row(mo, G.mo, id)
    local morows = row and rq(mo + G.mo.rows)
    if not row or not morows then return false end
    local b = read(morows + row * BUILD.mount.stride, 4 * BUILD.mount.slots)
    if not b then return false end
    for s = 0, BUILD.mount.slots - 1 do
        local w = u32s(b, s * 4)
        if w and w ~= 0 and (find_row(wmg, G.wm, w) or (linked and linked[w])) then return true end
    end
    return false
end

local function scan_sentries(need_pos)
    local out, names = {}, {}
    state.dynamic_sentry_roots = 0
    local linked = CFG.sentry_dynamic and build_magazine_ancestors() or nil
    local hm = rq(G.health)
    if not hm then return out, nil end
    local recs = rq(hm + G.hp.tbl + BUILD.hp.recs_from_tbl)
    local um = rq(G.unit)
    if not recs or not um then return out, hm end
    each_entry(hm, G.hp, function(id, row)
        if row > 0x100000 then return end
        local rec = rq(recs + row * 8)
        if not rec then return end
        local key, rid, unit, flags = type_key(rec)
        if rid ~= id or TOWER_TYPES[key] or VEHICLE_TYPES[key] then return end
        local known = SENTRY_TYPES[key] ~= nil
        local mo = rq(G.mount)
        local has_mount = mo and find_row(mo, G.mo, id) ~= nil
        if not known and (not CFG.sentry_dynamic or (not has_mount and not mount_has_magazine(id, linked))) then return end
        if not find_row(um, G.un, id) then return end
        if not known then state.dynamic_sentry_roots = state.dynamic_sentry_roots + 1 end
        local s = {id = id, row = row, rec = rec, key = key, unit = unit, flags = flags,
                   name = SENTRY_TYPES[key] or ('Dynamic defensive 0x' .. key)}
        if need_pos then
            local p = world_pos(unit)
            if p then
                for _, t in ipairs(towers) do
                    if t.pos and dist2(p, t.pos) <= CFG.radius * CFG.radius then s.in_range = true; break end
                end
            end
        end
        out[#out + 1] = s
        if s.in_range and #names < 8 then names[#names + 1] = string.format('0x%X:%s', id, s.name) end
    end)
    state.sentry_probe = table.concat(names, ' | ')
    if state.sentry_probe == '' then state.sentry_probe = 'none' end
    return out, hm
end


-- =======================================================================================
-- Sentry Ammo Model v3.7.6
-- 3D world-space geometry only. No world_to_screen, no screen GUI, no world GUI.
-- The marker is rendered through a depth-tested Stingray LineObject so terrain/rocks/walls
-- occlude it naturally as part of the 3D scene.

local MODEL_TITLE = '哨戒炮弹药模型'
local MODEL_VERSION = '3.7.6'
local MC = {
    enabled = true,
    max_distance = 110.0,
    scale = 0.36,
    height = 2.40,
    opacity = 70,
    low_color = true,
    scan_every = 6,
}

state.model_version = MODEL_VERSION
state.model_rows = 0
state.model_drawn = 0
state.model_status = 'starting'
state.model_error = 'none'
state.model_option_links = {}
state.model_world = nil
state.model_line = nil
state.model_line_created = 0
state.model_line_errors = 0
state.ac8_spatial_claims = 0
state.spatial_claims = 0
state.unowned_magazines = 0
state.unowned_detail = 'none'
state.render_mode = '3d_depth_tested_line_model'
state.last_model_diag = ''

local function model_log(message)
    state.model_status = tostring(message)
    pcall(function()
        local f = loader.open_log and loader.open_log('SentryAmmoModel.log')
        if f then
            f:write('version=' .. MODEL_VERSION .. '\n')
            f:write('status=' .. tostring(state.model_status) .. '\n')
            f:write('build_mode=' .. tostring(state.build_mode) .. '\n')
            f:write('rows=' .. tostring(state.model_rows or 0) .. '\n')
            f:write('drawn=' .. tostring(state.model_drawn or 0) .. '\n')
            f:write('render_mode=' .. tostring(state.render_mode) .. '\n')
            f:write('line_created=' .. tostring(state.model_line_created or 0) .. '\n')
            f:write('line_errors=' .. tostring(state.model_line_errors or 0) .. '\n')
            f:write('component_status=' .. tostring(state.component_status or 'none') .. '\n')
            f:write('roots=' .. tostring(state.root_detail or 'none') .. '\n')
            f:write('owned=' .. tostring(state.owned_detail or 'none') .. '\n')
            f:write('claims=entity:' .. tostring(state.claim_entity or 0) .. ',mount:' .. tostring(state.claim_mount or 0) .. ',unit:' .. tostring(state.claim_unit or 0) .. ',goid:' .. tostring(state.claim_goid or 0) .. ',spatial:' .. tostring(state.claim_spatial or 0) .. ',mount_fallback:' .. tostring(state.claim_mount_fallback or 0) .. ',feed_fallback:' .. tostring(state.claim_feed_fallback or 0) .. '\n')
            f:write('components=mag:' .. tostring(state.mag_components or 0) .. ',rounds:' .. tostring(state.round_components or 0) .. '\n')
            f:write('ac8_spatial_claims=' .. tostring(state.ac8_spatial_claims or 0) .. '\n')
            f:write('spatial_claims=' .. tostring(state.spatial_claims or 0) .. '\n')
            f:write('unowned_magazines=' .. tostring(state.unowned_magazines or 0) .. '\n')
            f:write('player_filtered=' .. tostring(state.player_filtered or 0) .. '\n')
            f:write('ac8_claims=' .. tostring(state.ac8_claims or 0) .. '\n')
            f:write('unowned_detail=' .. tostring(state.unowned_detail or 'none') .. '\n')
            f:write('opacity=' .. tostring(MC.opacity) .. '\n')
            f:write('error=' .. tostring(state.model_error or 'none') .. '\n')
            f:close()
        end
    end)
end

pcall(function()
    local f = loader.open_log and loader.open_log('SentryAmmoModel_BOOT.log')
    if f then f:write('BOOT ' .. MODEL_VERSION .. ' - 3D model entry executed\n'); f:close() end
end)

-- Optional Mod Options Menu.
local OPTION_SPECS = {
    {key='enabled', id='codex.sentry_ammo_model.enabled', type='toggle', label='显示哨戒炮弹药模型',
     description='在哨戒炮上方生成真实的3D弹药标记模型。模型参与场景深度遮挡，不使用屏幕投影。', default=true},
    {key='max_distance', id='codex.sentry_ammo_model.distance', type='slider', label='最大显示距离（米）',
     description='超过此距离不生成弹药模型。', min=20,max=200,step=10,default=110},
    {key='scale', id='codex.sentry_ammo_model.scale', type='slider', label='3D标记大小',
     description='调整图标和数字模型的整体大小。调整战备图标和数字模型的整体大小。', min=0.10,max=1.2,step=0.05,default=0.36},
    {key='height', id='codex.sentry_ammo_model.height', type='slider', label='标记悬浮高度',
     description='调整3D弹药模型位于哨戒炮上方的高度。', min=1.0,max=4.0,step=0.1,default=2.4},
    {key='opacity', id='codex.sentry_ammo_model.opacity', type='slider', label='标记透明度（%）',
     description='调整3D标记透明度。数值越低越不挡视野。', min=0,max=100,step=5,default=70},
    {key='low_color', id='codex.sentry_ammo_model.low_color', type='toggle', label='低弹药变色',
     description='弹药低于50%时变黄，低于20%时变红。', default=true},
}

local function menu_step()
    local menu = rawget(_G, 'ModOptionsMenu')
    if type(menu) ~= 'table' or menu.api ~= 1 or type(menu.register_option) ~= 'function' or type(menu.get) ~= 'function' then return end
    local ver = tonumber(menu.version) or 1
    for _,spec in ipairs(OPTION_SPECS) do
        if state.model_option_links[spec.id] == nil then
            state.model_option_links[spec.id] = false
            if spec.type ~= 'slider' or ver >= 2 then
                local data = {type=spec.type,mod=MODEL_TITLE,label=spec.label,description=spec.description,default=spec.default}
                if spec.type == 'slider' then data.min,data.max,data.step = spec.min,spec.max,spec.step end
                local ok,accepted = pcall(menu.register_option, spec.id, data)
                if ok and accepted == true then
                    state.model_option_links[spec.id] = true
                    if type(menu.on_change) == 'function' then
                        local key = spec.key
                        pcall(menu.on_change, spec.id, function(v)
                            if (key == 'enabled' or key == 'low_color') and type(v) == 'boolean' then MC[key] = v
                            elseif key ~= 'enabled' and key ~= 'low_color' and type(v) == 'number' and v == v then MC[key] = v end
                        end)
                    end
                end
            end
        end
        if state.model_option_links[spec.id] then
            local ok,v = pcall(menu.get, spec.id)
            if ok then
                if (spec.key == 'enabled' or spec.key == 'low_color') and type(v) == 'boolean' then MC[spec.key] = v
                elseif spec.key ~= 'enabled' and spec.key ~= 'low_color' and type(v) == 'number' and v == v then MC[spec.key] = v end
            end
        end
    end
end

-- Current-ammo scan. The normal Mount/Attachable ownership remains first choice.
-- If it fails, a narrow spatial fallback is used only around verified defensive roots.
local RAW_AMMO_COMPONENTS = {
    {name='mag', root=0x3326648, table_off=0x20, desc_off=0x38, data_off=0x50, stride=12},
    {name='rounds', root=0x3326CF0, table_off=0x28, desc_off=0x40, data_off=0x58, stride=20},
}

local function sane_u32(v, limit)
    return type(v)=='number' and v>=0 and v<=limit
end

local function descriptor_fields(p)
    local b = p and read(p,24)
    if not b then return nil end
    return {
        resource = string.format('%08X%08X',u32s(b,4),u32s(b,0)),
        entity = u32s(b,8), unit = u32s(b,12), goid = u32s(b,16), flags = u32s(b,20),
    }
end

local function raw_component_rows(spec)
    local manager = rq(game + spec.root)
    if not manager then return {},'manager_not_ready' end
    local tb = read(manager + spec.table_off,20)
    if not tb then return {},'table_header_unreadable' end
    local entries,cap,empty = ptrs(tb,0),u32s(tb,8),u32s(tb,12)
    if not entries or not cap or cap==0 or cap>65536 then return {},'table_invalid' end
    local pow=1 while pow<cap do pow=pow*2 end
    if pow~=cap then return {},'capacity_not_power2' end
    local descs = rq(manager + spec.desc_off)
    local data = rq(manager + spec.data_off)
    if not descs or not data then return {},'arrays_not_ready' end
    local raw = read(entries,cap*8)
    if not raw then return {},'index_unreadable' end
    local out={}
    for i=0,cap-1 do
        local entity,j=u32s(raw,i*8),u32s(raw,i*8+4)
        if entity~=empty and j~=0xFFFFFFFF and j<0x100000 then
            local dp=rq(descs+j*8)
            local d=descriptor_fields(dp)
            if d and d.entity==entity then
                local row=read(data+j*spec.stride,spec.stride)
                if row then out[#out+1]={d=d,row=row,j=j,spec=spec} end
            end
        end
    end
    return out,'ok'
end

local function mag_config(entity)
    local wmg=rq(G.wmag)
    if not wmg then return nil,nil end
    local row=find_row(wmg,G.wm,entity)
    local recs=rq(wmg+G.wm.recs)
    if not row or not recs then return nil,nil end
    local rec=rq(recs+row*8)
    if not rec then return nil,nil end
    local cfg=call('magcfg',G.magcfg,addr(rec))
    if cfg==nil then return nil,nil end
    local cb=read(num(cfg),0x98)
    if not cb then return nil,nil end
    local cap,maxm=i32s(cb,BUILD.wm.cfg_cap),i32s(cb,BUILD.wm.cfg_max)
    if not sane_u32(cap,100000) or cap<1 then cap=nil end
    if not sane_u32(maxm,10000) then maxm=nil end
    return cap,maxm
end

local KNOWN_SENTRY_MAG_RESOURCES = {
    ['B6AFF2195568767F'] = true,
    ['89C5493E08CA4207'] = true,
}

-- Observed hostile ranged-unit magazine resources. These are never valid sentry display feeds.
-- A6A735ACCB4A327F was observed on the Terminid ranged unit that produced the false sentry icon.
local HOSTILE_MAG_RESOURCES = {
    ['A6A735ACCB4A327F'] = true,
}

-- Confirmed/expected sentry magazine feeds that can exist without a root visible to the old sentry scanner.
-- 820CC3BAFE962858 was observed live at cap=600 and matches A/FLAM-40's Runtime/ModBuilder capacity.
-- 299C0D3DFD2F0994 was observed live at cap=16 and matches A/M-23 EMS Mortar's zero-spare feed.
local SPECIAL_SENTRY_FEEDS = {
    ['820CC3BAFE962858'] = 'flame',
    ['299C0D3DFD2F0994'] = 'ems',
}

local function is_ac8_feed(cap)
    cap=tonumber(cap) or 0
    -- Keep the v3.7.2 AC-8 fallback, but only for the actual AC-8 feed sizes we have seen.
    -- This deliberately excludes the hostile 250-round feed that caused the bile-unit false positive.
    return cap==24 or cap==36 or cap==48 or cap==72 or cap==200
end

local function classify_mag_feed(cap,maxm,remaining,maximum)
    -- Match the actual defensive sentry feed families. A/AC-8 is a single-feed
    -- autocannon (24 vanilla / 200 with the user's sentry rebalance), while the
    -- Gatling uses a very large belt. This is only a display classifier.
    cap=tonumber(cap) or 0; maxm=tonumber(maxm) or 0
    maximum=tonumber(maximum) or 0
    if cap==24 or cap==48 or cap==72 or cap==200 then return 'cannon' end
    if cap>=350 or maximum>=350 then return 'gatling' end
    return 'mg'
end

local function collect_sentry_ammo()
    local sentries=scan_sentries(false)
    local roots,root_by_id={},{}
    for _,st in ipairs(sentries or {}) do
        local p=world_pos(st.unit)
        if p then
            local r={id=st.id,key=st.key,name=st.name,pos=p,unit=st.unit,remaining=0,maximum=0,parts=0,kind='mg',sources={},verified=true,pseudo=false,known_root=(SENTRY_TYPES[st.key]~=nil)}
            roots[st.id]=r; root_by_id[st.id]=r
        end
    end

    local set,mount_owner,mountlist={}, {}, {}
    for rid in pairs(roots) do set[rid]=true end
    local mo=rq(G.mount)
    local morows=mo and rq(mo+G.mo.rows)
    if mo and morows then
        for rid in pairs(roots) do
            local row=find_row(mo,G.mo,rid)
            if row then
                local b=read(morows+row*BUILD.mount.stride,4*BUILD.mount.slots)
                if b then
                    for slot=0,BUILD.mount.slots-1 do
                        local w=u32s(b,slot*4)
                        if w and w~=0 then mountlist[w]=true; mount_owner[w]=rid end
                    end
                end
            end
        end
    end

    local am=rq(G.att)
    local amrows=am and rq(am+G.at.rows)
    local function linked_owner(id)
        local cur,seen=id,{}
        for _=1,40 do
            if set[cur] then return cur,'root' end
            if mount_owner[cur] then return mount_owner[cur],'mount' end
            if seen[cur] then return nil end
            seen[cur]=true
            if not am or not amrows then return nil end
            local row=find_row(am,G.at,cur)
            if not row then return nil end
            local parent=r32(amrows+row*G.at.stride)
            if not parent or parent==0 or parent==cur then return nil end
            cur=parent
        end
        return nil
    end

    state.claim_entity,state.claim_mount,state.claim_unit,state.claim_goid,state.claim_goid_near,state.claim_spatial=0,0,0,0,0,0
    state.claim_mount_fallback,state.claim_feed_fallback=0,0
    state.mag_components,state.round_components,state.unowned_magazines=0,0,0
    state.player_filtered=0
    state.ac8_claims=0
    local unowned={}
    local pseudo_rows={}

    local function classify_kind(cap,maxm,key)
        if not cap then return nil end
        if SPECIAL_SENTRY_FEEDS[key] then return SPECIAL_SENTRY_FEEDS[key] end
        -- Current Runtime/ModBuilder sentry capacities. These feeds use no spare magazines.
        if cap==600 and maxm==0 then return 'flame' end
        if cap==400 and maxm==0 then return 'tesla' end
        if cap==36 and maxm==0 then return 'mortar' end
        if cap==16 and maxm==0 then return 'ems' end
        if cap<=8 and maxm and maxm>=4 and maxm<=12 then return 'rocket' end
        -- Keep AC-8 pseudo detection, but after mortar/EMS so their distinctive zero-spare feeds win.
        if is_ac8_feed(cap) and maxm and maxm<=4 then return 'cannon' end
        if cap>=450 and cap<=800 and (maxm==0 or maxm==1) then return 'gatling' end
        if cap>=80 and cap<=220 and (maxm==0 or maxm==1) then return 'mg' end
        return nil
    end
    local function pseudo_bucket(pos,kind)
        return string.format('%s:%d:%d:%d',kind,math.floor(pos.x*2+0.5),math.floor(pos.y*2+0.5),math.floor(pos.z*2+0.5))
    end
    local function get_or_create_pseudo(id,key,unit,pos,kind)
        local bucket=pseudo_bucket(pos,kind)
        local pr=pseudo_rows[bucket]
        if pr then return pr end
        pr={id=id,key='PSEUDO_'..kind,name='Pseudo '..kind,pos=pos,unit=unit,remaining=0,maximum=0,parts=0,kind=kind,sources={},verified=true,pseudo=true,known_root=false}
        pseudo_rows[bucket]=pr
        roots[id]=pr; root_by_id[id]=pr; set[id]=true
        return pr
    end

    local wmg=rq(G.wmag)
    local wrecs=wmg and rq(wmg+G.wm.recs)
    local wrows=wmg and rq(wmg+G.wm.rows)
    if not wmg or not wrecs or not wrows then
        state.component_status='mag=manager_not_ready'
        state.root_detail='none'
        state.owned_detail='none'
        return {}
    end

    each_entry(wmg,G.wm,function(id,rowidx)
        if rowidx>0x100000 then return end
        local rec=rq(wrecs+rowidx*8); if not rec then return end
        local key,rid,unit,flags=type_key(rec); if rid~=id then return end
        local cfg=call('magcfg',G.magcfg,addr(rec)); if cfg==nil then return end
        local cb=read(num(cfg),0x98); if not cb then return end
        local cap,maxm=i32s(cb,BUILD.wm.cfg_cap),i32s(cb,BUILD.wm.cfg_max)
        if not cap or cap<=0 or cap>100000 or maxm==nil or maxm<0 or maxm>10000 then return end
        local mb=read(wrows+rowidx*BUILD.wm.stride,8); if not mb then return end
        local mags,rounds=i32s(mb,0),i32s(mb,4)
        if not sane_u32(rounds,1000000) or not sane_u32(mags,100000) then return end
        state.mag_components=state.mag_components+1

        -- Hard reject the hostile feed that was producing a sentry icon in v3.7.2.
        if HOSTILE_MAG_RESOURCES[key] then
            state.player_filtered=state.player_filtered+1
            if #unowned<12 then unowned[#unowned+1]=string.format('%X:%s cap=%d maxm=%d rounds=%d mags=%d HOSTILE',id,tostring(key),cap,maxm,rounds,mags) end
            return
        end

        local owner,why=linked_owner(id)
        local kind_guess=classify_kind(cap,maxm,key)

        -- Dynamic roots are kept enabled so A/AC-8 still appears exactly as in v3.7.2,
        -- but an unknown root must carry a plausible sentry feed before it can be displayed.
        if owner and roots[owner] and not roots[owner].known_root and not kind_guess then
            state.player_filtered=state.player_filtered+1
            if #unowned<12 then unowned[#unowned+1]=string.format('%X:%s cap=%d maxm=%d rounds=%d mags=%d NONSENTRY',id,tostring(key),cap,maxm,rounds,mags) end
            return
        end

        local allow_pseudo = (kind_guess=='cannon' or kind_guess=='mortar' or kind_guess=='ems' or kind_guess=='flame' or kind_guess=='tesla')
        if not owner and allow_pseudo and unit and unit~=0 and unit~=0xFFFFFFFF then
            local p=world_pos(unit)
            if p then
                local pr=get_or_create_pseudo(id,key,unit,p,kind_guess)
                owner=pr.id; why='pseudo'
                if kind_guess=='cannon' then state.ac8_claims=(state.ac8_claims or 0)+1 end
            end
        end
        if not owner or not roots[owner] then
            state.player_filtered=state.player_filtered+1
            if #unowned<12 then unowned[#unowned+1]=string.format('%X:%s cap=%d maxm=%d rounds=%d mags=%d',id,tostring(key),cap,maxm,rounds,mags) end
            return
        end
        if why=='mount' then state.claim_mount=state.claim_mount+1
        elseif why=='pseudo' then state.claim_feed_fallback=(state.claim_feed_fallback or 0)+1
        else state.claim_entity=state.claim_entity+1 end

        local remaining=rounds + mags*cap
        local maximum=cap*(1+maxm)
        if maximum<remaining then maximum=remaining end
        local r=roots[owner]
        r.remaining=r.remaining+remaining; r.maximum=r.maximum+maximum; r.parts=r.parts+1
        r.sources[#r.sources+1]=string.format('mag:%s=%d/%d cap=%d maxm=%d',tostring(key),remaining,maximum,cap,maxm)

        if r.kind=='cannon' then
            -- keep cannon
        elseif r.key=='37079568DC86E9C6' then r.kind='rocket'
        elseif r.key=='51A0812E3BCE2D74' then if kind_guess=='ems' then r.kind='ems' else r.kind='mortar' end
        elseif r.key=='37CDE43876BA26BB' or r.key=='0E977C49DB7604F9' or r.key=='A970CBA66FBEAA11' then r.kind='mg'
        elseif r.key=='7FF0FD4572F5996F' then r.kind='gatling'
        elseif r.key=='EF85D6CF58E31D70' then
            if kind_guess=='cannon' then r.kind='cannon'; state.ac8_claims=state.ac8_claims+1 else r.kind='gatling' end
        else
            if kind_guess then r.kind=kind_guess end
        end
    end)

    state.component_status='mag=ok:'..tostring(state.mag_components)
    state.unowned_magazines=state.player_filtered
    state.unowned_detail=#unowned>0 and table.concat(unowned,' | ') or 'none'
    local out,details,root_names={},{},{}
    for _,r in pairs(roots) do
        root_names[#root_names+1]=string.format('%X:%s',r.id,tostring(r.key))
        if r.parts>0 then
            out[#out+1]=r
            if #details<16 then details[#details+1]=string.format('%X:%s:%s %d/%d [%s]',r.id,tostring(r.key),r.kind,r.remaining,r.maximum,table.concat(r.sources,',')) end
        end
    end
    table.sort(root_names); table.sort(out,function(a,b) return a.id<b.id end)
    state.root_detail=#root_names>0 and table.concat(root_names,' | ') or 'none'
    state.owned_detail=#details>0 and table.concat(details,' | ') or 'none'
    return out
end


local sr = rawget(_G,'stingray') or rawget(_G,'s3d')

local function main_world()
    if not sr or not sr.Application or type(sr.Application.main_world) ~= 'function' then return nil end
    local ok,w = pcall(sr.Application.main_world)
    if ok then return w end
    return nil
end

local function release_model()
    if state.model_line and state.model_world and sr and sr.World and type(sr.World.destroy_line_object) == 'function' then
        pcall(sr.World.destroy_line_object,state.model_world,state.model_line)
    end
    state.model_line = nil
    state.model_world = nil
end

local function ensure_model(world)
    if not sr or not sr.World or not sr.LineObject or type(sr.World.create_line_object) ~= 'function' then return false end
    if state.model_line and state.model_world == world then return true end
    release_model()
    local ok,line = pcall(sr.World.create_line_object,world,false)
    if not ok or not line then
        state.model_line_errors = state.model_line_errors + 1
        state.model_error = tostring(line)
        return false
    end
    state.model_world = world
    state.model_line = line
    state.model_line_created = state.model_line_created + 1
    return true
end

local SEGMENTS = {
    ['0']={1,2,3,5,6,7}, ['1']={3,6}, ['2']={1,3,4,5,7}, ['3']={1,3,4,6,7},
    ['4']={2,3,4,6}, ['5']={1,2,4,6,7}, ['6']={1,2,4,5,6,7}, ['7']={1,3,6},
    ['8']={1,2,3,4,5,6,7}, ['9']={1,2,3,4,6,7},
}
local SEG_COORD = {
    [1]={-0.30,0.42, 0.30,0.42}, [2]={-0.34,0.38,-0.34,0.02}, [3]={0.34,0.38,0.34,0.02},
    [4]={-0.30,0.00,0.30,0.00}, [5]={-0.34,-0.02,-0.34,-0.38}, [6]={0.34,-0.02,0.34,-0.38},
    [7]={-0.30,-0.42,0.30,-0.42},
}
local function point(center,right,up,x,y,scale)
    return center + right*(x*scale) + up*(y*scale)
end
local function add_thick_line(line,color,center,right,up,x1,y1,x2,y2,scale,thick)
    local p1=point(center,right,up,x1,y1,scale)
    local p2=point(center,right,up,x2,y2,scale)
    sr.LineObject.add_line(line,color,p1,p2)
    local dx,dy=x2-x1,y2-y1
    local len=math.sqrt(dx*dx+dy*dy)
    if len>0.0001 then
        local ox,oy=-dy/len*thick,dx/len*thick
        sr.LineObject.add_line(line,color,point(center,right,up,x1+ox,y1+oy,scale),point(center,right,up,x2+ox,y2+oy,scale))
        sr.LineObject.add_line(line,color,point(center,right,up,x1-ox,y1-oy,scale),point(center,right,up,x2-ox,y2-oy,scale))
    end
end
local function add_digit(line,ch,center,right,up,scale,color)
    local segs=SEGMENTS[ch]; if not segs then return end
    for _,n in ipairs(segs) do
        local c=SEG_COORD[n]
        add_thick_line(line,color,center,right,up,c[1],c[2],c[3],c[4],scale,0.020)
    end
end
local function add_number(line,value,center,right,up,scale,color)
    local text=tostring(math.max(0,math.floor((tonumber(value) or 0)+0.5)))
    if #text>4 then text=text:sub(#text-3) end
    local spacing=0.84
    local start=-(#text-1)*spacing*0.5
    for i=1,#text do
        local c=center+right*((start+(i-1)*spacing)*scale)
        add_digit(line,text:sub(i,i),c,right,up,scale,color)
    end
end

-- v3.7.1 ORIGINAL GAME ICONS (transparent-clean variant).
-- Uses the exported game SVG layers but intentionally drops the dark background layer so the icon stays transparent and unobtrusive in gameplay.
local ORIGINAL_ICON_RES = 64
local ORIGINAL_ICON_RUNS = {
  mg={bg={{0,0,63},{1,0,63},{2,0,63},{3,0,63},{4,0,63},{5,0,63},{6,0,63},{7,0,63},{8,0,63},{9,0,63},{10,0,63},{11,0,17},{11,31,36},{11,56,63},{12,0,17},{12,34,38},{12,56,63},{13,0,20},{13,36,39},{13,56,63},{14,0,25},{14,38,40},{14,56,63},{15,0,7},{15,22,26},{15,39,41},{15,56,63},{16,0,7},{16,26,29},{16,40,42},{16,56,63},{17,0,7},{17,26,29},{17,41,43},{17,56,63},{18,0,7},{18,22,26},{18,42,63},{19,0,25},{19,43,63},{20,0,24},{20,43,63},{21,0,7},{21,22,27},{21,44,63},{22,0,7},{22,26,28},{22,44,63},{23,0,7},{23,26,29},{23,44,63},{24,0,7},{24,22,26},{24,45,63},{25,0,25},{25,45,63},{26,0,24},{26,45,63},{27,0,7},{27,22,27},{27,46,63},{28,0,7},{28,26,28},{28,46,63},{29,0,7},{29,26,29},{29,46,63},{30,0,7},{30,22,26},{30,46,63},{31,0,25},{31,46,63},{32,0,20},{32,46,63},{33,0,17},{33,46,63},{34,0,17},{34,46,63},{35,0,63},{36,0,63},{37,0,63},{38,0,63},{39,0,63},{40,0,63},{41,0,63},{42,0,63},{43,0,63},{44,0,63},{45,0,63},{46,0,17},{46,46,63},{47,0,16},{47,47,63},{48,0,15},{48,48,63},{49,0,14},{49,49,63},{50,0,13},{50,50,63},{51,0,12},{51,51,63},{52,0,11},{52,52,63},{53,0,63},{54,0,63},{55,0,63},{56,0,63},{57,0,63},{58,0,63},{59,0,63},{60,0,63},{61,0,63},{62,0,63},{63,0,63}},green={{11,18,30},{11,37,55},{12,18,33},{12,39,55},{13,21,35},{13,40,55},{14,26,37},{14,41,55},{15,20,21},{15,27,38},{15,42,55},{16,25,25},{16,30,39},{16,43,55},{17,25,25},{17,30,40},{17,44,55},{18,20,21},{18,27,41},{19,26,42},{20,25,42},{21,20,21},{21,28,43},{22,25,25},{22,29,43},{23,25,25},{23,30,43},{24,20,21},{24,27,44},{25,26,44},{26,25,44},{27,20,21},{27,28,45},{28,25,25},{28,29,45},{29,25,25},{29,30,45},{30,20,21},{30,27,45},{31,26,45},{32,21,45},{33,18,45},{34,18,45},{46,18,45},{47,17,46},{48,16,47},{49,15,48},{50,14,49},{51,13,50},{52,12,51}},white={{15,8,19},{16,8,24},{17,8,24},{18,8,19},{21,8,19},{22,8,24},{23,8,24},{24,8,19},{27,8,19},{28,8,24},{29,8,24},{30,8,19}}},
  gatling={bg={{0,0,63},{1,0,63},{2,0,63},{3,0,63},{4,0,63},{5,0,63},{6,0,63},{7,0,63},{8,0,63},{9,0,63},{10,0,63},{11,0,17},{11,31,36},{11,56,63},{12,0,17},{12,34,38},{12,56,63},{13,0,17},{13,36,39},{13,56,63},{14,0,20},{14,38,40},{14,56,63},{15,0,24},{15,39,41},{15,56,63},{16,0,7},{16,22,26},{16,40,42},{16,56,63},{17,0,7},{17,26,28},{17,41,43},{17,56,63},{18,0,7},{18,26,28},{18,42,63},{19,0,7},{19,22,27},{19,43,63},{20,0,24},{20,43,63},{21,0,25},{21,44,63},{22,0,7},{22,22,26},{22,44,63},{23,0,7},{23,26,29},{23,44,63},{24,0,7},{24,26,28},{24,45,63},{25,0,7},{25,22,27},{25,45,63},{26,0,24},{26,45,63},{27,0,25},{27,46,63},{28,0,7},{28,22,26},{28,46,63},{29,0,7},{29,26,29},{29,46,63},{30,0,7},{30,26,28},{30,46,63},{31,0,7},{31,22,27},{31,46,63},{32,0,25},{32,46,63},{33,0,25},{33,46,63},{34,0,7},{34,22,27},{34,46,63},{35,0,7},{35,26,63},{36,0,7},{36,26,63},{37,0,7},{37,22,27},{37,42,63},{38,0,25},{38,42,63},{39,0,25},{39,42,63},{40,0,7},{40,22,27},{40,42,63},{41,0,7},{41,26,29},{41,42,63},{42,0,7},{42,26,29},{42,42,63},{43,0,7},{43,22,27},{43,42,63},{44,0,63},{45,0,63},{46,0,17},{46,46,63},{47,0,16},{47,47,63},{48,0,15},{48,48,63},{49,0,14},{49,49,63},{50,0,13},{50,50,63},{51,0,12},{51,51,63},{52,0,11},{52,52,63},{53,0,63},{54,0,63},{55,0,63},{56,0,63},{57,0,63},{58,0,63},{59,0,63},{60,0,63},{61,0,63},{62,0,63},{63,0,63}},green={{11,18,30},{11,37,55},{12,18,33},{12,39,55},{13,18,35},{13,40,55},{14,21,37},{14,41,55},{15,25,38},{15,42,55},{16,20,21},{16,27,39},{16,43,55},{17,25,25},{17,29,40},{17,44,55},{18,25,25},{18,29,41},{19,20,21},{19,28,42},{20,25,42},{21,26,43},{22,20,21},{22,27,43},{23,25,25},{23,30,43},{24,25,25},{24,29,44},{25,20,21},{25,28,44},{26,25,44},{27,26,45},{28,20,21},{28,27,45},{29,25,25},{29,30,45},{30,25,25},{30,29,45},{31,20,21},{31,28,45},{32,26,45},{33,26,45},{34,20,21},{34,28,45},{35,25,25},{36,25,25},{37,20,21},{37,28,41},{38,26,41},{39,26,41},{40,20,21},{40,28,41},{41,25,25},{41,30,41},{42,25,25},{42,30,41},{43,20,21},{43,28,41},{46,18,45},{47,17,46},{48,16,47},{49,15,48},{50,14,49},{51,13,50},{52,12,51}},white={{16,8,19},{17,8,24},{18,8,24},{19,8,19},{22,8,19},{23,8,24},{24,8,24},{25,8,19},{28,8,19},{29,8,24},{30,8,24},{31,8,19},{34,8,19},{35,8,24},{36,8,24},{37,8,19},{40,8,19},{41,8,24},{42,8,24},{43,8,19}}},
  cannon={bg={{0,0,63},{1,0,63},{2,0,63},{3,0,63},{4,0,63},{5,0,63},{6,0,63},{7,0,63},{8,0,63},{9,0,63},{10,0,63},{11,0,17},{11,31,36},{11,56,63},{12,0,17},{12,34,38},{12,56,63},{13,0,17},{13,36,39},{13,56,63},{14,0,17},{14,38,40},{14,56,63},{15,0,24},{15,39,41},{15,56,63},{16,0,26},{16,40,42},{16,56,63},{17,0,7},{17,17,19},{17,25,26},{17,41,43},{17,56,63},{18,0,7},{18,16,18},{18,26,27},{18,42,63},{19,0,7},{19,15,17},{19,26,27},{19,43,63},{20,0,7},{20,14,16},{20,26,27},{20,43,63},{21,0,7},{21,13,15},{21,26,27},{21,44,63},{22,0,7},{22,12,14},{22,25,26},{22,44,63},{23,0,26},{23,44,63},{24,0,26},{24,45,63},{25,0,7},{25,17,19},{25,25,26},{25,45,63},{26,0,7},{26,16,18},{26,26,27},{26,45,63},{27,0,7},{27,15,17},{27,26,27},{27,46,63},{28,0,7},{28,14,16},{28,26,27},{28,46,63},{29,0,7},{29,13,15},{29,26,27},{29,46,63},{30,0,7},{30,12,14},{30,25,26},{30,46,63},{31,0,26},{31,46,63},{32,0,26},{32,46,63},{33,0,7},{33,17,19},{33,25,26},{33,46,63},{34,0,7},{34,16,18},{34,26,27},{34,46,63},{35,0,7},{35,15,17},{35,26,63},{36,0,7},{36,14,16},{36,26,63},{37,0,7},{37,13,15},{37,26,27},{37,42,63},{38,0,7},{38,12,14},{38,25,26},{38,42,63},{39,0,25},{39,42,63},{40,0,24},{40,42,63},{41,0,21},{41,42,63},{42,0,21},{42,42,63},{43,0,21},{43,42,63},{44,0,63},{45,0,63},{46,0,17},{46,46,63},{47,0,16},{47,47,63},{48,0,15},{48,48,63},{49,0,14},{49,49,63},{50,0,13},{50,50,63},{51,0,12},{51,51,63},{52,0,11},{52,52,63},{53,0,63},{54,0,63},{55,0,63},{56,0,63},{57,0,63},{58,0,63},{59,0,63},{60,0,63},{61,0,63},{62,0,63},{63,0,63}},green={{11,18,30},{11,37,55},{12,18,33},{12,39,55},{13,18,35},{13,40,55},{14,18,37},{14,41,55},{15,25,38},{15,42,55},{16,27,39},{16,43,55},{17,24,24},{17,27,40},{17,44,55},{18,25,25},{18,28,41},{19,28,42},{20,28,42},{21,25,25},{21,28,43},{22,24,24},{22,27,43},{23,27,43},{24,27,44},{25,24,24},{25,27,44},{26,25,25},{26,28,44},{27,28,45},{28,28,45},{29,25,25},{29,28,45},{30,24,24},{30,27,45},{31,27,45},{32,27,45},{33,24,24},{33,27,45},{34,25,25},{34,28,45},{37,25,25},{37,28,41},{38,24,24},{38,27,41},{39,26,41},{40,25,41},{41,22,41},{42,22,41},{43,22,41},{46,18,45},{47,17,46},{48,16,47},{49,15,48},{50,14,49},{51,13,50},{52,12,51}},white={{17,8,16},{17,20,23},{18,8,15},{18,19,24},{19,8,14},{19,18,25},{20,8,13},{20,17,25},{21,8,12},{21,16,24},{22,8,11},{22,15,23},{25,8,16},{25,20,23},{26,8,15},{26,19,24},{27,8,14},{27,18,25},{28,8,13},{28,17,25},{29,8,12},{29,16,24},{30,8,11},{30,15,23},{33,8,16},{33,20,23},{34,8,15},{34,19,24},{35,8,14},{35,18,25},{36,8,13},{36,17,25},{37,8,12},{37,16,24},{38,8,11},{38,15,23}}},
  mortar={bg={{0,0,63},{1,0,63},{2,0,63},{3,0,63},{4,0,63},{5,0,63},{6,0,63},{7,0,63},{8,0,63},{9,0,63},{10,0,63},{11,0,18},{11,22,23},{11,31,36},{11,56,63},{12,0,17},{12,23,24},{12,35,38},{12,56,63},{13,0,17},{13,23,24},{13,37,39},{13,56,63},{14,0,17},{14,23,24},{14,38,40},{14,56,63},{15,0,16},{15,24,25},{15,39,41},{15,56,63},{16,0,16},{16,24,25},{16,40,42},{16,56,63},{17,0,16},{17,24,25},{17,41,43},{17,56,63},{18,0,15},{18,25,26},{18,42,63},{19,0,15},{19,25,26},{19,43,63},{20,0,15},{20,25,26},{20,43,63},{21,0,14},{21,26,27},{21,44,63},{22,0,14},{22,26,27},{22,44,63},{23,0,14},{23,26,27},{23,44,63},{24,0,14},{24,26,27},{24,45,63},{25,0,14},{25,26,26},{25,45,63},{26,0,15},{26,25,26},{26,45,63},{27,0,15},{27,25,26},{27,46,63},{28,0,15},{28,25,25},{28,46,63},{29,0,16},{29,24,25},{29,46,63},{30,0,16},{30,24,25},{30,46,63},{31,0,16},{31,24,24},{31,46,63},{32,0,17},{32,23,24},{32,46,63},{33,0,17},{33,23,24},{33,46,63},{34,0,17},{34,23,23},{34,46,63},{35,0,18},{35,22,63},{36,0,18},{36,22,63},{37,0,18},{37,22,23},{37,42,63},{38,0,18},{38,22,23},{38,42,63},{39,0,17},{39,23,24},{39,42,63},{40,0,16},{40,24,25},{40,42,63},{41,0,15},{41,25,26},{41,42,63},{42,0,15},{42,25,26},{42,42,63},{43,0,15},{43,25,26},{43,42,63},{44,0,15},{44,25,63},{45,0,15},{45,25,63},{46,0,15},{46,25,26},{46,46,63},{47,0,26},{47,47,63},{48,0,26},{48,48,63},{49,0,14},{49,49,63},{50,0,13},{50,50,63},{51,0,12},{51,51,63},{52,0,11},{52,52,63},{53,0,63},{54,0,63},{55,0,63},{56,0,63},{57,0,63},{58,0,63},{59,0,63},{60,0,63},{61,0,63},{62,0,63},{63,0,63}},green={{11,24,30},{11,37,55},{12,18,18},{12,22,22},{12,25,34},{12,39,55},{13,25,36},{13,40,55},{14,25,37},{14,41,55},{15,17,17},{15,23,23},{15,26,38},{15,42,55},{16,26,39},{16,43,55},{17,26,40},{17,44,55},{18,16,16},{18,24,24},{18,27,41},{19,27,42},{20,27,42},{21,15,15},{21,25,25},{21,28,43},{22,28,43},{23,28,43},{24,15,15},{24,25,25},{24,28,44},{25,15,15},{25,25,25},{25,27,44},{26,27,44},{27,16,16},{27,24,24},{27,27,45},{28,16,16},{28,24,24},{28,26,45},{29,26,45},{30,17,17},{30,23,23},{30,26,45},{31,17,17},{31,23,23},{31,25,45},{32,25,45},{33,18,18},{33,22,22},{33,25,45},{34,18,18},{34,22,22},{34,24,45},{37,24,41},{38,24,41},{39,18,18},{39,22,22},{39,25,41},{40,23,23},{40,26,41},{41,24,24},{41,27,41},{42,27,41},{43,27,41},{46,27,45},{47,27,46},{48,27,47},{49,15,48},{50,14,49},{51,13,50},{52,12,51}},white={{11,19,21},{12,19,21},{13,18,22},{14,18,22},{15,18,22},{16,17,23},{17,17,23},{18,17,23},{19,16,24},{20,16,24},{21,16,24},{22,15,25},{23,15,25},{24,16,24},{25,16,24},{26,16,24},{27,17,23},{28,17,23},{29,17,23},{30,18,22},{31,18,22},{32,18,22},{33,19,21},{34,19,21},{35,19,21},{36,19,21},{37,19,21},{38,19,21},{39,19,21},{40,17,22},{41,16,23},{42,16,24},{43,16,24},{44,16,24},{45,16,24},{46,16,24}}},
  ems={bg={{0,0,63},{1,0,63},{2,0,63},{3,0,63},{4,0,63},{5,0,63},{6,0,63},{7,0,63},{8,0,63},{9,0,63},{10,0,63},{11,0,18},{11,22,23},{11,31,36},{11,56,63},{12,0,17},{12,23,24},{12,35,38},{12,56,63},{13,0,17},{13,23,24},{13,37,39},{13,56,63},{14,0,17},{14,23,24},{14,38,40},{14,56,63},{15,0,16},{15,24,25},{15,39,41},{15,56,63},{16,0,16},{16,24,25},{16,40,42},{16,56,63},{17,0,16},{17,24,25},{17,41,43},{17,56,63},{18,0,15},{18,25,26},{18,42,63},{19,0,15},{19,25,26},{19,43,63},{20,0,15},{20,25,26},{20,43,63},{21,0,14},{21,26,27},{21,44,63},{22,0,14},{22,26,27},{22,44,63},{23,0,21},{23,26,27},{23,44,63},{24,0,20},{24,26,27},{24,45,63},{25,0,19},{25,26,26},{25,45,63},{26,0,19},{26,25,26},{26,45,63},{27,0,18},{27,25,26},{27,46,63},{28,0,17},{28,25,25},{28,46,63},{29,0,17},{29,24,25},{29,46,63},{30,0,16},{30,24,25},{30,46,63},{31,0,16},{31,24,24},{31,46,63},{32,0,17},{32,23,24},{32,46,63},{33,0,17},{33,23,24},{33,46,63},{34,0,17},{34,23,23},{34,46,63},{35,0,18},{35,22,63},{36,0,18},{36,22,63},{37,0,18},{37,22,23},{37,42,63},{38,0,18},{38,22,23},{38,42,63},{39,0,17},{39,23,24},{39,42,63},{40,0,16},{40,24,25},{40,42,63},{41,0,15},{41,25,26},{41,42,63},{42,0,15},{42,25,26},{42,42,63},{43,0,15},{43,25,26},{43,42,63},{44,0,15},{44,25,63},{45,0,15},{45,25,63},{46,0,15},{46,25,26},{46,46,63},{47,0,26},{47,47,63},{48,0,26},{48,48,63},{49,0,14},{49,49,63},{50,0,13},{50,50,63},{51,0,12},{51,51,63},{52,0,11},{52,52,63},{53,0,63},{54,0,63},{55,0,63},{56,0,63},{57,0,63},{58,0,63},{59,0,63},{60,0,63},{61,0,63},{62,0,63},{63,0,63}},green={{11,24,30},{11,37,55},{12,18,18},{12,22,22},{12,25,34},{12,39,55},{13,25,36},{13,40,55},{14,25,37},{14,41,55},{15,17,17},{15,23,23},{15,26,38},{15,42,55},{16,26,39},{16,43,55},{17,26,40},{17,44,55},{18,16,16},{18,24,24},{18,27,41},{19,27,42},{20,27,42},{21,15,15},{21,25,25},{21,28,43},{22,15,15},{22,28,43},{23,28,43},{24,25,25},{24,28,44},{25,20,20},{25,25,25},{25,27,44},{26,27,44},{27,24,24},{27,27,45},{28,18,18},{28,24,24},{28,26,45},{29,26,45},{30,17,17},{30,23,23},{30,26,45},{31,17,17},{31,23,23},{31,25,45},{32,25,45},{33,18,18},{33,22,22},{33,25,45},{34,18,18},{34,22,22},{34,24,45},{37,24,41},{38,24,41},{39,18,18},{39,22,22},{39,25,41},{40,23,23},{40,26,41},{41,24,24},{41,27,41},{42,27,41},{43,27,41},{46,27,45},{47,27,46},{48,27,47},{49,15,48},{50,14,49},{51,13,50},{52,12,51}},white={{11,19,21},{12,19,21},{13,18,22},{14,18,22},{15,18,22},{16,17,23},{17,17,23},{18,17,23},{19,16,24},{20,16,24},{21,16,24},{22,16,25},{23,22,25},{24,21,24},{25,21,24},{26,20,24},{27,19,23},{28,19,23},{29,18,23},{30,18,22},{31,18,22},{32,18,22},{33,19,21},{34,19,21},{35,19,21},{36,19,21},{37,19,21},{38,19,21},{39,19,21},{40,17,22},{41,16,23},{42,16,24},{43,16,24},{44,16,24},{45,16,24},{46,16,24}}},
  rocket={bg={{0,0,63},{1,0,63},{2,0,63},{3,0,63},{4,0,63},{5,0,63},{6,0,63},{7,0,63},{8,0,63},{9,0,63},{10,0,63},{11,0,17},{11,31,36},{11,56,63},{12,0,17},{12,34,38},{12,56,63},{13,0,17},{13,36,39},{13,56,63},{14,0,17},{14,38,40},{14,56,63},{15,0,17},{15,39,41},{15,56,63},{16,0,17},{16,24,33},{16,40,42},{16,56,63},{17,0,17},{17,23,33},{17,41,43},{17,56,63},{18,0,17},{18,22,24},{18,32,33},{18,42,63},{19,0,17},{19,21,23},{19,32,33},{19,43,63},{20,0,17},{20,20,22},{20,32,33},{20,43,63},{21,0,17},{21,19,21},{21,32,33},{21,44,63},{22,0,20},{22,32,33},{22,44,63},{23,0,19},{23,32,33},{23,44,63},{24,0,18},{24,32,33},{24,45,63},{25,0,12},{25,31,33},{25,45,63},{26,0,11},{26,30,32},{26,45,63},{27,0,10},{27,29,31},{27,46,63},{28,0,9},{28,28,30},{28,46,63},{29,0,8},{29,27,29},{29,46,63},{30,0,7},{30,26,28},{30,46,63},{31,0,6},{31,25,27},{31,46,63},{32,0,17},{32,25,26},{32,46,63},{33,0,17},{33,25,26},{33,46,63},{34,0,9},{34,14,17},{34,25,26},{34,46,63},{35,0,8},{35,13,17},{35,25,63},{36,0,7},{36,12,14},{36,16,17},{36,25,63},{37,0,13},{37,16,17},{37,24,26},{37,42,63},{38,0,12},{38,16,17},{38,23,25},{38,42,63},{39,0,12},{39,16,17},{39,22,24},{39,42,63},{40,0,12},{40,15,17},{40,21,23},{40,42,63},{41,0,12},{41,14,17},{41,20,22},{41,42,63},{42,0,17},{42,19,21},{42,42,63},{43,0,21},{43,42,63},{44,0,63},{45,0,63},{46,0,17},{46,46,63},{47,0,16},{47,47,63},{48,0,15},{48,48,63},{49,0,14},{49,49,63},{50,0,13},{50,50,63},{51,0,12},{51,51,63},{52,0,11},{52,52,63},{53,0,63},{54,0,63},{55,0,63},{56,0,63},{57,0,63},{58,0,63},{59,0,63},{60,0,63},{61,0,63},{62,0,63},{63,0,63}},green={{11,18,30},{11,37,55},{12,18,33},{12,39,55},{13,18,35},{13,40,55},{14,18,37},{14,41,55},{15,18,38},{15,42,55},{16,18,23},{16,34,39},{16,43,55},{17,18,22},{17,34,40},{17,44,55},{18,18,21},{18,25,25},{18,34,41},{19,18,20},{19,24,24},{19,34,42},{20,18,19},{20,23,23},{20,34,42},{21,18,18},{21,22,22},{21,34,43},{22,21,21},{22,34,43},{23,20,20},{23,34,43},{24,19,19},{24,31,31},{24,34,44},{25,13,13},{25,30,30},{25,34,44},{26,12,12},{26,29,29},{26,33,44},{27,11,11},{27,28,28},{27,32,45},{28,10,10},{28,27,27},{28,31,45},{29,9,9},{29,26,26},{29,30,45},{30,8,8},{30,25,25},{30,29,45},{31,7,7},{31,28,45},{32,27,45},{33,27,45},{34,10,10},{34,27,45},{35,9,9},{36,8,8},{36,24,24},{37,23,23},{37,27,41},{38,22,22},{38,26,41},{39,21,21},{39,25,41},{40,20,20},{40,24,41},{41,19,19},{41,23,41},{42,18,18},{42,22,41},{43,22,41},{46,18,45},{47,17,46},{48,16,47},{49,15,48},{50,14,49},{51,13,50},{52,12,51}},white={{18,26,31},{19,25,31},{20,24,31},{21,23,31},{22,22,31},{23,21,31},{24,20,30},{25,14,29},{26,13,28},{27,12,27},{28,11,26},{29,10,25},{30,9,24},{31,8,24},{32,18,24},{33,18,24},{34,11,13},{34,18,24},{35,10,12},{35,18,24},{36,9,11},{36,15,15},{36,18,23},{37,14,15},{37,18,22},{38,13,15},{38,18,21},{39,13,15},{39,18,20},{40,13,14},{40,18,19},{41,13,13},{41,18,18}}},
}

local function draw_icon_runs(line,center,right,up,scale,runs,color)
    if not runs then return end
    local n=ORIGINAL_ICON_RES
    local half=0.5
    local row_thick=(1.0/n)*0.49
    for i=1,#runs do
        local r=runs[i]
        local y=half-((r[1]+0.5)/n)
        local x1=(r[2]/n)-half
        local x2=((r[3]+1)/n)-half
        add_thick_line(line,color,center,right,up,x1,y,x2,y,scale,row_thick)
    end
end
local function add_special_icon(line,kind,center,right,up,scale,alpha)
    local a = math.max(20, math.min(255, math.floor(alpha + 0.5)))
    local green=sr.Color(a,126,151,116)
    local white=sr.Color(a,224,224,218)
    local t=0.026
    if kind=='tesla' then
        -- Compact lightning-bolt glyph.
        local pts={{-0.02,0.48},{-0.30,0.06},{-0.08,0.06},{-0.20,-0.46},{0.34,0.12},{0.10,0.12},{0.24,0.48}}
        for i=1,#pts-1 do
            add_thick_line(line,green,center,right,up,pts[i][1],pts[i][2],pts[i+1][1],pts[i+1][2],scale,t)
        end
        add_thick_line(line,white,center,right,up,-0.18,-0.05,0.18,0.05,scale,t*0.75)
        return true
    elseif kind=='flame' then
        -- Stylised flame outline with a small bright inner lick.
        local pts={{0.00,-0.48},{-0.28,-0.15},{-0.26,0.10},{-0.06,0.46},{0.02,0.16},{0.22,0.34},{0.30,0.02},{0.18,-0.28},{0.00,-0.48}}
        for i=1,#pts-1 do
            add_thick_line(line,green,center,right,up,pts[i][1],pts[i][2],pts[i+1][1],pts[i+1][2],scale,t)
        end
        add_thick_line(line,white,center,right,up,0.00,-0.28,-0.08,-0.02,scale,t*0.8)
        add_thick_line(line,white,center,right,up,-0.08,-0.02,0.06,0.16,scale,t*0.8)
        return true
    end
    return false
end

local function add_original_icon(line,kind,center,right,up,scale,alpha)
    if add_special_icon(line,kind,center,right,up,scale,alpha) then return end
    local data=ORIGINAL_ICON_RUNS[kind] or ORIGINAL_ICON_RUNS.mg
    -- Low saturation, not low visibility: keep normal marker alpha and mute only the RGB saturation.
    local a = math.max(20, math.min(255, math.floor(alpha + 0.5)))
    local green=sr.Color(a,126,151,116)
    local white=sr.Color(a,224,224,218)
    draw_icon_runs(line,center,right,up,scale,data.green,green)
    draw_icon_runs(line,center,right,up,scale,data.white,white)
end

local function add_icon_brackets(line,center,right,up,scale,color)
    -- Four outlined triangular corner markers, with each tip pointing outward.
    local e=0.64
    local s=0.22
    local d=0.12
    local t=0.018
    local function tri(ax,ay,bx,by,cx,cy)
        add_thick_line(line,color,center,right,up,ax,ay,bx,by,scale,t)
        add_thick_line(line,color,center,right,up,ax,ay,cx,cy,scale,t)
        add_thick_line(line,color,center,right,up,bx,by,cx,cy,scale,t)
    end
    -- top-left / top-right / bottom-left / bottom-right
    tri(-e-d, e+d,-e+s, e,-e, e-s)
    tri( e+d, e+d, e-s, e, e, e-s)
    tri(-e-d,-e-d,-e+s,-e,-e,-e+s)
    tri( e+d,-e-d, e-s,-e, e,-e+s)
end

local function render_models(world)
    if not ensure_model(world) then state.model_drawn = 0; return end
    local line = state.model_line
    pcall(sr.LineObject.reset,line)
    if not MC.enabled then
        pcall(sr.LineObject.dispatch,world,line)
        state.model_drawn = 0
        return
    end
    if not sr.World or type(sr.World.debug_camera_pose) ~= 'function' or not sr.Matrix4x4 then
        state.model_error = 'debug_camera_pose unavailable'
        state.model_drawn = 0
        return
    end
    local ok,pose = pcall(sr.World.debug_camera_pose,world)
    if not ok or not pose then state.model_error = 'debug_camera_pose failed'; state.model_drawn = 0; return end
    local cam_pos = sr.Matrix4x4.translation(pose)
    local right = sr.Matrix4x4.axis(pose,1)
    local up = sr.Matrix4x4.axis(pose,3)
    local alpha = math.max(20,math.min(100,MC.opacity))*2.55
    local rows = state.live_ammo or {}
    local drawn = 0

    for _,r in ipairs(rows) do
        local center = sr.Vector3(r.pos.x,r.pos.y,r.pos.z+MC.height)
        local distance = sr.Vector3.distance(cam_pos,center)
        if distance <= MC.max_distance then
            local ratio = r.maximum > 0 and math.max(0,math.min(1,r.remaining/r.maximum)) or 0
            local rr,gg,bb = 245,245,245
            if MC.low_color and ratio <= 0.20 then rr,gg,bb = 255,70,70
            elseif MC.low_color and ratio <= 0.50 then rr,gg,bb = 255,220,40 end
            local color = sr.Color(alpha,rr,gg,bb)
            -- Layout tuned for readability: slightly larger icon, smaller digits, and wider spacing to avoid overlap on 3-digit counts.
            local s = MC.scale * 0.40
            local remain_value = math.max(0, math.floor((tonumber(r.remaining) or 0) + 0.5))
            local digits = #tostring(remain_value)
            local icon_center = center - right*((0.96 + math.max(0,digits-2)*0.06)*s)
            local num_center = center + right*((1.04 + math.max(0,digits-2)*0.20)*s)
            local icon_scale=s*1.34
            add_original_icon(line,r.kind,icon_center,right,up,icon_scale,alpha)
            local bracket_color=sr.Color(math.max(24,math.floor(alpha*0.92)),rr,gg,bb)
            add_icon_brackets(line,icon_center,right,up,icon_scale,bracket_color)
            add_number(line,remain_value,num_center,right,up,s*0.86,color)
            drawn = drawn + 1
        end
    end
    sr.LineObject.dispatch(world,line)
    state.model_drawn = drawn
end

local function model_tick()
    state.frames = (state.frames or 0) + 1
    if state.frames % 30 == 0 then menu_step() end
    if not sr then
        sr = rawget(_G,'stingray') or rawget(_G,'s3d')
        if not sr then return end
    end
    if not G.wmag then
        if state.build_mode == 'compatibility' and compat.offset ~= math.huge then compatibility_scan_step() end
        return
    end
    if state.frames % MC.scan_every == 0 or state.live_ammo == nil then
        local ok,rows = pcall(collect_sentry_ammo)
        if ok then
            state.live_ammo = rows
            state.model_rows = #rows
            state.model_error = 'none'
        else
            state.live_ammo = {}
            state.model_rows = 0
            state.model_error = tostring(rows)
            model_log('scan failed: ' .. tostring(rows))
        end
    end
    local world = main_world()
    if not world then
        release_model()
        state.model_drawn = 0
        return
    end
    local ok,err = pcall(render_models,world)
    if not ok then
        state.model_error = tostring(err)
        state.model_line_errors = state.model_line_errors + 1
        model_log('render failed: ' .. tostring(err))
        release_model()
    elseif state.frames % 120 == 0 then
        local diag = string.format('rows=%d drawn=%d mag=%d rounds=%d unit=%d goid=%d near=%d spatial=%d unowned=%d',state.model_rows or 0,state.model_drawn or 0,state.mag_components or 0,state.round_components or 0,state.claim_unit or 0,state.claim_goid or 0,state.claim_goid_near or 0,state.claim_spatial or 0,state.unowned_magazines or 0)
        if diag ~= state.last_model_diag then state.last_model_diag = diag; model_log(diag) end
    end
end

local previous_update = rawget(_G,'update')
if type(previous_update) ~= 'function' then
    model_log('global update() unavailable')
    return state
end
local model_wrapper
local function after_update(...)
    if not state.model_failed then
        local ok,err = pcall(model_tick)
        if not ok then
            state.model_failed = true
            state.model_error = tostring(err)
            model_log('FAILED: ' .. tostring(err))
            pcall(release_model)
        end
    end
    return ...
end
model_wrapper = function(...) return after_update(previous_update(...)) end
_G.update = model_wrapper

local previous_shutdown = rawget(_G,'shutdown')
if type(previous_shutdown) == 'function' then
    _G.shutdown = function(...)
        pcall(release_model)
        if rawget(_G,'update') == model_wrapper then _G.update = previous_update end
        return previous_shutdown(...)
    end
end

model_log('ready - v3.9.0 expanded sentries + hostile feed filter + triangle corner icons')
return state
